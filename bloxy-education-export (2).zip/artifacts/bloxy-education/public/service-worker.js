/* Cache only public app assets. Never cache API, authentication or other artifacts. */
const CACHE = 'bloxy-public-offline-v1';
const root = self.registration.scope;
const allowed = value => {
  const url = new URL(value, root);
  const path = url.pathname;
  return url.origin === self.location.origin &&
    (path === '/' || path === '/index.html' || path === '/offline' ||
     path === '/logo.svg' || path === '/favicon.svg' ||
     path.startsWith('/assets/') || path.startsWith('/src/') ||
     path.startsWith('/node_modules/') || path.startsWith('/@'));
};

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll([root, new URL('logo.svg', root).href]);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});
self.addEventListener('message', event => {
  if (event.data?.type !== 'CACHE_APP_RESOURCES' || !Array.isArray(event.data.urls)) return;
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await Promise.all(event.data.urls.filter(allowed).map(async url => {
      try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        await cache.put(url, response);
      } catch (error) {
        console.warn('Could not cache offline asset', url, error);
      }
    }));
  })());
});
self.addEventListener('fetch', event => {
  const path = new URL(event.request.url).pathname;
  const appNavigation = event.request.mode === 'navigate' &&
    new URL(event.request.url).origin === self.location.origin &&
    ['/user-portal', '/learn', '/challenges', '/leaderboard', '/sign-in', '/sign-up'].some(route => path === route || path.startsWith(`${route}/`));
  if (appNavigation) {
    event.respondWith(fetch(event.request).catch(() => Response.redirect(new URL('offline', root).href)));
    return;
  }
  if (event.request.method !== 'GET' || !allowed(event.request.url)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const response = await fetch(event.request);
      if (response.ok) await cache.put(event.request, response.clone());
      return response;
    } catch {
      const saved = await cache.match(event.request);
      if (saved) return saved;
      if (event.request.mode === 'navigate') {
        const shell = await cache.match(root);
        if (shell) return shell;
      }
      return new Response('This resource has not been saved for offline use yet.', { status: 503 });
    }
  })());
});