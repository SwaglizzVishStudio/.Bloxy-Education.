import { useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowRight, FlaskConical, Shield, ShoppingBag, Sparkles, Sword } from 'lucide-react';
import { getGetDashboardQueryKey, getGetShopQueryKey, useGetShop, usePurchaseShopItem } from '@workspace/api-client-react';
import type { ShopItem } from '@workspace/api-client-react';
import '../games-shop.css';

const itemArt = {
  sword: { icon: Sword, note: 'A practice blade for imaginary quests.' },
  shield: { icon: Shield, note: 'A sturdy companion for story adventures.' },
  potion: { icon: FlaskConical, note: 'A pretend boost for your next chapter.' },
};

function ShopLoading() {
  return <div className="shop-items" aria-label="Loading shop" data-testid="status-shop-loading">{[0,1,2].map(item => <div className="shop-item" key={item}><div className="skeleton skeleton-title" /><div className="skeleton skeleton-line" /><div className="skeleton skeleton-card" /></div>)}</div>;
}

export function ShopPage() {
  const queryClient = useQueryClient();
  const { data: shop, isLoading, isError, refetch } = useGetShop();
  const purchase = usePurchaseShopItem();
  const requestIds = useRef(new Map<string, string>());
  const [pendingItem, setPendingItem] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ text: string; error: boolean } | null>(null);

  const buy = (item: ShopItem) => {
    if (!shop || shop.coins < item.price || purchase.isPending) return;
    let requestId = requestIds.current.get(item.id);
    if (!requestId) {
      requestId = crypto.randomUUID();
      requestIds.current.set(item.id, requestId);
    }
    setNotice(null);
    setPendingItem(item.id);
    purchase.mutate({ data: { itemId: item.id, requestId } }, {
      onSuccess: result => {
        requestIds.current.delete(item.id);
        setNotice({ text: result.alreadyProcessed ? 'That purchase was already recorded. Your inventory is up to date.' : `${item.name} added to your inventory for ${result.coinsSpent} coins.`, error: false });
        queryClient.invalidateQueries({ queryKey: getGetShopQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        setPendingItem(null);
      },
      onError: () => {
        setPendingItem(null);
        setNotice({ text: 'Purchase could not be confirmed. Retry to safely reuse this purchase request.', error: true });
      },
    });
  };

  if (isLoading) return <div className="shop-page"><div className="shop-hero"><div><div className="eyebrow eyebrow-light">The coin corner</div><h1>Little finds.</h1><p>Loading your account inventory…</p></div></div><ShopLoading /></div>;
  if (isError || !shop) return <div className="shop-page"><div className="shop-hero"><div><div className="eyebrow eyebrow-light">The coin corner</div><h1>Little finds.</h1><p>We couldn’t load your account balance just now.</p></div></div><div className="error-panel" role="alert" data-testid="status-shop-error"><div><strong>One tiny hiccup.</strong><p>The shop is taking a pause. Your items and coins remain safe.</p><button className="text-link" onClick={() => refetch()} data-testid="button-retry-shop">Try again <ArrowRight size={15} /></button></div></div></div>;

  return <div className="shop-page reveal">
    <section className="shop-hero"><div><div className="eyebrow eyebrow-light">A small reward for curiosity</div><h1>The coin corner</h1><p>Pick a playful companion for your story adventures. Your purchases and inventory stay with your Bloxy account.</p></div><div className="coin-balance" data-testid="text-shop-balance"><span className="coin-medallion">B</span><div><small>YOUR COINS</small><strong>{shop.coins}</strong></div></div></section>
    <div className="shop-section-head"><div><div className="eyebrow">Available today</div><h2>Choose a little something</h2></div><p>Purchases update your shared account inventory.</p></div>
    <div className="shop-items">{shop.items.map(item => {
      const art = itemArt[item.id];
      const Icon = art?.icon ?? ShoppingBag;
      const canAfford = shop.coins >= item.price;
      return <article className="shop-item" key={item.id} data-testid={`shop-item-${item.id}`}>
        <span className="shop-item-symbol"><Icon size={25} /></span>
        <h3>{item.name}</h3><p>{item.description || art?.note}</p>
        <span className="item-owned">Owned · {item.ownedCount}</span>
        <div className="shop-item-bottom"><span className="item-price"><span aria-hidden="true">B</span> {item.price}</span><button type="button" className="game-action shop-buy" onClick={() => buy(item)} disabled={!canAfford || purchase.isPending} data-testid={`button-buy-${item.id}`}>{pendingItem === item.id ? 'Buying…' : canAfford ? 'Buy item' : 'Need more coins'} <ArrowRight size={14} /></button></div>
      </article>;
    })}</div>
    {notice && <div className={`shop-notice ${notice.error ? 'error' : ''}`} role={notice.error ? 'alert' : 'status'} data-testid="status-purchase-result">{notice.text}{notice.error && pendingItem === null && <button className="text-link" style={{ marginLeft: 9 }} onClick={() => { const lastFailed = shop.items.find(item => requestIds.current.has(item.id)); if (lastFailed) buy(lastFailed); }}>Retry purchase <ArrowRight size={13} /></button>}</div>}
    {shop.items.some(item => shop.coins < item.price) && <p className="shop-notice">A few more earned coins will unlock the items above your balance.</p>}
    <section className="shop-inventory"><h2><Sparkles size={17} style={{ verticalAlign: '-3px', marginRight: 7 }} />Your account inventory</h2>{shop.items.some(item => item.ownedCount > 0) ? <div className="inventory-list">{shop.items.filter(item => item.ownedCount > 0).map(item => <span className="inventory-chip" key={item.id}><span>{item.name}</span><strong>× {item.ownedCount}</strong></span>)}</div> : <div className="empty-state"><span className="empty-icon"><ShoppingBag size={20} /></span><div><strong>Your inventory is ready for its first find.</strong><p>Choose an item above and it will appear here across your signed-in account.</p></div></div>}</section>
    <p className="game-disclaimer">Coins and inventory are read from Bloxy and updated only after a confirmed purchase. Games do not change your coin balance except for the server-verified Maze Escape reward.</p>
  </div>;
}
