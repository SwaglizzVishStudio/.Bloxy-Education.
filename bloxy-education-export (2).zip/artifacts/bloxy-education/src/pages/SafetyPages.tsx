import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Link } from 'wouter';
import {
  AlertCircle, ArrowRight, CheckCircle2, ChevronRight, Clock3,
  Eye, LockKeyhole, Search, ShieldCheck, ShieldOff, UserRound, X,
} from 'lucide-react';
import {
  getGetModerationAccessQueryKey, getGetOwnerSessionQueryKey,
  getListOwnerSafetyReportsQueryKey, getListOwnerUsersQueryKey,
  getListReportTargetsQueryKey, useBanOwnerUser, useCompleteModerationEvent,
  useCreateOwnerSession, useCreateSafetyReport, useDeleteOwnerSession,
  useGetModerationAccess, useGetOwnerSession, useKickOwnerUser,
  useListOwnerSafetyReports, useListOwnerUsers, useListReportTargets,
  useReviewOwnerSafetyReport, useUnbanOwnerUser, useUpdateModerationPreferences,
} from '@workspace/api-client-react';
import type {
  OwnerSafetyReport, OwnerUser, SafetyReportReason, SafetyReportStatus,
} from '@workspace/api-client-react';

const reasonTitles: Record<SafetyReportReason, string> = {
  unsafe_contact: 'Someone asked to contact me outside Bloxy',
  personal_information: 'Someone shared or asked for personal information',
  harassment: 'Someone was unkind or made me feel unsafe',
  other: 'Something else I want an adult to review',
};
const statusTitles: Record<SafetyReportStatus, string> = {
  pending: 'Pending', action_taken: 'Action taken', reviewed: 'Reviewed', dismissed: 'Dismissed',
};
const dateLabel = (date: string) => new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date(date));

function SafetyLoading() {
  return <div className="loading-panel" role="status" data-testid="status-safety-loading"><div className="skeleton skeleton-title" /><div className="skeleton skeleton-line" /><div className="skeleton skeleton-card" /><span>Opening the safety desk</span></div>;
}
function SafetyError({ retry }: { retry: () => void }) {
  return <div className="error-panel" role="alert" data-testid="status-safety-error"><div className="error-symbol"><AlertCircle size={19} /></div><div><strong>The safety desk is taking a moment.</strong><p>Nothing has been submitted. Please try again.</p><button className="text-link" type="button" onClick={retry} data-testid="button-retry-safety">Try again <ArrowRight size={15} /></button></div></div>;
}

function SpookyVisual() {
  return <div className="spooky-visual" aria-hidden="true">
    <svg viewBox="0 0 260 230" focusable="false">
      <path d="M38 65 54 14 94 42 130 30 166 42 206 14 222 65 229 115 207 168 174 196 130 210 86 196 53 168 31 115Z" fill="#84382e" stroke="#d99661" strokeWidth="5" strokeLinejoin="round" />
      <path d="m52 72 34 7-8 69-27 11-13-45Z" fill="#512b28" stroke="#b97750" strokeWidth="4" />
      <path d="m208 72-34 7 8 69 27 11 13-45Z" fill="#512b28" stroke="#b97750" strokeWidth="4" />
      <path d="m63 78 53 7-9 34-45-3Z" fill="#241f20" stroke="#e7b06f" strokeWidth="4" strokeLinejoin="round" />
      <path d="m197 78-53 7 9 34 45-3Z" fill="#241f20" stroke="#e7b06f" strokeWidth="4" strokeLinejoin="round" />
      <ellipse cx="91" cy="99" rx="8" ry="10" fill="#ffd47a" />
      <ellipse cx="169" cy="99" rx="8" ry="10" fill="#ffd47a" />
      <path d="m118 119 12-7 12 7-12 9Z" fill="#d59667" stroke="#412729" strokeWidth="3" />
      <path d="m82 144 48 10 48-10-9 35-39 13-39-13Z" fill="#211e21" stroke="#d99661" strokeWidth="4" strokeLinejoin="round" />
      <path d="m101 151 12 3-3 19-12-4Zm25 5h9v18h-9Zm21-2 12-3 3 18-12 4Z" fill="#f1dfba" stroke="#8b5944" strokeWidth="2" strokeLinejoin="round" />
      <path d="m125 44 5 20 5-20M48 154l17 3m147-3-17 3M80 190l-5 14m105-14 5 14" fill="none" stroke="#edb471" strokeWidth="4" strokeLinecap="round" />
      <circle cx="130" cy="77" r="5" fill="#edb471" />
    </svg>
  </div>;
}

export function SpookyPreference() {
  const queryClient = useQueryClient();
  const access = useGetModerationAccess({ query: { queryKey: getGetModerationAccessQueryKey() } });
  const update = useUpdateModerationPreferences();
  const [message, setMessage] = useState('');
  if (access.isLoading) return <div className="safety-card"><div className="skeleton skeleton-line" /><p>Loading your visual-effect preference…</p></div>;
  if (access.isError || !access.data) return <div className="safety-card"><h2>Your comfort settings</h2><p>We couldn’t load this preference.</p><button className="owner-action" onClick={() => access.refetch()} data-testid="button-retry-preference">Try again</button></div>;
  const toggle = () => {
    setMessage('');
    update.mutate({ data: { allowSpookyEffects: !access.data.allowSpookyEffects } }, {
      onSuccess: result => {
        queryClient.setQueryData(getGetModerationAccessQueryKey(), { ...access.data!, allowSpookyEffects: result.allowSpookyEffects });
        setMessage(result.allowSpookyEffects ? 'Visual effects are now allowed. You can turn this off at any time.' : 'Visual effects are off for your account.');
      },
      onError: () => setMessage('That change could not be saved. Please try again.'),
    });
  };
  return <section className="preference-row" aria-labelledby="spooky-preference-title">
    <span className="preference-icon"><Eye size={21} /></span>
    <div className="preference-copy"><strong id="spooky-preference-title">Visual spooky effects</strong><p>Choose whether a short, original robot-fox face reveal may appear during a moderation event. It has no sound, never flashes, and can always be skipped.</p>{message && <span className={update.isError ? 'safety-inline-error' : 'safety-hint'} role={update.isError ? 'alert' : 'status'} data-testid="text-preference-message">{message}</span>}</div>
    <button className="toggle-control" role="switch" aria-checked={access.data.allowSpookyEffects} aria-label="Allow visual spooky effects" disabled={update.isPending} onClick={toggle} data-testid="switch-spooky-effects" />
  </section>;
}

export function ModerationGate({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const access = useGetModerationAccess({ query: { queryKey: getGetModerationAccessQueryKey(), refetchInterval: 4000, refetchIntervalInBackground: true } });
  const complete = useCompleteModerationEvent();
  const [eventId, setEventId] = useState('');
  const [seconds, setSeconds] = useState(3);
  const [effectPhase, setEffectPhase] = useState(false);
  const [eventDone, setEventDone] = useState(false);
  const [message, setMessage] = useState('');
  const pending = access.data?.pendingEvent;
  useEffect(() => {
    if (pending && pending.id !== eventId) {
      setEventId(pending.id);
      setSeconds(3);
      setEffectPhase(false);
      setEventDone(false);
      setMessage('');
    }
  }, [pending?.id, eventId]);
  useEffect(() => {
    if (!pending || pending.id !== eventId || !effectPhase || seconds <= 0) return;
    const timer = window.setTimeout(() => setSeconds(value => Math.max(0, value - 1)), 1000);
    return () => window.clearTimeout(timer);
  }, [pending?.id, eventId, effectPhase, seconds]);
  const finishEvent = (withEffect: boolean) => {
    if (!pending || complete.isPending) return;
    if (withEffect && pending.showSpookyEffect && access.data?.allowSpookyEffects && !effectPhase) {
      setEffectPhase(true);
      setSeconds(3);
      return;
    }
    if (withEffect && effectPhase && seconds > 0) return;
    setMessage('');
    complete.mutate({ eventId: pending.id }, {
      onSuccess: () => {
        setEventDone(true);
        queryClient.invalidateQueries({ queryKey: getGetModerationAccessQueryKey() });
        setEffectPhase(false);
      },
      onError: () => setMessage('We couldn’t finish this step just now. Please try again.'),
    });
  };
  useEffect(() => {
    if (!effectPhase || seconds !== 0) return;
    const timer = window.setTimeout(() => {
      complete.mutate({ eventId }, {
        onSuccess: () => {
          setEventDone(true);
          setEffectPhase(false);
          queryClient.invalidateQueries({ queryKey: getGetModerationAccessQueryKey() });
        },
        onError: () => setMessage('We couldn’t finish this step just now. Please try again.'),
      });
    }, 1800);
    return () => window.clearTimeout(timer);
  }, [effectPhase, seconds, eventId]);
  if (access.isLoading) return <div className="app-shell"><div className="main-column"><main className="portal-content"><SafetyLoading /></main></div></div>;
  if (access.isError || !access.data) return <div className="app-shell"><div className="main-column"><main className="portal-content"><SafetyError retry={() => access.refetch()} /></main></div></div>;
  if (access.data.banned) return <main className="moderation-screen"><section className="moderation-dialog"><span className="safety-seal"><ShieldOff /></span><div className="eyebrow">Account access</div><h1>This learning space is unavailable</h1><p>Your account is currently restricted. If you think this is a mistake, please ask a parent or guardian to contact Bloxy support. You can sign out safely.</p><Link href="/" className="button button-dark" data-testid="link-banned-home">Return to Bloxy <ArrowRight size={16} /></Link></section></main>;
  if (pending && pending.id === eventId && !eventDone) return <main className="moderation-screen" role="dialog" aria-modal="true" aria-labelledby="moderation-title"><section className={`moderation-dialog ${effectPhase && seconds === 0 ? 'effect-active' : ''}`}>
    <span className="safety-seal"><ShieldCheck /></span><div className="eyebrow">A quick account check</div>
    {effectPhase ? <><span className="countdown-badge"><Clock3 size={14} /> {seconds > 0 ? `Visual effect begins in ${seconds}` : 'Visual effect complete'}</span>{seconds === 0 && <SpookyVisual />}<h1 id="moderation-title">{seconds > 0 ? 'Take a breath' : 'The visual effect has played'}</h1><p>No sound and no flashing. This original robot-fox reveal is brief and can be skipped at any time.</p><div className="moderation-actions"><button className="button button-quiet" onClick={() => finishEvent(false)} disabled={complete.isPending} data-testid="button-skip-effect">Skip effect and continue</button></div></> :
      <><h1 id="moderation-title">{pending.action === 'ban' ? 'Your account is restricted' : 'Please pause here'}</h1><p>{pending.action === 'ban' ? 'This account has been restricted by a moderator. We’ll record that you have seen this notice.' : 'A moderator has asked you to pause this session. Your learning space will be ready after this check.'}</p>{pending.showSpookyEffect && access.data.allowSpookyEffects && <div className="safety-callout"><Eye size={17} /><span>A visual-only effect is available because this account has opted in. It has no sound, never flashes, and starts with a 3-second warning.</span></div>}{message && <p className="safety-inline-error" role="alert">{message}</p>}<div className="moderation-actions">{pending.showSpookyEffect && access.data.allowSpookyEffects && <button className="button button-dark" onClick={() => finishEvent(true)} disabled={complete.isPending} data-testid="button-continue-effect">Continue with visual effect <ChevronRight size={16} /></button>}<button className="button button-quiet" onClick={() => finishEvent(false)} disabled={complete.isPending} data-testid="button-skip-moderation">{complete.isPending ? 'Saving…' : 'Skip and continue'} <ArrowRight size={16} /></button></div></>}
  </section></main>;
  return <>{children}</>;
}

export function SafetyReportPage() {
  const queryClient = useQueryClient();
  const targets = useListReportTargets({ query: { queryKey: getListReportTargetsQueryKey() } });
  const create = useCreateSafetyReport();
  const [targetUserId, setTarget] = useState('');
  const [reason, setReason] = useState<SafetyReportReason>('unsafe_contact');
  const [details, setDetails] = useState('');
  const [evidence, setEvidence] = useState('');
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!targetUserId || details.trim().length < 10) { setError('Choose a learner and add at least 10 characters so the reviewer understands your concern.'); return; }
    setError('');
    create.mutate({ data: { targetUserId, reason, details: details.trim(), ...(evidence.trim() ? { evidence: evidence.trim() } : {}) } }, {
      onSuccess: () => {
        setSuccess(true);
        setDetails('');
        setEvidence('');
        queryClient.invalidateQueries({ queryKey: getListOwnerSafetyReportsQueryKey() });
      },
      onError: () => setError('Your report could not be sent. Nothing was submitted; please try again.'),
    });
  };
  return <section className="safety-page reveal">
    <header className="safety-hero"><div><div className="eyebrow">A private way to ask for help</div><h1>Safety report</h1><p>Tell our moderation team what happened. Reports are reviewed by a person; submitting a report does not automatically restrict anyone.</p></div><span className="safety-seal"><ShieldCheck size={27} /></span></header>
    {success ? <div className="safety-success" role="status" data-testid="status-report-success"><CheckCircle2 size={22} /><div><strong>Your report is with the safety team.</strong><p>A person will review it. You can return to learning whenever you’re ready.</p><button className="text-link" onClick={() => setSuccess(false)} data-testid="button-submit-another-report">Send another report <ArrowRight size={15} /></button></div></div> :
      <form className="safety-card" onSubmit={submit} data-testid="form-safety-report">
        <h2>What would you like us to review?</h2><p>You only need to share what feels useful. Please do not include passwords, email addresses, phone numbers, or other contact details.</p>
        <div className="safety-form-grid">
          <label className="safety-field">Learner to report<select className="safety-input" value={targetUserId} onChange={event => setTarget(event.target.value)} required data-testid="select-report-target"><option value="">Choose a nickname</option>{targets.data?.map(target => <option key={target.id} value={target.id}>{target.displayName}</option>)}</select>{targets.isLoading && <span className="safety-hint">Loading learner names…</span>}{targets.isError && <span className="safety-inline-error" role="alert">Couldn’t load the list. <button type="button" className="text-link" onClick={() => targets.refetch()}>Try again</button></span>}{targets.data?.length === 0 && <span className="safety-hint">No other learner profiles are available right now.</span>}</label>
          <label className="safety-field">What is this about?<select className="safety-input" value={reason} onChange={event => setReason(event.target.value as SafetyReportReason)} data-testid="select-report-reason">{Object.entries(reasonTitles).map(([value, title]) => <option key={value} value={value}>{title}</option>)}</select></label>
          <label className="safety-field full">Tell us what happened<textarea className="safety-input" value={details} onChange={event => setDetails(event.target.value)} minLength={10} maxLength={1000} required placeholder="Share the parts you want the reviewer to know." data-testid="input-report-details" /><span className="safety-hint">{details.length}/1000. A short description is enough.</span></label>
          <label className="safety-field full">Optional evidence<textarea className="safety-input" value={evidence} onChange={event => setEvidence(event.target.value)} maxLength={700} placeholder="Only include material you choose to submit yourself." data-testid="input-report-evidence" /><span className="safety-hint">This is only the evidence you submit here. Bloxy does not attach chat history or room logs.</span></label>
        </div>
        <div className="safety-callout"><LockKeyhole size={17} /><span>Your report is shared with the moderation team for review. Your email and contact details are not shown in owner review lists.</span></div>
        {error && <p className="safety-inline-error" role="alert" data-testid="text-report-error">{error}</p>}
        <div className="safety-actions"><button className="button button-dark" type="submit" disabled={create.isPending || targets.isLoading || !targets.data?.length} data-testid="button-send-report">{create.isPending ? 'Sending securely…' : 'Send for review'} <ArrowRight size={16} /></button><Link href="/user-portal" className="text-link" data-testid="link-report-cancel">Back to learning</Link></div>
      </form>}
  </section>;
}

function OwnerConfirmation({ user, action, onClose, onConfirm, pending }: { user: OwnerUser; action: 'kick'|'ban'|'unban'; onClose: () => void; onConfirm: (withScare: boolean, reason: string) => void; pending: boolean }) {
  const [withScare, setWithScare] = useState(false);
  const [reason, setReason] = useState('');
  const title = action === 'kick' ? 'Kick this learner?' : action === 'ban' ? 'Restrict this account?' : 'Restore this account?';
  return <div className="confirm-layer" role="presentation"><section className="confirm-card" role="dialog" aria-modal="true" aria-labelledby="owner-confirm-title">
    <div className="eyebrow">Owner action · {user.displayName}</div><h2 id="owner-confirm-title">{title}</h2><p>{action === 'kick' ? 'This ends the learner’s current session. They can sign in again.' : action === 'ban' ? 'This blocks access until an owner restores the account. A ban is not automatic; use this only after your review.' : 'This will remove the account restriction and allow the learner to sign in again.'}</p>
    {action === 'ban' && <label className="safety-field">Optional moderation note<textarea className="safety-input" maxLength={500} value={reason} onChange={event => setReason(event.target.value)} placeholder="Briefly record the reason for the restriction." data-testid="input-ban-reason" /></label>}
    {action !== 'unban' && <label className="safety-callout" style={{ cursor:'pointer' }}><input type="checkbox" checked={withScare} onChange={event => setWithScare(event.target.checked)} data-testid="checkbox-visual-effect" /><span>Request an opt-in visual effect for the learner. It is visual only, has no sound, never flashes, and will only be queued if their preference allows it.</span></label>}
    <div className="safety-actions"><button className={`button ${action === 'unban' ? 'button-dark' : 'button-outline'}`} disabled={pending} onClick={() => onConfirm(withScare, reason.trim())} data-testid={`button-confirm-${action}`}>{pending ? 'Working…' : action === 'kick' ? 'Kick learner' : action === 'ban' ? 'Restrict account' : 'Restore account'}</button><button className="button button-quiet" disabled={pending} onClick={onClose} data-testid="button-cancel-owner-action">Cancel</button></div>
  </section></div>;
}

export function OwnerPage() {
  const queryClient = useQueryClient();
  const session = useGetOwnerSession({ query: { queryKey: getGetOwnerSessionQueryKey(), retry: false } });
  const login = useCreateOwnerSession({ mutation: { gcTime: 0, retry: false } });
  const logout = useDeleteOwnerSession();
  const [search, setSearch] = useState('');
  const [passphrase, setPassphrase] = useState('');
  const [loginError, setLoginError] = useState('');
  const [reportStatus, setReportStatus] = useState<SafetyReportStatus | ''>('pending');
  const [actionTarget, setActionTarget] = useState<{ user: OwnerUser; action: 'kick'|'ban'|'unban' } | null>(null);
  const [reviewNotes, setReviewNotes] = useState<Record<string,string>>({});
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const ownerAuthenticated = session.data?.authenticated === true;
  const params = search.trim() ? { search: search.trim() } : undefined;
  const userList = useListOwnerUsers(params, { query: { queryKey: getListOwnerUsersQueryKey(params), enabled: ownerAuthenticated } });
  const reportParams = reportStatus ? { status: reportStatus } : undefined;
  const reportList = useListOwnerSafetyReports(reportParams, { query: { queryKey: getListOwnerSafetyReportsQueryKey(reportParams), enabled: ownerAuthenticated } });
  const kick = useKickOwnerUser();
  const ban = useBanOwnerUser();
  const unban = useUnbanOwnerUser();
  const review = useReviewOwnerSafetyReport();
  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: getListOwnerUsersQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListOwnerSafetyReportsQueryKey() });
  };
  const confirmAction = (withScare: boolean, reason: string) => {
    if (!actionTarget) return;
    const { user, action } = actionTarget;
    const options = { onSuccess: () => { setActionTarget(null); setNotice(action === 'kick' ? `${user.displayName} has been kicked from the current session.` : action === 'ban' ? `${user.displayName}’s account is restricted.` : `${user.displayName}’s account is restored.`); setError(''); refresh(); }, onError: () => setError('That owner action could not be completed. Please try again.') };
    if (action === 'kick') kick.mutate({ userId: user.id, data: { withScare } }, options);
    else if (action === 'ban') ban.mutate({ userId: user.id, data: { reason, withScare } }, options);
    else unban.mutate({ userId: user.id }, options);
  };
  const actPending = kick.isPending || ban.isPending || unban.isPending;
  const reviewReport = (report: OwnerSafetyReport, status: 'action_taken'|'reviewed'|'dismissed') => {
    setError('');
    review.mutate({ reportId: report.id, data: { status, ...(reviewNotes[report.id]?.trim() ? { reviewNote: reviewNotes[report.id].trim() } : {}) } }, {
      onSuccess: () => { setNotice(`Report marked ${statusTitles[status].toLowerCase()}.`); refresh(); },
      onError: () => setError('This report could not be updated. Please try again.'),
    });
  };
  const signIn = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoginError('');
    login.mutate({ data: { passphrase } }, {
      onSuccess: result => {
        setPassphrase('');
        queryClient.setQueryData(getGetOwnerSessionQueryKey(), result);
      },
      onError: () => {
        setPassphrase('');
        setLoginError('Sign-in failed. Check the passphrase or try again later.');
      },
      onSettled: () => login.reset(),
    });
  };
  const lockOwnerSession = () => {
    logout.mutate(undefined, {
      onSuccess: result => {
        queryClient.removeQueries({ queryKey: getListOwnerUsersQueryKey() });
        queryClient.removeQueries({ queryKey: getListOwnerSafetyReportsQueryKey() });
        queryClient.setQueryData(getGetOwnerSessionQueryKey(), result);
        setSearch('');
        setReviewNotes({});
        setNotice('');
        setError('');
      },
      onError: () => setError('The owner session could not be locked. Please try again.'),
    });
  };
  if (session.isLoading) return <div className="owner-page-standalone"><SafetyLoading /></div>;
  if (session.isError || !session.data) return <div className="owner-page-standalone"><SafetyError retry={() => session.refetch()} /></div>;
  if (!ownerAuthenticated) return <main className="safety-page owner-page-standalone">
    <div className="owner-login-top"><Link href="/" className="text-link" data-testid="link-owner-home"><ArrowRight size={15} /> Back to Bloxy</Link></div>
    <section className="safety-card owner-login-card">
      <span className="safety-seal"><LockKeyhole size={25} /></span>
      <div className="eyebrow">Private owner sign-in</div>
      <h1>Safety desk</h1>
      <p>Enter the owner passphrase to manage learner accounts and review submitted safety reports. This sign-in does not require a learner account.</p>
      <p className="safety-hint">Owner sessions lock automatically after one hour. Keep the passphrase private.</p>
      {loginError && <p className="safety-inline-error" role="alert" data-testid="text-owner-login-error">{loginError}</p>}
      <form className="owner-login-form" onSubmit={signIn} data-testid="form-owner-login">
        <label className="safety-field" htmlFor="owner-passphrase">Owner passphrase
          <input id="owner-passphrase" name="owner-passphrase" className="safety-input" type="password" value={passphrase} onChange={event => setPassphrase(event.target.value)} autoComplete="current-password" maxLength={256} required data-testid="input-owner-passphrase" />
        </label>
        <button className="button button-dark" type="submit" disabled={login.isPending} data-testid="button-owner-login">{login.isPending ? 'Checking…' : 'Unlock owner tools'}</button>
      </form>
    </section>
  </main>;
  return <main className="safety-page reveal owner-page-standalone">
    <header className="safety-hero"><div><div className="eyebrow">Owner workspace</div><h1>Safety desk</h1><p>Review accounts and reports with care. Names and age groups only—contact details are never part of this workspace.</p></div><button className="owner-action" type="button" onClick={lockOwnerSession} disabled={logout.isPending} data-testid="button-lock-owner-session">{logout.isPending ? 'Locking…' : 'Lock owner session'}</button></header>
    {notice && <div className="safety-success" role="status" data-testid="status-owner-success"><CheckCircle2 size={19} /><div><strong>{notice}</strong><button className="text-link" onClick={() => setNotice('')} data-testid="button-dismiss-owner-success"><X size={14} /> Dismiss</button></div></div>}
    {error && <p className="safety-inline-error" role="alert" data-testid="text-owner-error">{error}</p>}
    <div className="safety-toolbar"><h2>Registered accounts</h2><label style={{ position:'relative' }}><Search size={15} style={{ position:'absolute', left:11, top:13, color:'#87958a' }} /><input className="safety-search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search nicknames" aria-label="Search accounts by nickname" data-testid="input-owner-search" /></label></div>
    {userList.isLoading ? <div className="safety-card"><div className="skeleton skeleton-line" /><div className="skeleton skeleton-card" /></div> : userList.isError ? <SafetyError retry={() => userList.refetch()} /> : userList.data?.length ? <div className="owner-list">{userList.data.map(user => <article className="owner-row" key={user.id} data-testid={`row-owner-user-${user.id}`}><span className="owner-avatar"><UserRound size={19} /></span><div className="owner-main"><strong>{user.displayName}</strong><div className="owner-meta"><span>{user.ageGroup ? `${user.ageGroup[0].toUpperCase()}${user.ageGroup.slice(1)}` : 'Age group not set'}</span><span>Joined {dateLabel(user.createdAt)}</span><span className={`status-tag ${user.banned ? '' : 'done'}`}>{user.banned ? 'Restricted' : 'Active'}</span></div></div><div className="owner-actions">{user.banned ? <button className="owner-action" onClick={() => setActionTarget({ user, action:'unban' })} data-testid={`button-unban-${user.id}`}>Restore access</button> : <><button className="owner-action" onClick={() => setActionTarget({ user, action:'kick' })} data-testid={`button-kick-${user.id}`}>Kick</button><button className="owner-action danger" onClick={() => setActionTarget({ user, action:'ban' })} data-testid={`button-ban-${user.id}`}>Restrict</button></>}</div></article>)}</div> : <div className="empty-composed"><strong>No matching accounts</strong><p>Try a different nickname, or clear your search.</p></div>}
    <div className="safety-toolbar"><h2>Safety reports</h2><label className="safety-hint">Show <select className="safety-select" value={reportStatus} onChange={event => setReportStatus(event.target.value as SafetyReportStatus|'')} data-testid="select-report-status"><option value="">All reports</option>{Object.entries(statusTitles).map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select></label></div>
    {reportList.isLoading ? <div className="safety-card"><div className="skeleton skeleton-line" /><div className="skeleton skeleton-card" /></div> : reportList.isError ? <SafetyError retry={() => reportList.refetch()} /> : reportList.data?.length ? <div className="owner-layout">{reportList.data.map(report => <OwnerReportCard key={report.id} report={report} note={reviewNotes[report.id] ?? ''} onNote={value => setReviewNotes(current => ({ ...current, [report.id]:value }))} onReview={status => reviewReport(report,status)} pending={review.isPending} />)}</div> : <div className="empty-composed"><strong>No reports in this view</strong><p>Reports submitted by learners appear here for manual review.</p></div>}
    {actionTarget && <OwnerConfirmation user={actionTarget.user} action={actionTarget.action} onClose={() => setActionTarget(null)} onConfirm={confirmAction} pending={actPending} />}
  </main>;
}

function OwnerReportCard({ report, note, onNote, onReview, pending }: { report: OwnerSafetyReport; note: string; onNote: (value:string)=>void; onReview:(status:'action_taken'|'reviewed'|'dismissed')=>void; pending:boolean }) {
  return <article className="owner-report" data-testid={`card-owner-report-${report.id}`}>
    <div className="owner-report-head"><div><strong>{reasonTitles[report.reason]}</strong><div className="owner-meta"><span>Reported by {report.reporterName}</span><span>About {report.targetName}</span><span>{dateLabel(report.createdAt)}</span></div></div><span className={`status-tag ${report.status === 'pending' ? '' : 'done'}`}>{statusTitles[report.status]}</span></div>
    <div className="report-details">{report.details}</div>
    {report.evidence && <div className="report-evidence"><strong>Evidence submitted by reporter</strong><br />{report.evidence}</div>}
    {report.reviewNote && <p className="safety-hint">Review note: {report.reviewNote}</p>}
    {report.status === 'pending' && <><div className="review-controls"><textarea className="safety-input" value={note} onChange={event => onNote(event.target.value)} maxLength={500} placeholder="Optional internal review note" aria-label={`Review note for report ${report.id}`} data-testid={`input-review-note-${report.id}`} /><div className="owner-actions"><button className="owner-action danger" disabled={pending} onClick={() => onReview('dismissed')} data-testid={`button-dismiss-report-${report.id}`}>Dismiss</button><button className="owner-action" disabled={pending} onClick={() => onReview('reviewed')} data-testid={`button-mark-reviewed-${report.id}`}>Mark reviewed</button><button className="owner-action" disabled={pending} onClick={() => onReview('action_taken')} data-testid={`button-action-taken-${report.id}`}>Action taken</button></div></div><span className="safety-hint">Manual review only. Report contents do not automatically restrict an account.</span></>}
  </article>;
}
