import { useEffect, useMemo, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowRight, BookOpen, Brain, Check, ChevronRight, Clock3, Code2, Compass, Grid2X2, Lightbulb, Search, Sparkles, Target, WandSparkles, Zap } from 'lucide-react';
import { Link } from 'wouter';
import { miniGames, miniGameById, type MiniGameDefinition } from '@/data/mini-games';
import { getGetDashboardQueryKey, getGetShopQueryKey, useCompleteMaze, useGetDashboard, useStartMaze } from '@workspace/api-client-react';
import { BalanceGame, ColorMatch, CommandCoding, ConnectFour, Crossword, EscapeRoom, FishingSignal, LaneChallenge, LetterReveal, LogicPlacement, MiniSudoku, PaddleGame, PhysicsDrop, ReactionSignal, RhythmGame, ScienceLab, ShapeSort, SlidingPuzzle, SnakeGame, SpaceShooter, StepPlan, TicTacToe, TileHunt, TowerTiming, TypingTimer, VirtualChemistry, WordBuilder } from './GameModes';
import '../games-shop.css';

const categories = ['All games', ...Array.from(new Set(miniGames.map(game => game.category)))];
const icons = [Brain, Target, BookOpen, Zap, Compass, Grid2X2, Lightbulb, Code2, WandSparkles, Sparkles];
const gameIcon = (index: number) => icons[index % icons.length];

export function GamesPage() {
  const { data: dashboard, isLoading: dashboardLoading, isError: dashboardError } = useGetDashboard();
  const [category, setCategory] = useState('All games');
  const [search, setSearch] = useState('');
  const filtered = useMemo(() => miniGames.filter(game =>
    (category === 'All games' || game.category === category) &&
    `${game.title} ${game.category} ${game.instructions}`.toLowerCase().includes(search.trim().toLowerCase())
  ), [category, search]);

  return <div className="games-page">
    <section className="games-hero reveal">
      <div><div className="eyebrow">A pocket-sized playroom</div><h1>Pick a game.<br /><em>Find your flow.</em></h1><p>Quick little challenges for curious minds. Choose one that sounds fun and jump straight in—every game is ready to play.</p></div>
      <div className="games-count" aria-label="50 mini-games"><strong>{miniGames.length}</strong><span>MINI GAMES</span></div>
    </section>
    <div className="maze-eligibility" role="status" data-testid="status-maze-discount">
      <span className="eligibility-seal">M</span><span><strong>Maze Escape shop discount</strong><small>{dashboardLoading ? 'Checking your signed-in eligibility…' : dashboardError ? 'Eligibility could not be checked right now.' : dashboard?.profile.mazeDiscountEligible ? 'Verified and available on this account' : 'Complete a server-verified Maze Escape to check eligibility'}</small></span>
    </div>
    <div className="games-toolbar">
      <label className="game-search"><Search size={17} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Find a little challenge" aria-label="Search mini-games" data-testid="input-search-games" /><span className="sr-only">{filtered.length} games</span></label>
      <span className="game-stage-label">{filtered.length} ready to play</span>
    </div>
    <div className="games-category-row" role="group" aria-label="Filter games by category">
      {categories.map(item => <button key={item} type="button" className={`game-category ${category === item ? 'active' : ''}`} onClick={() => setCategory(item)} aria-pressed={category === item} data-testid={`filter-game-${item.toLowerCase().replaceAll(' ', '-')}`}>{item}</button>)}
    </div>
    {filtered.length ? <div className="mini-game-grid">{filtered.map(game => {
      const GameIcon = gameIcon(miniGames.indexOf(game));
      return <Link href={`/games/${encodeURIComponent(game.id)}`} className="mini-game-card" key={game.id} data-testid={`card-game-${game.id}`}>
        <div className="game-card-top"><span className="game-glyph"><GameIcon size={19} /></span><span className="game-card-index">{String(miniGames.indexOf(game) + 1).padStart(2, '0')} / 50</span></div>
        <span className="game-card-category">{game.category}</span><h2>{game.title}</h2><p>{game.instructions}</p>
        <div className="game-card-enter"><span><Clock3 size={13} /> A quick session</span><span>Play <ChevronRight size={15} /></span></div>
      </Link>;
    })}</div> : <div className="empty-state game-empty"><span className="empty-icon"><Search size={21} /></span><div><strong>No matches this time.</strong><p>Try a different title or switch to another category.</p></div><button className="text-link" onClick={() => { setSearch(''); setCategory('All games'); }} data-testid="button-reset-games">Show all games <ArrowRight size={15} /></button></div>}
  </div>;
}

type Prompt = { text: string; options: string[]; correctAnswer: number; detail?: string };
const quizPrompts: Prompt[] = [
  { text: 'Which shape has exactly three sides?', options: ['Triangle', 'Square', 'Circle', 'Hexagon'], correctAnswer: 0, detail: 'A triangle is made from three straight sides.' },
  { text: 'What do plants take in from the air?', options: ['Carbon dioxide', 'Helium', 'Steam', 'Sand'], correctAnswer: 0, detail: 'Plants use carbon dioxide, water, and light to grow.' },
  { text: 'Which number is even?', options: ['17', '21', '28', '35'], correctAnswer: 2, detail: 'Even numbers divide into two equal groups.' },
  { text: 'What is the largest ocean on Earth?', options: ['Pacific', 'Arctic', 'Indian', 'Southern'], correctAnswer: 0, detail: 'The Pacific Ocean is the largest of Earth’s oceans.' },
  { text: 'Which instruction repeats a set of steps in code?', options: ['Loop', 'Label', 'Color', 'Pause'], correctAnswer: 0, detail: 'A loop repeats instructions without rewriting each step.' },
  { text: 'Which habitat is naturally very dry?', options: ['Desert', 'Reef', 'Wetland', 'Rainforest'], correctAnswer: 0, detail: 'Deserts receive very little rainfall.' },
];
const sciencePrompts: Prompt[] = [
  { text: 'What force pulls objects toward Earth?', options: ['Gravity', 'Sound', 'Magnetism', 'Friction'], correctAnswer: 0, detail: 'Gravity pulls objects toward the center of Earth.' },
  { text: 'Which part of a plant takes in most water?', options: ['Roots', 'Petals', 'Fruit', 'Stem tip'], correctAnswer: 0, detail: 'Roots absorb water from the soil.' },
  { text: 'What is the closest star to Earth?', options: ['The Sun', 'Sirius', 'Polaris', 'Vega'], correctAnswer: 0, detail: 'Our Sun is the nearest star.' },
];
const riddlePrompts: Prompt[] = [
  { text: 'I have hands but cannot clap. What am I?', options: ['A clock', 'A tree', 'A book', 'A chair'], correctAnswer: 0 },
  { text: 'I get wetter as I dry. What am I?', options: ['A towel', 'A cloud', 'A sponge', 'A river'], correctAnswer: 0 },
  { text: 'I have a face and two hands, but no arms or legs.', options: ['A clock', 'A doll', 'A map', 'A mirror'], correctAnswer: 0 },
];
const cheerfulQuestion: Prompt = {
  text: 'Which word is closest to cheerful?',
  options: ['Glad', 'Angry', 'Sleepy'],
  correctAnswer: 0,
  detail: 'Glad is a synonym for happy and cheerful.',
};
const triviaPrompts = [cheerfulQuestion, ...quizPrompts];
const wordRounds = [
  { clue: 'A bright object in the daytime sky', answer: 'sun' },
  { clue: 'A shape with four equal sides', answer: 'square' },
  { clue: 'A young plant beginning to grow', answer: 'seedling' },
];
const memoryPairs = [['Moon', 'Orbit'], ['Seed', 'Sprout'], ['Code', 'Pattern']];
const pairs = [...memoryPairs.flatMap(pair => pair), ...memoryPairs.flatMap(pair => pair)].sort((a,b) => a.length - b.length || a.localeCompare(b));
const typingLine = 'Curiosity grows one small question at a time.';

function Completion({ score, total, restart }: { score: number; total: number; restart: () => void }) {
  return <div className="game-complete" role="status"><span className="game-complete-mark"><Check size={25} /></span><h2>Nicely done.</h2><p>Your practice round is complete: {score} of {total} points. This is a local practice result and does not award coins or change your Bloxy Points.</p><div className="game-action-row"><button className="game-action" onClick={restart} data-testid="button-play-again">Play another round <ArrowRight size={15} /></button></div></div>;
}

function LocalGame({ game }: { game: MiniGameDefinition }) {
  const [round, setRound] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState('');
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState('');
  const [done, setDone] = useState(false);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [turns, setTurns] = useState(0);
  const [cells, setCells] = useState<number[]>([]);
  const [board, setBoard] = useState<string[]>(Array(game.variant === 'connect-four' ? 16 : 9).fill(''));
  const [drawn, setDrawn] = useState<number[]>([]);
  const [moves, setMoves] = useState<string[]>([]);
  const finish = (points = score, total = 3) => { setScore(points); setDone(true); };
  const restart = () => { setRound(0); setScore(0); setSelected(''); setAnswer(''); setFeedback(''); setDone(false); setFlipped([]); setMatched([]); setTurns(0); setCells([]); setBoard(Array(game.variant === 'connect-four' ? 16 : 9).fill('')); setDrawn([]); setMoves([]); };
  const nextPrompt = (correct: boolean) => {
    const nextScore = score + (correct ? 1 : 0);
    setScore(nextScore); setSelected(''); setAnswer('');
    if (round >= 2) finish(nextScore);
    else { setRound(round + 1); setFeedback(correct ? 'That’s it. On to the next one.' : 'Good try. Take the next clue with you.'); }
  };

  if (done) return <Completion score={score} total={game.mechanic === 'memory' ? 3 : game.mechanic === 'typing' ? 1 : 3} restart={restart} />;

  if (game.mechanic === 'memory') {
    const patternMode = game.variant === 'pattern' || game.variant === 'sequence';
    const target = patternMode ? [0, 3, 5] : [];
    const cards = game.variant === 'biology' ? ['Bee','Flower','Fish','Water','Bird','Nest','Nest','Bird','Water','Fish','Flower','Bee'] : pairs;
    const toggleCard = (index: number) => {
      if (matched.includes(index) || flipped.includes(index) || flipped.length === 2) return;
      const now = [...flipped, index]; setFlipped(now);
      if (now.length === 2) {
        setTurns(turns + 1);
        if (patternMode ? target.includes(now[0]) === target.includes(now[1]) : cards[now[0]] === cards[now[1]]) {
          const nextMatched = patternMode ? [...new Set([...matched, ...now])] : [...matched, ...now];
          setMatched(nextMatched);
          if (patternMode ? nextMatched.length >= 6 : nextMatched.length === cards.length) { setScore(Math.max(0, 3 - Math.floor(turns / 4))); setDone(true); }
          window.setTimeout(() => setFlipped([]), 450);
        } else window.setTimeout(() => setFlipped([]), 750);
      }
    };
    return <><p className="game-prompt">{patternMode ? 'Remember the marked tiles, then find them again.' : 'Turn over two cards and find the matching pair.'}</p><p className="game-subprompt">{patternMode ? 'Build the pattern from memory.' : `${matched.length / 2} of ${cards.length / 2} pairs found · ${turns} turns`}</p><div className="game-board" style={{ gridTemplateColumns: 'repeat(4,minmax(0,1fr))' }}>{cards.map((card, index) => {
      const selectedPath = moves.filter(value => value !== 'started').map(Number);
      const shown = flipped.includes(index) || matched.includes(index) || (patternMode && ((!moves.includes('started') && target.includes(index)) || selectedPath.includes(index)));
      return <button type="button" key={`${card}-${index}`} className={`game-cell ${shown ? 'active' : ''} ${matched.includes(index) ? 'found' : ''}`} onClick={() => {
        if (!patternMode) { toggleCard(index); return; }
        if (!moves.includes('started')) { setMoves(['started']); return; }
        if (selectedPath.includes(index)) return;
        const nextPath = [...selectedPath, index];
        setMoves(['started', ...nextPath.map(String)]);
        if (nextPath.length === target.length) {
          const isCorrect = nextPath.every((value, position) => value === target[position]);
          setScore(isCorrect ? 3 : nextPath.filter(value => target.includes(value)).length);
          setDone(true);
        }
      }} aria-label={shown ? (patternMode ? `Selected tile ${index + 1}` : card) : `Hidden tile ${index + 1}`} data-testid={`memory-card-${index}`}>{shown ? (patternMode ? '•' : card) : '?'}</button>;
    })}</div>{patternMode && <p className="game-feedback">{moves.includes('started') ? `${moves.length - 1} of ${target.length} path tiles chosen.` : 'Study the highlighted path, then tap any tile to begin.'}</p>}</>;
  }

  if (game.mechanic === 'words' && game.variant !== 'letter-reveal' && game.variant !== 'crossword' && game.variant !== 'build') {
    const word = wordRounds[round % wordRounds.length];
    const scramble = word.answer.split('').sort((a,b) => (a.charCodeAt(0) * (round + 3) % 7) - (b.charCodeAt(0) * (round + 3) % 7)).join(' ');
    return <form onSubmit={event => { event.preventDefault(); const correct = answer.trim().toLowerCase() === word.answer; setFeedback(correct ? 'Exactly right.' : `Not quite. Hint: ${word.answer.length} letters.`); if (correct) nextPrompt(true); }}><p className="game-prompt">{game.variant === 'scramble' ? `Unscramble: ${scramble}` : word.clue}</p><p className="game-subprompt">Round {round + 1} of 3 · {game.instructions}</p><input className="game-input" autoComplete="off" value={answer} onChange={event => setAnswer(event.target.value)} placeholder="Type your answer" aria-label="Your answer" data-testid="input-game-answer" /><div className="game-action-row"><button className="game-action" type="submit">Check word <ArrowRight size={15} /></button><button type="button" className="game-action secondary" onClick={() => nextPrompt(false)}>Skip this clue</button></div><p className="game-feedback">{feedback}</p></form>;
  }

  if (game.mechanic === 'typing') return <><p className="game-prompt">Copy the line exactly, at your own pace.</p><p className="game-subprompt">Accuracy first. Speed comes after.</p><div className="game-prompt" style={{ fontSize: 17, fontFamily: 'var(--app-font-mono)' }}>{typingLine}</div><input className="game-input" value={answer} onChange={event => setAnswer(event.target.value)} placeholder="Start typing the line" aria-label="Type the displayed line" data-testid="input-typing-line" /><div className="game-action-row"><button className="game-action" onClick={() => { if (answer.trim() === typingLine) finish(1,1); else setFeedback('Check the sentence for a missing letter or space.'); }}>Finish line <Check size={15} /></button></div><p className="game-feedback">{feedback}</p></>;

  if (game.mechanic === 'creative') return <><p className="game-prompt">Sketch a tiny scene: a sun, a hill, and something growing.</p><p className="game-subprompt">Tap the canvas to add marks. Make it your own.</p><div className="game-board" style={{ gridTemplateColumns: 'repeat(5,minmax(0,1fr))', width: 'min(330px,100%)' }}>{Array.from({ length: 25 }, (_, index) => <button className={`game-cell ${drawn.includes(index) ? 'active' : ''}`} key={index} onClick={() => setDrawn(current => current.includes(index) ? current : [...current,index])} aria-label={`Canvas square ${index + 1}`} data-testid={`drawing-cell-${index}`}>{drawn.includes(index) ? '•' : ''}</button>)}</div><div className="game-action-row"><button className="game-action" onClick={() => finish(Math.min(3,Math.floor(drawn.length / 2)),3)} disabled={drawn.length < 3}>Save sketch <Check size={15} /></button><button className="game-action secondary" onClick={() => setDrawn([])}>Clear canvas</button></div><p className="game-feedback">{drawn.length} marks on your canvas</p></>;

  if (game.mechanic === 'board') {
    const size = game.variant === 'connect-four' ? 4 : 3;
    const checkLine = (cells: string[], mark: string) => {
      for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
        for (const [dx,dy] of [[1,0],[0,1],[1,1],[-1,1]]) {
          if (Array.from({length:size},(_,step) => cells[(y + dy * step) * size + x + dx * step]).every(value => value === mark)) return true;
        }
      }
      return false;
    };
    return <><p className="game-prompt">{game.variant === 'connect-four' ? 'Take turns with the computer and line up four marks.' : 'Take turns with the computer and line up three marks.'}</p><div className="game-board" style={{ gridTemplateColumns: `repeat(${size},minmax(0,1fr))`, maxWidth: size === 4 ? 340 : 300 }}>{board.map((mark, index) => <button key={index} className={`game-cell ${mark ? 'active' : ''}`} onClick={() => {
      if (board[index] || done) return;
      const next = [...board]; next[index] = 'You';
      if (checkLine(next, 'You')) { setBoard(next); finish(3); return; }
      const free = next.map((value,i) => value ? -1 : i).filter(i => i >= 0);
      if (!free.length) { setBoard(next); finish(score); return; }
      const computerIndex = free[(round + index) % free.length];
      next[computerIndex] = 'Computer'; setBoard(next); setRound(round + 1);
      if (checkLine(next, 'Computer') || next.every(Boolean)) finish(score);
      else setScore(score + 1);
    }} aria-label={`Board square ${index + 1} ${mark || 'empty'}`} data-testid={`board-cell-${index}`}>{mark === 'You' ? 'X' : mark ? 'O' : ''}</button>)}</div><p className="game-feedback">You: X · Computer: O · Choose an open square.</p><div className="game-action-row"><button className="game-action secondary" onClick={() => finish(score)}>End practice round</button></div></>;
  }

  if (game.mechanic === 'grid') {
    const goalSet = game.variant === 'spot-difference' ? [1,5,10] : game.variant === 'shape-sort' ? [0,3,6] : game.variant === 'number-hunt' ? [0,1,2] : game.variant === 'sliding' ? [0,1,2,3,4,5,6,7] : [2,4,6];
    const label = game.variant === 'sudoku' ? ['1','2','3','4','3','4','1','2','2','1','4','3','4','3','2','1'] : game.variant === 'number-hunt' ? ['2','4','6','8','3','5','7','1','9','2','4','6','5','8','3','7'] : ['○','□','△','○','△','□','○','□','△','□','○','△','△','○','□','△'];
    return <><p className="game-prompt">{game.variant === 'spot-difference' ? 'Tap the three tiles that break the pattern.' : game.variant === 'sliding' ? 'Tap numbered tiles in ascending order.' : game.variant === 'sudoku' ? 'Select the tiles marked with the number 4.' : 'Find the three triangles and tap them.'}</p><p className="game-subprompt">A small visual puzzle · {cells.length} selected</p><div className="game-board" style={{ gridTemplateColumns: 'repeat(4,minmax(0,1fr))' }}>{label.map((value,index) => <button key={index} className={`game-cell ${cells.includes(index) ? 'active' : ''}`} onClick={() => {
      if (cells.includes(index)) return;
      const next = [...cells,index]; setCells(next);
      const correct = game.variant === 'sudoku' ? value === '4' : game.variant === 'number-hunt' ? ['2','4','6'].includes(value) && goalSet.includes(index) : game.variant === 'sliding' ? value === String(next.length) : game.variant === 'shape-sort' ? value === '△' : goalSet.includes(index);
      if (correct) setScore(score + 1);
      if ((game.variant === 'sliding' ? next.length >= 8 : next.length >= 5) || (game.variant !== 'sliding' && score + (correct ? 1:0) >= 3)) finish(score + (correct ? 1:0),3);
    }} data-testid={`grid-cell-${index}`}>{game.variant === 'sliding' ? value : value}</button>)}</div><div className="game-action-row"><button className="game-action secondary" onClick={() => finish(score,3)}>Finish this puzzle</button></div><p className="game-feedback">Look carefully, then choose a tile.</p></>;
  }

  if (game.mechanic === 'adventure') return <><p className="game-prompt">{game.variant === 'treasure-grid' ? 'A treasure is hidden behind the compass, the map, and the key.' : game.variant === 'escape-room' ? 'The room has a locked cabinet, a window, and a notebook.' : 'The path splits at a river. How will you continue?'}</p><p className="game-subprompt">{game.instructions}</p><div className="game-options">{['Inspect the clue', 'Follow the safe path', 'Check the map', 'Gather the useful item'].map(option => <button key={option} className={`game-option ${selected === option ? 'selected' : ''}`} onClick={() => setSelected(option)}>{option}</button>)}</div><div className="game-action-row"><button className="game-action" disabled={!selected} onClick={() => { setScore(score + 1); if (round >= 2) finish(score + 1); else { setRound(round + 1); setSelected(''); setFeedback('Good thinking. Another clue appears ahead.'); } }}>Choose this path <ArrowRight size={15} /></button></div><p className="game-feedback">{feedback || `Chapter ${round + 1} of 3`}</p></>;

  if (game.mechanic === 'builder') return <><p className="game-prompt">{game.variant === 'virtual-recipe' ? 'Build a no-heat virtual snack in a sensible order.' : game.variant === 'farm' ? 'Plan a small virtual garden for a sunny day.' : 'Stack each block carefully to keep your tower steady.'}</p><p className="game-subprompt">Choose one step at a time. This is a fictional screen activity only.</p><div className="game-options">{(game.variant === 'virtual-recipe' ? ['Choose a plate', 'Add fruit pieces', 'Place crackers', 'Finish the arrangement'] : game.variant === 'farm' ? ['Choose a sunny plot', 'Plant virtual seeds', 'Water the garden', 'Harvest the crops'] : ['Set the base', 'Watch the marker', 'Drop the block', 'Balance the top']).map((step,index) => <button key={step} className={`game-option ${moves.includes(step) ? 'selected' : ''}`} onClick={() => { if (moves.includes(step)) return; const next = [...moves,step]; setMoves(next); setScore(score + 1); if (next.length >= 4) finish(Math.min(3,score + 1),3); }}>{String(index + 1).padStart(2,'0')} &nbsp; {step}</button>)}</div><p className="game-feedback">{moves.length} of 4 steps complete</p></>;

  if (game.mechanic === 'reflex' || game.mechanic === 'arcade') return <><p className="game-prompt">{game.variant === 'reaction' ? 'Wait for the signal, then catch a green target.' : game.variant === 'fishing' ? 'Cast, watch the water, and reel in when the signal appears.' : game.variant === 'color-match' ? 'Choose the color named by the target.' : game.variant === 'balance' ? 'Keep the marker near the center by choosing the lighter side.' : game.instructions}</p><p className="game-subprompt">Tap the right choice to build your run · {round} of 5 moves</p><div className="game-options">{(game.variant === 'color-match' ? ['Amber','Leaf','Coral','Sky'] : game.variant === 'balance' ? ['Left','Steady','Right','Steady'] : game.variant === 'fishing' ? ['Reel in','Wait','Cast again','Wait'] : ['Move left','Stay centered','Move right','Jump']).map((option,index) => <button className={`game-option ${selected === option ? 'selected' : ''}`} key={`${option}-${index}`} onClick={() => {
    const rightChoice = game.variant === 'color-match' ? option === ['Coral','Leaf','Amber','Sky'][round % 4] : game.variant === 'balance' ? option === 'Steady' : game.variant === 'fishing' ? (round % 2 === 1 ? option === 'Reel in' : option === 'Wait') : index === (round % 4);
    const nextRound = round + 1; const nextScore = score + (rightChoice ? 1 : 0);
    setScore(nextScore); setRound(nextRound); setSelected(''); setFeedback(rightChoice ? 'Nice timing.' : 'Keep going; the next signal is yours.');
    if (nextRound >= 5) finish(nextScore);
  }}>{option}</button>)}</div><p className="game-feedback">{feedback}</p></>;

  const prompt = game.mechanic === 'science'
    ? game.variant === 'coding' ? 'Arrange the instructions to guide a character to the goal.' : game.variant === 'chemistry' ? 'Select only the safe virtual ingredients for a color-changing mix.' : game.variant === 'physics' ? 'Choose a drop point that lands the object in the target.' : 'Choose a safe tool that helps observe a tiny detail.'
    : game.mechanic === 'math' ? game.variant === 'number-hunt' ? 'Find the three numbers that add up to 12.' : `What is ${[4,7,9][round % 3]} + ${[3,5,6][round % 3]}?`
    : game.variant === 'letter-reveal' ? 'Guess a letter in the hidden word: PLANET.' : game.variant === 'build' ? 'Choose letters to build the word that means a young plant.' : 'Choose the best answer for this quick question.';
  const options = game.mechanic === 'math' ? ['7','9','12','15'] : game.mechanic === 'science' ? game.variant === 'coding' ? ['Move forward','Turn left','Collect star','Repeat 2'] : ['Safety glasses','Virtual magnifier','Notebook','Toy beaker'] : game.variant === 'letter-reveal' ? ['A','E','I','O','U','N','P','T'] : game.variant === 'build' ? ['S','E','E','D','L','I','N','G'] : quizPrompts.map((_, i) => quizPrompts[(round + i) % quizPrompts.length].options[0]);
  const activeQuiz = game.id === 'science-quiz' ? sciencePrompts : game.id === 'riddle-solver' ? riddlePrompts : game.id === 'trivia-quiz' ? triviaPrompts : quizPrompts;
  const promptItem = activeQuiz[round % activeQuiz.length];
  const optionsNow = game.mechanic === 'quiz' ? promptItem.options : options;
  const expected = game.mechanic === 'math' ? ['7','12','15'][round % 3] : game.mechanic === 'science' ? (game.variant === 'coding' ? ['Move forward','Turn left','Collect star','Repeat 2'][round % 4] : ['Safety glasses','Virtual magnifier','Notebook'][round % 3]) : game.variant === 'letter-reveal' ? 'A' : 'S';
  const checkAnswer = (selectedIndex: number) => selectedIndex === promptItem.correctAnswer ? "✅ That's right!" : '❌ Try again!';
  const submitAnswer = () => {
    if (game.mechanic !== 'quiz') {
      nextPrompt(selected === expected);
      return;
    }
    const result = checkAnswer(optionsNow.indexOf(selected));
    setFeedback(result);
    if (result !== "✅ That's right!") return;
    const nextScore = score + 1;
    setScore(nextScore);
    setSelected('');
    if (round >= 2) finish(nextScore);
    else setRound(round + 1);
  };
  return <><p className="game-prompt">{game.mechanic === 'quiz' ? promptItem.text : prompt}</p><p className="game-subprompt">{game.mechanic === 'quiz' ? promptItem.detail || game.instructions : game.instructions}</p><div className="game-options">{optionsNow.map((option,index) => <button type="button" key={`${option}-${index}`} className={`game-option ${selected === option ? 'selected' : ''}`} onClick={() => { setSelected(option); setFeedback(''); }}>{option}</button>)}</div><div className="game-action-row"><button type="button" className="game-action" disabled={!selected} onClick={submitAnswer}>{round === 2 ? 'Finish round' : 'Check answer'} <ArrowRight size={15} /></button></div><p className="game-feedback" role="status">{feedback || `Round ${round + 1} of 3`}</p></>;
}

type MazeMove = 'up' | 'down' | 'left' | 'right';
const moveDelta: Record<MazeMove, {x:number;y:number}> = { up: {x:0,y:-1}, down: {x:0,y:1}, left: {x:-1,y:0}, right: {x:1,y:0} };

function MazeGame() {
  const queryClient = useQueryClient();
  const startMaze = useStartMaze();
  const completeMaze = useCompleteMaze();
  const [maze, setMaze] = useState<Awaited<ReturnType<typeof startMaze.mutateAsync>> | null>(null);
  const [position, setPosition] = useState<{x:number;y:number} | null>(null);
  const [moves, setMoves] = useState<MazeMove[]>([]);
  const [result, setResult] = useState<{coinsAwarded:number;alreadyCompleted:boolean;discountEligible:boolean} | null>(null);
  const [message, setMessage] = useState('');
  const moveAction = useRef<(direction: MazeMove) => void>(() => undefined);
  const start = () => {
    setMessage(''); setResult(null); setMaze(null); setMoves([]);
    startMaze.mutate(undefined, { onSuccess: challenge => { setMaze(challenge); setPosition(challenge.start); }, onError: () => setMessage('The maze could not be opened. Please try again.') });
  };
  const move = (direction: MazeMove) => {
    if (!maze || !position || result || completeMaze.isPending) return;
    const delta = moveDelta[direction], next = { x: position.x + delta.x, y: position.y + delta.y };
    if (next.x < 0 || next.y < 0 || next.x >= maze.width || next.y >= maze.height) return;
    const row = maze.grid[next.y] ?? '';
    const cell = row[next.x] ?? '#';
    if (cell === '#' || cell === '1' || cell === 'W') return;
    const nextMoves = [...moves, direction]; setMoves(nextMoves); setPosition(next);
    if (next.x === maze.exit.x && next.y === maze.exit.y) completeMaze.mutate({ data: { runId: maze.runId, moves: nextMoves } }, {
      onSuccess: response => { setResult(response); setMessage(response.alreadyCompleted ? 'This maze run was already completed.' : `Maze complete. ${response.coinsAwarded} coins added to your account.`); queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetShopQueryKey() }); },
      onError: () => setMessage('Your route is safe, but completion could not be saved. Retry the completion.'),
    });
  };
  moveAction.current = move;
  const retryComplete = () => { if (maze) completeMaze.mutate({ data: { runId: maze.runId, moves } }, { onSuccess: response => { setResult(response); setMessage(`Maze complete. ${response.coinsAwarded} coins added to your account.`); queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetShopQueryKey() }); }, onError: () => setMessage('Still unable to save this run. Try again in a moment.') }); };
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const direction: Record<string, MazeMove> = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
      const next = direction[event.key];
      if (next) { event.preventDefault(); moveAction.current(next); }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);
  const keys: MazeMove[] = ['up','left','down','right'];
  return <div>
    {!maze ? <div className="game-complete" style={{ marginTop: 54 }}><span className="game-complete-mark"><Compass size={25} /></span><h2>Ready for the maze?</h2><p>This challenge is powered by your Bloxy account. Reaching the exit submits your route to the server for verification.</p><div className="game-action-row"><button className="game-action" onClick={start} disabled={startMaze.isPending} data-testid="button-start-maze">{startMaze.isPending ? 'Opening maze…' : 'Start a maze'} <ArrowRight size={15} /></button></div>{startMaze.isError && <p className="game-feedback error">We couldn’t start a maze. Try again.</p>}</div> :
      result ? <div className="game-complete" role="status"><span className="game-complete-mark"><Check size={25} /></span><h2>Exit found.</h2><p>{message} {result.discountEligible && 'Your account is eligible for the maze shop discount.'}</p><div className="game-action-row"><button className="game-action" onClick={start} disabled={startMaze.isPending}>Try another maze <ArrowRight size={15} /></button></div></div> :
      <>
        <p className="game-prompt">Find your way to the marked exit.</p><p className="game-subprompt">Use arrow keys or direction controls · {moves.length} moves</p>
        <div className="maze-grid" style={{ gridTemplateColumns: `repeat(${maze.width}, minmax(0,1fr))` }}>{Array.from({length: maze.width * maze.height}, (_, index) => {
          const x=index % maze.width, y=Math.floor(index / maze.width), row=maze.grid[y] ?? '', value=row[x] ?? '#';
          const isWall = value === '#' || value === '1' || value === 'W';
          const isHere = position?.x === x && position.y === y;
          const isExit = maze.exit.x === x && maze.exit.y === y;
          return <div key={`${x}-${y}`} className={`maze-cell ${isWall ? 'wall' : 'path'} ${isHere ? 'player' : ''} ${isExit ? 'exit' : ''}`} aria-label={isHere ? 'Your position' : isExit ? 'Exit' : isWall ? 'Wall' : 'Path'}>{isHere ? '•' : isExit ? 'E' : ''}</div>;
        })}</div>
        <div className="maze-controls">{keys.map(direction => <button type="button" key={direction} onClick={() => move(direction)} aria-label={`Move ${direction}`} data-testid={`maze-move-${direction}`}>{direction === 'up' ? '↑' : direction === 'down' ? '↓' : direction === 'left' ? '←' : '→'}</button>)}</div>
        <p className={`game-feedback ${message ? 'error' : ''}`} role={message ? 'alert' : 'status'}>{completeMaze.isPending ? 'Checking your route…' : message || 'Walls stop your path. Keep exploring.'}</p>
        {completeMaze.isError && <div className="game-action-row"><button className="game-action secondary" onClick={retryComplete}>Retry saving route</button></div>}
      </>}
    <p className="game-disclaimer">Maze rewards are verified by Bloxy. This is the only mini-game that changes your account coins.</p>
  </div>;
}

export function MiniGamePage({ params }: { params: { gameId?: string } }) {
  const id = params.gameId ?? '';
  const game = miniGameById.get(decodeURIComponent(id));
  const { data: dashboard, isLoading: dashboardLoading, isError: dashboardError } = useGetDashboard();
  if (!game) return <div className="empty-state"><span className="empty-icon"><BookOpen size={22} /></span><div><strong>That game slipped out of the list.</strong><p>Choose a mini-game from the library to begin.</p></div><Link href="/games" className="text-link">Back to all games <ArrowRight size={15} /></Link></div>;
  const Icon = gameIcon(miniGames.indexOf(game));
  return <div className="mini-game-page reveal">
    <div className="mini-game-heading"><Link href="/games" className="back-to-games" aria-label="Back to games" data-testid="link-back-games"><ArrowRight size={18} style={{ transform: 'rotate(180deg)' }} /></Link><div><div className="eyebrow">{game.category} / QUICK PLAY</div><h1>{game.title}</h1><p>{game.instructions}</p></div><span className="game-glyph" style={{ marginLeft: 'auto' }}><Icon size={20} /></span></div>
    <div className="maze-eligibility" role="status" data-testid="status-maze-discount">
      <span className="eligibility-seal">M</span><span><strong>Maze Escape discount eligibility</strong><small>{dashboardLoading ? 'Checking your signed-in profile…' : dashboardError ? 'Profile eligibility could not be checked right now.' : dashboard?.profile.mazeDiscountEligible ? 'Verified eligible on this account' : 'Not yet eligible — finish a verified Maze Escape to qualify'}</small></span>
    </div>
    <section className="game-stage"><div className="game-stage-head"><span className="game-stage-label">A little practice session</span><span className="game-stage-score"><Sparkles size={13} /> {game.mechanic === 'maze' ? 'SERVER VERIFIED' : 'LOCAL PLAY'}</span></div>{game.mechanic === 'maze' ? <MazeGame key={game.id} /> : <GameBehavior key={game.id} game={game} />}</section>
    {game.mechanic !== 'maze' && <p className="game-disclaimer">Practice progress stays in this session. Mini-games do not award coins or affect Bloxy Points or leaderboard standings.</p>}
  </div>;
}

function GameBehavior({ game }: { game: MiniGameDefinition }) {
  switch (game.id) {
    case 'typing-speed': return <TypingTimer />;
    case 'reaction-test': return <ReactionSignal />;
    case 'color-match': return <ColorMatch />;
    case 'sudoku': return <MiniSudoku />;
    case 'puzzle-slider': return <SlidingPuzzle />;
    case 'connect-four': return <ConnectFour />;
    case 'tic-tac-toe': return <TicTacToe />;
    case 'snake-game': return <SnakeGame />;
    case 'hangman': return <LetterReveal />;
    case 'word-builder': return <WordBuilder />;
    case 'crossword': return <Crossword />;
    case 'music-rhythm': return <RhythmGame />;
    case 'balance-game': return <BalanceGame />;
    case 'escape-room': return <EscapeRoom />;
    case 'logic-puzzle': return <LogicPlacement />;
    case 'shape-sorter': return <ShapeSort />;
    case 'treasure-hunt':
    case 'number-hunt':
    case 'spot-the-difference': return <TileHunt game={game} />;
    case 'coding-challenge': return <CommandCoding />;
    case 'chemistry-mix': return <VirtualChemistry />;
    case 'physics-drop': return <PhysicsDrop />;
    case 'fishing-game': return <FishingSignal />;
    case 'space-shooter': return <SpaceShooter />;
    case 'catch-falling-object':
    case 'platform-runner':
    case 'car-racing':
    case 'jumping-game':
    case 'obstacle-course': return <LaneChallenge game={game} />;
    case 'ball-bounce':
    case 'brick-breaker': return <PaddleGame game={game} />;
    case 'tower-builder': return <TowerTiming />;
    case 'cooking-simulator':
    case 'farm-builder': return <StepPlan game={game} />;
    case 'science-lab-puzzle': return <ScienceLab />;
    default: return <LocalGame game={game} />;
  }
}
