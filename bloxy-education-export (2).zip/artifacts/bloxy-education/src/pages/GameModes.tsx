import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Check, RotateCcw, Timer } from 'lucide-react';
import type { MiniGameDefinition } from '@/data/mini-games';

function Done({ score, total, replay }: { score: number; total: number; replay: () => void }) {
  return <div className="game-complete" role="status"><span className="game-complete-mark"><Check size={24} /></span><h2>Round complete.</h2><p>Practice result: {score} of {total}. It stays local and does not change coins, points, or leaderboard standings.</p><div className="game-action-row"><button className="game-action" onClick={replay}>Play again <RotateCcw size={14} /></button></div></div>;
}

export function TypingTimer() {
  const sentence = 'Curiosity grows one small question at a time.';
  const [value, setValue] = useState('');
  const [seconds, setSeconds] = useState(30);
  const [started, setStarted] = useState(false);
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (!started || done) return;
    const timer = window.setInterval(() => setSeconds(current => {
      if (current <= 1) { window.clearInterval(timer); setDone(true); return 0; }
      return current - 1;
    }), 1000);
    return () => window.clearInterval(timer);
  }, [started, done]);
  const accuracy = Math.round((value.split('').filter((char,index) => char === sentence[index]).length / Math.max(value.length,1)) * 100);
  if (done) return <Done score={accuracy} total={100} replay={() => { setValue(''); setSeconds(30); setStarted(false); setDone(false); }} />;
  return <><p className="game-prompt">Type the line accurately before the timer ends.</p><p className="game-subprompt">Every character counts. You have 30 seconds.</p><div className="game-prompt" style={{ font: '600 17px/1.6 var(--app-font-mono)' }}>{sentence}</div><div className="game-stage-head"><span className="game-stage-label">Accuracy {accuracy}%</span><span className="game-stage-score"><Timer size={14} /> {seconds}s</span></div><input className="game-input" autoFocus value={value} onChange={event => { setStarted(true); setValue(event.target.value.slice(0,sentence.length)); if (event.target.value === sentence) setDone(true); }} placeholder="Start typing here" aria-label="Type the displayed line" data-testid="input-typing-line" /><p className="game-feedback">The clock starts with your first key. Match spaces and punctuation too.</p></>;
}

export function ReactionSignal() {
  const [state, setState] = useState<'ready'|'waiting'|'signal'|'false-start'|'done'>('ready');
  const [times, setTimes] = useState<number[]>([]);
  const timer = useRef<number | null>(null);
  const startedAt = useRef(0);
  useEffect(() => () => { if (timer.current !== null) window.clearTimeout(timer.current); }, []);
  const begin = () => {
    if (timer.current !== null) window.clearTimeout(timer.current);
    setState('waiting');
    timer.current = window.setTimeout(() => { startedAt.current = performance.now(); setState('signal'); }, 1300 + Math.random() * 2000);
  };
  const tap = () => {
    if (state === 'waiting') { if (timer.current !== null) window.clearTimeout(timer.current); setState('false-start'); return; }
    if (state === 'signal') {
      const next = [...times, Math.round(performance.now() - startedAt.current)];
      setTimes(next); setState(next.length === 3 ? 'done' : 'ready');
    }
  };
  if (state === 'done') return <Done score={Math.max(0,1000 - Math.round(times.reduce((a,b)=>a+b,0) / times.length))} total={1000} replay={() => { setTimes([]); setState('ready'); }} />;
  return <><p className="game-prompt">Wait for the signal. Tap only when the field turns citrus.</p><p className="game-subprompt">Three rounds · false starts mean a fresh try</p><button className="game-action" style={{ display:'flex', width:'min(440px,100%)', height:175, margin:'20px auto', justifyContent:'center', borderRadius:22, fontSize:20, background:state === 'signal' ? '#e8bd52' : state === 'waiting' ? '#315f52' : '#e6ecdc', color:state === 'signal' ? '#24483f' : state === 'waiting' ? '#fff6df' : '#315f52' }} onClick={tap} data-testid="button-reaction-signal">{state === 'signal' ? 'TAP NOW' : state === 'waiting' ? 'Wait for it…' : state === 'false-start' ? 'Too early. Try again.' : 'Ready when you are'}</button>{state !== 'waiting' && state !== 'signal' && <div className="game-action-row"><button className="game-action" onClick={begin}>Start round {times.length + 1} <ArrowRight size={14} /></button></div>}<p className="game-feedback">{times.length ? `Your reaction times: ${times.join(' ms · ')} ms` : 'The signal changes after a short, unpredictable pause.'}</p></>;
}

const sudokuSolution = ['1','2','3','4','3','4','1','2','2','1','4','3','4','3','2','1'];
const sudokuClues = ['1','','3','','','4','','2','2','','4','','','3','','1'];
export function MiniSudoku() {
  const [board, setBoard] = useState(sudokuClues);
  const [active, setActive] = useState<number | null>(null);
  const [message, setMessage] = useState('');
  const [done, setDone] = useState(false);
  const invalid = (index: number, value: string) => {
    const row = Math.floor(index / 4), column = index % 4, boxRow = Math.floor(row / 2), boxColumn = Math.floor(column / 2);
    return board.some((cell, other) => {
      if (cell !== value || other === index) return false;
      const otherRow = Math.floor(other / 4), otherColumn = other % 4;
      return otherRow === row || otherColumn === column || (Math.floor(otherRow / 2) === boxRow && Math.floor(otherColumn / 2) === boxColumn);
    });
  };
  if (done) return <Done score={4} total={4} replay={() => { setBoard(sudokuClues); setActive(null); setDone(false); setMessage(''); }} />;
  return <><p className="game-prompt">Complete this 4 × 4 Sudoku.</p><p className="game-subprompt">Each row, column, and 2 × 2 box needs 1–4 once.</p><div className="game-board sudoku-board" style={{ gridTemplateColumns:'repeat(4,minmax(0,1fr))', width:280 }}>{board.map((value,index) => <button key={index} className={`game-cell ${active === index ? 'active' : ''} ${invalid(index,value) ? 'wrong' : ''}`} style={{ borderWidth: `${index % 4 === 1 ? 2 : 1}px ${index % 4 === 3 ? 2 : 1}px ${Math.floor(index/4) % 2 === 1 ? 2 : 1}px ${index % 4 === 0 ? 2 : 1}px` }} onClick={() => { if (!sudokuClues[index]) setActive(index); }} aria-label={`Row ${Math.floor(index/4)+1}, column ${index%4+1}, ${value || 'empty'}`}>{value}</button>)}</div><div className="game-action-row">{['1','2','3','4'].map(value => <button key={value} className="game-action secondary" onClick={() => {
    if (active === null) { setMessage('Choose an empty square first.'); return; }
    if (invalid(active,value)) { setMessage(`${value} already appears in that row, column, or box.`); return; }
    const next = [...board]; next[active] = value; setBoard(next); setMessage('');
    if (next.every(Boolean) && next.every((cell,index) => cell === sudokuSolution[index])) setDone(true);
  }} data-testid={`sudoku-number-${value}`}>{value}</button>)}<button className="game-action secondary" onClick={() => { if (active !== null) { const next=[...board]; next[active]=''; setBoard(next); } }}>Clear</button></div><p className="game-feedback" role="status">{message || 'Select a square, then choose a number.'}</p></>;
}

export function SlidingPuzzle() {
  const initial = [1,2,3,4,5,6,0,7,8];
  const [tiles,setTiles] = useState(initial);
  const [turns,setTurns] = useState(0);
  const [done,setDone] = useState(false);
  const move = (index:number) => {
    const empty=tiles.indexOf(0), dx=Math.abs(index%3-empty%3), dy=Math.abs(Math.floor(index/3)-Math.floor(empty/3));
    if (dx+dy !== 1) return;
    const next=[...tiles]; [next[index],next[empty]]=[next[empty],next[index]];
    setTiles(next); setTurns(turns+1);
    if (next.join(',') === '1,2,3,4,5,6,7,8,0') setDone(true);
  };
  if(done) return <Done score={Math.max(0,100-turns)} total={100} replay={() => { setTiles(initial); setTurns(0); setDone(false); }} />;
  return <><p className="game-prompt">Slide the tiles into number order.</p><p className="game-subprompt">Only a tile beside the empty space can move · {turns} moves</p><div className="game-board" style={{gridTemplateColumns:'repeat(3,minmax(0,1fr))',maxWidth:300}}>{tiles.map((tile,index)=><button key={index} className={`game-cell ${tile===0?'':'active'}`} onClick={()=>move(index)} aria-label={tile ? `Move tile ${tile}` : 'Empty space'} data-testid={`slider-tile-${tile}`}>{tile || ''}</button>)}</div><div className="game-action-row"><button className="game-action secondary" onClick={()=>{setTiles(initial);setTurns(0);}}>Reset puzzle</button></div></>;
}

function fourInLine(board:string[],player:string) {
  for(let y=0;y<6;y++) for(let x=0;x<7;x++) for(const [dx,dy] of [[1,0],[0,1],[1,1],[-1,1]]) {
    const coords=Array.from({length:4},(_,i)=>({x:x+dx*i,y:y+dy*i}));
    if(coords.every(point=>point.x>=0&&point.x<7&&point.y>=0&&point.y<6)&&coords.every(point=>board[point.y*7+point.x]===player)) return true;
  }
  return false;
}
export function ConnectFour() {
  const [board,setBoard]=useState(Array(42).fill(''));
  const [done,setDone]=useState(false), [message,setMessage]=useState('Choose a column. Discs fall to the lowest open row.');
  const drop=(column:number)=>{
    if(done)return;
    const row=[5,4,3,2,1,0].find(y=>!board[y*7+column]);
    if(row===undefined)return;
    const next=[...board];next[row*7+column]='You';
    if(fourInLine(next,'You')){setBoard(next);setDone(true);setMessage('Four in a row. You found the line.');return;}
    const openColumns=Array.from({length:7},(_,i)=>i).filter(col=>[0,1,2,3,4,5].some(y=>!next[y*7+col]));
    if(!openColumns.length){setBoard(next);setDone(true);setMessage('Board full. A thoughtful draw.');return;}
    const cpuColumn=openColumns[(column+openColumns.length-1)%openColumns.length];
    const cpuRow=[5,4,3,2,1,0].find(y=>!next[y*7+cpuColumn])!;
    next[cpuRow*7+cpuColumn]='Computer';setBoard(next);
    if(fourInLine(next,'Computer')){setDone(true);setMessage('Computer connected four. Try a new board.');}
    else setMessage('Your turn. Pick another column.');
  };
  if(done)return <Done score={fourInLine(board,'You')?4:0} total={4} replay={()=>{setBoard(Array(42).fill(''));setDone(false);setMessage('Choose a column. Discs fall to the lowest open row.');}} />;
  return <><p className="game-prompt">Connect Four</p><p className="game-subprompt">Drop a disc into a column; first to connect four wins.</p><div className="game-board connect-board" style={{gridTemplateColumns:'repeat(7,minmax(0,1fr))',maxWidth:440}}>{board.map((mark,index)=><button key={index} className={`game-cell ${mark==='You'?'active':''} ${mark==='Computer'?'wrong':''}`} onClick={()=>drop(index%7)} aria-label={`Column ${index%7+1}, row ${Math.floor(index/7)+1} ${mark||'empty'}`} data-testid={`connect-cell-${index}`}>{mark==='You'?'●':mark?'●':''}</button>)}</div><div className="game-action-row">{Array.from({length:7},(_,column)=><button className="game-action secondary" key={column} onClick={()=>drop(column)} aria-label={`Drop in column ${column+1}`}>{column+1}</button>)}</div><p className="game-feedback">{message}</p></>;
}

export function TicTacToe() {
  const [board,setBoard]=useState(Array(9).fill('')),[done,setDone]=useState(false),[result,setResult]=useState<'win'|'draw'|'loss'>('draw');
  const lines=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  const winner=(cells:string[])=>lines.find(line=>cells[line[0]]&&cells[line[0]]===cells[line[1]]&&cells[line[1]]===cells[line[2]])?.[0]===undefined?'':cells[lines.find(line=>cells[line[0]]&&cells[line[0]]===cells[line[1]]&&cells[line[1]]===cells[line[2]])![0]];
  const play=(index:number)=>{
    if(done||board[index])return;
    const next=[...board];next[index]='X';
    if(winner(next)){setBoard(next);setResult('win');setDone(true);return;}
    let free=next.map((value,i)=>value?-1:i).filter(i=>i>=0);
    if(!free.length){setBoard(next);setResult('draw');setDone(true);return;}
    const cpu=free.find(cell=>{const trial=[...next];trial[cell]='O';return !!winner(trial);}) ?? free.find(cell=>{const trial=[...next];trial[cell]='X';return !!winner(trial);}) ?? free[(index+free.length)%free.length];
    next[cpu]='O';setBoard(next);
    if(winner(next)){setResult('loss');setDone(true);}else if(next.every(Boolean)){setResult('draw');setDone(true);}
  };
  if(done)return <Done score={result==='win'?3:result==='draw'?1:0} total={3} replay={()=>{setBoard(Array(9).fill(''));setDone(false);setResult('draw');}} />;
  return <><p className="game-prompt">Tic-Tac-Toe</p><p className="game-subprompt">You are X. The computer takes O and blocks winning lines.</p><div className="game-board" style={{gridTemplateColumns:'repeat(3,minmax(0,1fr))',maxWidth:300}}>{board.map((mark,index)=><button key={index} className={`game-cell ${mark==='X'?'active':''} ${mark==='O'?'wrong':''}`} onClick={()=>play(index)} aria-label={`Square ${index+1}: ${mark||'empty'}`}>{mark}</button>)}</div></>;
}

const snakeFoods=[{x:4,y:2},{x:4,y:4},{x:2,y:4},{x:1,y:1},{x:5,y:1}];
export function SnakeGame() {
  const [snake,setSnake]=useState([{x:1,y:2},{x:0,y:2}]), [foodIndex,setFoodIndex]=useState(0), [direction,setDirection]=useState<'up'|'down'|'left'|'right'>('right'), [done,setDone]=useState(false);
  const move=(nextDirection:'up'|'down'|'left'|'right')=>{
    if(done)return;setDirection(nextDirection);
    const head=snake[0], delta={up:{x:0,y:-1},down:{x:0,y:1},left:{x:-1,y:0},right:{x:1,y:0}}[nextDirection], next={x:head.x+delta.x,y:head.y+delta.y};
    if(next.x<0||next.x>=6||next.y<0||next.y>=6||snake.some(part=>part.x===next.x&&part.y===next.y)){setDone(true);return;}
    const eating=next.x===snakeFoods[foodIndex].x&&next.y===snakeFoods[foodIndex].y;
    setSnake([next,...(eating?snake:snake.slice(0,-1))]);
    if(eating){if(foodIndex===snakeFoods.length-1)setDone(true);else setFoodIndex(foodIndex+1);}
  };
  useEffect(()=>{const handler=(event:KeyboardEvent)=>{const keys:Record<string,'up'|'down'|'left'|'right'>={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right'};if(keys[event.key]){event.preventDefault();move(keys[event.key]);}};window.addEventListener('keydown',handler);return()=>window.removeEventListener('keydown',handler);});
  if(done)return <Done score={foodIndex+(snake[0].x===snakeFoods[foodIndex]?.x&&snake[0].y===snakeFoods[foodIndex]?.y?1:0)} total={5} replay={()=>{setSnake([{x:1,y:2},{x:0,y:2}]);setFoodIndex(0);setDirection('right');setDone(false);}} />;
  const food=snakeFoods[foodIndex];
  return <><p className="game-prompt">Guide the snake to the dot.</p><p className="game-subprompt">Arrow keys or controls · collected {foodIndex} of 5</p><div className="game-board" style={{gridTemplateColumns:'repeat(6,minmax(0,1fr))',maxWidth:360}}>{Array.from({length:36},(_,index)=>{const x=index%6,y=Math.floor(index/6),isSnake=snake.some(part=>part.x===x&&part.y===y);return <div key={index} className={`game-cell ${isSnake?'active':''} ${food.x===x&&food.y===y?'found':''}`} aria-label={food.x===x&&food.y===y?'Food':isSnake?'Snake':'Empty'}>{food.x===x&&food.y===y?'•':isSnake?'●':''}</div>;})}</div><div className="maze-controls">{(['up','left','down','right'] as const).map(dir=><button key={dir} onClick={()=>move(dir)} aria-label={`Move ${dir}`}>{dir==='up'?<ArrowUp size={17}/>:dir==='down'?<ArrowDown size={17}/>:dir==='left'?<ArrowLeft size={17}/>:<ArrowRight size={17}/>}</button>)}</div></>;
}

export function LetterReveal() {
  const answer='PLANET', [guesses,setGuesses]=useState<string[]>([]), [done,setDone]=useState(false), [won,setWon]=useState(false);
  const guess=(letter:string)=>{if(guesses.includes(letter)||done)return;const next=[...guesses,letter];setGuesses(next);if(answer.split('').every(char=>char===' '||next.includes(char))){setDone(true);setWon(true);}else if(next.filter(char=>!answer.includes(char)).length>=6)setDone(true);};
  if(done)return <Done score={won?6:0} total={6} replay={()=>{setGuesses([]);setDone(false);setWon(false);}} />;
  return <><p className="game-prompt">Reveal the hidden word, one letter at a time.</p><p className="game-subprompt">Clue: Earth and Mars are examples · {6-guesses.filter(c=>!answer.includes(c)).length} guesses left</p><div className="game-action-row">{answer.split('').map((letter,index)=><span className="game-cell active" key={index} style={{width:45,height:50}}>{guesses.includes(letter)?letter:'_'}</span>)}</div><div className="game-options letter-bank">{'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(letter=><button className="game-option" key={letter} disabled={guesses.includes(letter)} onClick={()=>guess(letter)}>{letter}</button>)}</div><p className="game-feedback">Wrong guesses: {guesses.filter(char=>!answer.includes(char)).join(' ')||'none yet'}</p></>;
}

export function WordBuilder() {
  const letters=['S','E','E','D','L','I','N','G'], [picked,setPicked]=useState<number[]>([]),[done,setDone]=useState(false),[message,setMessage]=useState('');
  const goal='SEEDLING';
  if(done)return <Done score={8} total={8} replay={()=>{setPicked([]);setDone(false);setMessage('');}} />;
  return <><p className="game-prompt">Build the word for a young plant.</p><p className="game-subprompt">Choose letter tiles in order to spell it.</p><div className="game-action-row" style={{minHeight:54}}>{picked.map((index,position)=><span key={`${index}-${position}`} className="game-cell active" style={{width:42,height:48}}>{letters[index]}</span>)}</div><div className="game-options letter-bank">{letters.map((letter,index)=><button key={`${letter}-${index}`} className="game-option" disabled={picked.includes(index)} onClick={()=>{const next=[...picked,index];setPicked(next);const formed=next.map(tile=>letters[tile]).join('');if(formed===goal)setDone(true);else if(!goal.startsWith(formed))setMessage('Those letters do not fit yet. Remove one and try a new order.');else setMessage('Good start. Keep building the word.');}}>{letter}</button>)}</div><div className="game-action-row"><button className="game-action secondary" onClick={()=>{setPicked([]);setMessage('');}}>Clear word</button></div><p className="game-feedback">{message||`${picked.length} of ${goal.length} letters placed`}</p></>;
}

export function Crossword() {
  const across='PLANT', down='ACORN'; const [letters,setLetters]=useState<Record<string,string>>({}),[done,setDone]=useState(false),[message,setMessage]=useState('');
  const coords=Array.from({length:5},(_,i)=>({key:`1-${i+1}`,answer:across[i],row:1,col:i}));
  for(let i=1;i<down.length;i++) if(!coords.some(cell=>cell.row===i&&cell.col===2))coords.push({key:`${i+1}-3`,answer:down[i],row:i,col:2});
  if(done)return <Done score={9} total={9} replay={()=>{setLetters({});setDone(false);setMessage('');}} />;
  return <><p className="game-prompt">Mini crossword</p><p className="game-subprompt">Across: living thing that grows in soil. Down: an oak tree begins as one.</p><div className="game-board" style={{gridTemplateColumns:'repeat(5,48px)',width:'fit-content'}}>{Array.from({length:30},(_,idx)=>{const row=Math.floor(idx/5),col=idx%5,cell=coords.find(item=>item.row===row&&item.col===col);return <div key={idx} className={`game-cell ${cell?'active':''}`} style={{background:cell?'#f8f6e9':'#315f52',padding:0}}>{cell?<input aria-label={`Crossword row ${row+1} column ${col+1}`} value={letters[cell.key]||''} maxLength={1} onChange={event=>setLetters({...letters,[cell.key]:event.target.value.toUpperCase()})} style={{width:'100%',height:'100%',border:0,background:'transparent',textAlign:'center',color:'#315f52',fontWeight:700}}/>:null}</div>;})}</div><div className="game-action-row"><button className="game-action" onClick={()=>{const correct=coords.every(cell=>(letters[cell.key]||'')===cell.answer);if(correct)setDone(true);else setMessage('Check the crossing letters and try once more.');}}>Check crossword</button></div><p className="game-feedback">{message}</p></>;
}

export function RhythmGame() {
  const [sequence,setSequence]=useState<number[]>([]),[shown,setShown]=useState<number|null>(null),[input,setInput]=useState<number[]>([]),[round,setRound]=useState(1),[mode,setMode]=useState<'ready'|'show'|'input'|'done'>('ready');
  const padSequence=[0,2,1,3,2,0];
  const play=()=>{const current=padSequence.slice(0,round+2);setSequence(current);setInput([]);setMode('show');current.forEach((pad,index)=>window.setTimeout(()=>{setShown(pad);window.setTimeout(()=>setShown(null),300);if(index===current.length-1)window.setTimeout(()=>setMode('input'),400);},index*650));};
  const hit=(pad:number)=>{if(mode!=='input')return;const next=[...input,pad];setInput(next);if(next.some((value,index)=>value!==sequence[index])){setMode('ready');setRound(1);return;}if(next.length===sequence.length){if(round>=4)setMode('done');else{setRound(round+1);setMode('ready');}}};
  if(mode==='done')return <Done score={4} total={4} replay={()=>{setSequence([]);setInput([]);setRound(1);setMode('ready');}} />;
  return <><p className="game-prompt">Watch the lights. Repeat the rhythm.</p><p className="game-subprompt">Sequence {round} of 4 · {mode==='show'?'Watch closely':mode==='input'?'Your turn':'Ready to play'}</p><div className="game-options rhythm-pads">{['A','B','C','D'].map((pad,index)=><button className={`game-option ${shown===index?'active':''}`} key={pad} onClick={()=>hit(index)} disabled={mode!=='input'}>{pad}</button>)}</div><div className="game-action-row"><button className="game-action" onClick={play} disabled={mode==='show'||mode==='input'}>{mode==='ready'?'Play sequence':'Replay sequence'}</button></div><p className="game-feedback">{input.length} of {sequence.length} notes repeated</p></>;
}

export function BalanceGame() {
  const [position,setPosition]=useState(0),[seconds,setSeconds]=useState(12),[done,setDone]=useState(false),[failed,setFailed]=useState(false);
  useEffect(()=>{if(done||failed)return;const id=window.setInterval(()=>{setSeconds(value=>{if(value<=1){setDone(true);return 0;}return value-1;});setPosition(value=>{const next=Math.max(-4,Math.min(4,value+(Math.random()>.5?1:-1)));if(Math.abs(next)>=4)setFailed(true);return next;});},1000);return()=>window.clearInterval(id);},[done,failed]);
  if(done||failed)return <Done score={done?12-seconds:12-seconds} total={12} replay={()=>{setPosition(0);setSeconds(12);setDone(false);setFailed(false);}} />;
  return <><p className="game-prompt">Keep the marker inside the safe zone.</p><p className="game-subprompt">Correct each little drift with left and right.</p><div style={{maxWidth:440,margin:'34px auto',height:34,position:'relative',borderRadius:20,background:'#e7eddd'}}><div style={{position:'absolute',left:'35%',width:'30%',top:0,bottom:0,background:'#d4e7d1',borderRadius:20}}/><span style={{position:'absolute',left:`${50+position*9}%`,top:-8,width:30,height:50,borderRadius:14,background:'#e5bc55',transition:'left .2s'}}/></div><div className="game-stage-head"><span className="game-stage-label">Balance</span><span className="game-stage-score"><Timer size={14}/>{seconds}s</span></div><div className="game-action-row"><button className="game-action secondary" onClick={()=>setPosition(v=>v-1)}><ArrowLeft size={15}/> Left</button><button className="game-action secondary" onClick={()=>setPosition(v=>v+1)}>Right <ArrowRight size={15}/></button></div><p className="game-feedback">Stay centered until the timer reaches zero.</p></>;
}

export function EscapeRoom() {
  const [clues,setClues]=useState<string[]>([]),[code,setCode]=useState(''),[done,setDone]=useState(false),[message,setMessage]=useState('');
  if(done)return <Done score={4} total={4} replay={()=>{setClues([]);setCode('');setDone(false);setMessage('');}} />;
  return <><p className="game-prompt">Unlock the room by finding four clues.</p><p className="game-subprompt">The clock points to 3, the book is 1, the framed print is 4, and the shelf is 2.</p><div className="game-options">{['Inspect clock','Open book','Study framed print','Check shelf'].map((clue,index)=><button className={`game-option ${clues.includes(clue)?'selected':''}`} key={clue} onClick={()=>setClues(c=>c.includes(clue)?c:[...c,clue])}>{clues.includes(clue)?'Clue found · ':''}{clue}</button>)}</div><p className="game-subprompt">Enter the four digits in clue order.</p><input className="game-input" inputMode="numeric" maxLength={4} value={code} onChange={event=>setCode(event.target.value.replace(/\D/g,''))} aria-label="Escape code"/><div className="game-action-row"><button className="game-action" disabled={clues.length<4||code.length!==4} onClick={()=>{if(code==='3142')setDone(true);else setMessage('That code did not open the door. Re-read the clues.');}}>Unlock</button></div><p className="game-feedback">{message||`${clues.length} of 4 clues collected`}</p></>;
}

export function LogicPlacement() {
  const [placed,setPlaced]=useState<Record<string,string>>({}),[done,setDone]=useState(false);
  const targets=['Moon','Leaf','Shell'], slots=['Left','Center','Right'];
  if(done)return <Done score={3} total={3} replay={()=>{setPlaced({});setDone(false);}} />;
  return <><p className="game-prompt">Place each symbol using the clues.</p><p className="game-subprompt">The leaf goes left. The moon is to the right of the leaf. The shell fills the remaining space.</p><div className="game-options">{slots.map(slot=><button className="game-option" key={slot} onClick={()=>{const next={...placed,[slot]:targets.find(value=>!Object.values(placed).includes(value))||'Moon'};setPlaced(next);if(slots.every(item=>next[item])&&next.Left==='Leaf'&&next.Center==='Shell'&&next.Right==='Moon')setDone(true);}}>{slot}: {placed[slot]||'Choose next'}</button>)}</div><div className="game-action-row">{targets.map(item=><button key={item} className="game-action secondary" onClick={()=>{const slot=slots.find(key=>!placed[key]);if(!slot)return;const next={...placed,[slot]:item};setPlaced(next);if(slots.every(key=>next[key])&&next.Left==='Leaf'&&next.Center==='Shell'&&next.Right==='Moon')setDone(true);}}>{item}</button>)}</div><p className="game-feedback">{Object.keys(placed).length} of 3 positions filled · Tap a slot to cycle or choose a symbol below.</p></>;
}

export function ShapeSort() {
  const [sorted,setSorted]=useState<string[]>([]),[selected,setSelected]=useState<string|null>(null);
  const shapes=['Circle','Square','Triangle','Circle','Triangle','Square'];
  if(sorted.length===shapes.length)return <Done score={6} total={6} replay={()=>{setSorted([]);setSelected(null);}} />;
  return <><p className="game-prompt">Sort each shape into its matching basket.</p><div className="game-options">{shapes.map((shape,index)=>!sorted.includes(String(index))&&<button className={`game-option ${selected===String(index)?'selected':''}`} key={index} onClick={()=>setSelected(String(index))}>{shape}</button>)}</div><div className="game-action-row">{['Circle','Square','Triangle'].map(shape=><button className="game-action secondary" key={shape} onClick={()=>{if(selected===null)return;if(shapes[Number(selected)]===shape){const next=[...sorted,selected];setSorted(next);setSelected(null);}}}>Place in {shape} basket</button>)}</div><p className="game-feedback">{sorted.length} of 6 shapes sorted correctly</p></>;
}

export function TileHunt({ game }: { game: MiniGameDefinition }) {
  const [found,setFound]=useState<number[]>([]),[checked,setChecked]=useState<number[]>([]);
  const treasure=[2,8,13], numbers=['2','4','6','8','3','5','7','1','9','2','4','6','5','8','3','7'];
  const differences=[1,5,10];
  const isDiff=game.variant==='spot-difference', isNumber=game.variant==='number-hunt';
  const targets=isDiff?differences:isNumber?[0,1,2]:treasure;
  if(found.length>=3)return <Done score={3} total={3} replay={()=>{setFound([]);setChecked([]);}} />;
  if(isDiff)return <><p className="game-prompt">Compare both tiles and mark the three changes.</p><p className="game-subprompt">Select the changed cells in the pattern on the right.</p><div style={{display:'grid',gridTemplateColumns:'repeat(2,minmax(0,1fr))',gap:12,maxWidth:500,margin:'18px auto'}}><div><span className="game-stage-label">Pattern A</span><div className="game-board" style={{gridTemplateColumns:'repeat(4,minmax(0,1fr))',gap:4}}>{Array.from({length:16},(_,i)=><div key={i} className="game-cell" style={{aspectRatio:'1',minHeight:28}}>{'○'}</div>)}</div></div><div><span className="game-stage-label">Pattern B · tap differences</span><div className="game-board" style={{gridTemplateColumns:'repeat(4,minmax(0,1fr))',gap:4}}>{Array.from({length:16},(_,i)=><button key={i} className={`game-cell ${found.includes(i)?'found':''}`} onClick={()=>{if(checked.includes(i))return;setChecked(value=>[...value,i]);if(differences.includes(i))setFound(value=>[...value,i]);}} aria-label={`Compare tile ${i+1}`}>{differences.includes(i)?'△':'○'}</button>)}</div></div></div><p className="game-feedback">{found.length} of 3 differences found</p></>;
  return <><p className="game-prompt">{isDiff?'Spot the different tiles.':isNumber?'Find three numbers that total 12.':'Tap tiles to uncover all three hidden treasures.'}</p><p className="game-subprompt">{isDiff?'Compare the left and right tile patterns.':isNumber?'Select 2, 4, and 6.':`${found.length} of 3 treasures uncovered.`}</p><div className="game-board" style={{gridTemplateColumns:'repeat(4,minmax(0,1fr))'}}>{Array.from({length:16},(_,i)=>{const isTarget=targets.includes(i);const value=isDiff?(isTarget?'●':'○'):isNumber?numbers[i]:found.includes(i)?(isTarget?'◆':'·'):'?';return <button key={i} className={`game-cell ${found.includes(i)?'found':''}`} onClick={()=>{if(checked.includes(i))return;setChecked(c=>[...c,i]);if(isTarget)setFound(c=>[...c,i]);}} aria-label={`${isDiff?'Pattern tile':isNumber?`Number ${numbers[i]}`:'Treasure tile'} ${i+1}`} data-testid={`hunt-tile-${i}`}>{value}</button>;})}</div><p className="game-feedback">{isDiff?`${found.length} differences found`:isNumber?`${found.length} target numbers found`:`${found.length} treasures found`}</p></>;
}

export function CommandCoding() {
  const [commands,setCommands]=useState<string[]>([]),[message,setMessage]=useState(''),[done,setDone]=useState(false);
  const required=['right','right','down'];
  if(done)return <Done score={3} total={3} replay={()=>{setCommands([]);setDone(false);setMessage('');}} />;
  const run=()=>{if(commands.join(',')===required.join(','))setDone(true);else setMessage('The character missed the goal. Clear the program and try again.');};
  return <><p className="game-prompt">Program the character to reach the star.</p><p className="game-subprompt">Start at the top-left of this grid. Goal is at row 2, column 3.</p><div className="game-board" style={{gridTemplateColumns:'repeat(3,54px)',width:'fit-content'}}>{Array.from({length:9},(_,i)=><div key={i} className={`game-cell ${i===0?'active':''} ${i===5?'found':''}`}>{i===0?'S':i===5?'G':''}</div>)}</div><div className="game-action-row">{['up','left','down','right'].map(dir=><button className="game-action secondary" key={dir} onClick={()=>setCommands(c=>[...c,dir])}>{dir==='up'?<ArrowUp size={14}/>:dir==='down'?<ArrowDown size={14}/>:dir==='left'?<ArrowLeft size={14}/>:<ArrowRight size={14}/>} {dir}</button>)}</div><p className="game-feedback">Program: {commands.join(' → ')||'empty'}</p><div className="game-action-row"><button className="game-action" onClick={run}>Run program</button><button className="game-action secondary" onClick={()=>{setCommands([]);setMessage('');}}>Clear</button></div><p className="game-feedback">{message}</p></>;
}

export function VirtualChemistry() {
  const [selected,setSelected]=useState<string[]>([]),[message,setMessage]=useState('');
  const items=['Blue pigment','Water bead','Paper star','Silver shimmer','Bubble shape','Stone chip'];
  const goal=['Blue pigment','Water bead','Silver shimmer'];
  if(goal.every(item=>selected.includes(item))&&selected.length===3)return <Done score={3} total={3} replay={()=>setSelected([])} />;
  return <><p className="game-prompt">Sort virtual ingredients for the imaginary blue mixture.</p><p className="game-subprompt">Choose blue pigment, a water bead, and silver shimmer. No real lab activities.</p><div className="game-options">{items.map(item=><button key={item} className={`game-option ${selected.includes(item)?'selected':''}`} onClick={()=>setSelected(current=>current.includes(item)?current.filter(x=>x!==item):[...current,item])}>{item}</button>)}</div><div className="game-action-row"><button className="game-action" onClick={()=>setMessage(selected.length===3&&selected.every(item=>goal.includes(item))?'Correct virtual sort.':`Try again: ${selected.filter(item=>goal.includes(item)).length} of 3 matches.`)}>Check sort</button><button className="game-action secondary" onClick={()=>{setSelected([]);setMessage('');}}>Reset</button></div><p className="game-feedback">{message}</p></>;
}

export function PhysicsDrop() {
  const [position,setPosition]=useState(20),[result,setResult]=useState(false);
  if(result)return <Done score={position>=65&&position<=75?1:0} total={1} replay={()=>setResult(false)} />;
  return <><p className="game-prompt">Adjust the drop point, then land the object in the target.</p><p className="game-subprompt">Move the slider near the center-right target before releasing.</p><div style={{width:'min(440px,100%)',height:120,margin:'30px auto',position:'relative',borderBottom:'3px solid #789487'}}><span style={{position:'absolute',left:'65%',width:'10%',height:55,bottom:0,background:'#dbead6',borderRadius:'14px 14px 0 0'}}/><span style={{position:'absolute',left:`${position}%`,top:10,width:24,height:24,borderRadius:'50%',background:'#e7bc52',transform:'translateX(-50%)'}}/></div><label className="game-subprompt" style={{display:'block',textAlign:'center'}}>Drop position: {position}<input type="range" min="0" max="100" value={position} onChange={event=>setPosition(Number(event.target.value))} style={{display:'block',width:'min(400px,90%)',margin:'14px auto'}} aria-label="Drop position"/></label><div className="game-action-row"><button className="game-action" onClick={()=>setResult(true)}>Drop object</button></div></>;
}

export function FishingSignal() {
  const [state,setState]=useState<'ready'|'waiting'|'bite'|'done'>('ready'),[catches,setCatches]=useState(0),[falseReels,setFalseReels]=useState(0);
  const timer=useRef<number|null>(null);
  useEffect(()=>()=>{if(timer.current!==null)window.clearTimeout(timer.current);},[]);
  if(state==='done')return <Done score={catches} total={3} replay={()=>{setCatches(0);setFalseReels(0);setState('ready');}} />;
  const cast=()=>{setState('waiting');timer.current=window.setTimeout(()=>setState('bite'),1000+Math.random()*2300);};
  const reel=()=>{if(state==='bite'){const next=catches+1;setCatches(next);setState(next===3?'done':'ready');}else if(state==='waiting'){if(timer.current!==null)window.clearTimeout(timer.current);setFalseReels(v=>v+1);setState('ready');}};
  return <><p className="game-prompt">Cast, watch, and reel only when the bobber dips.</p><p className="game-subprompt">Virtual fishing only · {catches} of 3 catches · {falseReels} early reels</p><button className="game-action" style={{display:'flex',width:'min(380px,100%)',height:120,margin:'25px auto',justifyContent:'center',fontSize:20,background:state==='bite'?'#e8be58':'#dcebe1',color:'#24584c'}} onClick={state==='ready'?cast:reel}>{state==='ready'?'Cast line':state==='waiting'?'Water is quiet… reel':'BITE! Reel now'}</button><p className="game-feedback">Wait for the signal, then reel in.</p></>;
}

export function ColorMatch() {
  const colors=[{name:'Coral',color:'#c96550'},{name:'Moss',color:'#688c62'},{name:'Sky',color:'#78a4a0'},{name:'Gold',color:'#d4a942'}];
  const [round,setRound]=useState(0),[score,setScore]=useState(0),[done,setDone]=useState(false),[message,setMessage]=useState('');
  const targets=[2,1,0,3,1];
  if(done)return <Done score={score} total={5} replay={()=>{setRound(0);setScore(0);setDone(false);setMessage('');}} />;
  return <><p className="game-prompt">Match the named color.</p><div style={{display:'grid',placeItems:'center',width:110,height:110,margin:'12px auto',borderRadius:'50%',background:colors[targets[round]].color,color:'#fff7e4',font:'700 14px var(--app-font-mono)'}}>{colors[targets[round]].name}</div><p className="game-subprompt">Round {round+1} of 5 · choose the matching swatch below</p><div className="game-options">{colors.map(item=><button key={item.name} className="game-option" onClick={()=>{const correct=item.name===colors[targets[round]].name;const nextScore=score+(correct?1:0);setScore(nextScore);setMessage(correct?'Color matched.':'Not quite—watch the target label.');if(round===4)setDone(true);else setRound(round+1);}}><span style={{display:'inline-block',width:16,height:16,marginRight:9,verticalAlign:'middle',borderRadius:'50%',background:item.color}}/>{item.name}</button>)}</div><p className="game-feedback">{message}</p></>;
}

export function PaddleGame({ game }: { game: MiniGameDefinition }) {
  const [paddle,setPaddle]=useState(2),[ball,setBall]=useState(2),[turn,setTurn]=useState(0),[broken,setBroken]=useState<number[]>([]),[done,setDone]=useState(false),[misses,setMisses]=useState(0);
  const isBrick=game.variant==='breaker', targets=[0,3,1,4,2,0,4];
  const advance=()=>{
    if(!isBrick){const good=paddle===targets[turn];setTurn(turn+1);if(good)setBroken([...broken,turn]);setBall(targets[(turn+1)%targets.length]);if(turn>=4)setDone(true);return;}
    const nextBrick=targets.findIndex((_,index)=>!broken.includes(index));
    if(nextBrick<0){setDone(true);return;}
    const lane=targets[nextBrick];setBall(lane);
    if(paddle===lane){setBroken([...broken,nextBrick]);if(broken.length+1>=5)setDone(true);}
    else {setMisses(misses+1);if(misses>=2)setMisses(0);}
    setTurn(turn+1);
  };
  if(done)return <Done score={isBrick?broken.length:broken.length} total={isBrick?5:5} replay={()=>{setPaddle(2);setBall(2);setTurn(0);setBroken([]);setDone(false);setMisses(0);}} />;
  return <><p className="game-prompt">{isBrick?'Move the paddle beneath the ball to clear the bricks.':'Bounce the ball toward each target.'}</p><p className="game-subprompt">{isBrick?`${broken.length} of 5 blocks cleared · misses ${misses}`:`Bounce ${turn+1} of 5 · align your paddle`}</p><div className="game-board paddle-field" style={{gridTemplateColumns:'repeat(5,minmax(0,1fr))',maxWidth:390}}>{Array.from({length:15},(_,index)=>{const col=index%5,row=Math.floor(index/5);const brick=isBrick&&row===0&&!broken.includes(col);return <div key={index} className={`game-cell ${brick?'active':''} ${row===2&&ball===col?'found':''}`} style={{height:42,aspectRatio:'auto'}}>{brick?'■':row===2&&ball===col?'●':''}</div>;})}</div><div className="game-board" style={{gridTemplateColumns:'repeat(5,minmax(0,1fr))',maxWidth:390,marginTop:0}}>{[0,1,2,3,4].map(lane=><button className={`game-cell ${paddle===lane?'active':''}`} key={lane} onClick={()=>setPaddle(lane)} style={{height:35,aspectRatio:'auto',borderRadius:8}} aria-label={`Paddle lane ${lane+1}`}>{paddle===lane?'▰':''}</button>)}</div><div className="game-action-row"><button className="game-action secondary" onClick={()=>setPaddle(Math.max(0,paddle-1))}><ArrowLeft size={14}/> Move left</button><button className="game-action" onClick={advance}>Launch / bounce</button><button className="game-action secondary" onClick={()=>setPaddle(Math.min(4,paddle+1))}>Move right <ArrowRight size={14}/></button></div><p className="game-feedback">{isBrick?'Blocks break when your paddle lines up with the falling ball.':'Place your paddle in the ball’s target lane before each bounce.'}</p></>;
}

export function TowerTiming() {
  const [position,setPosition]=useState(0),[stack,setStack]=useState<number[]>([]),[done,setDone]=useState(false);
  useEffect(()=>{if(done)return;const id=window.setInterval(()=>setPosition(value=>(value+1)%5),450);return()=>window.clearInterval(id);},[done]);
  if(done)return <Done score={stack.length} total={5} replay={()=>{setPosition(0);setStack([]);setDone(false);}} />;
  return <><p className="game-prompt">Drop each moving block on the tower.</p><p className="game-subprompt">Stop the marker over the center lane · {stack.length} of 5 blocks</p><div className="game-board" style={{gridTemplateColumns:'repeat(5,48px)',width:'fit-content'}}>{[0,1,2,3,4].map(lane=><div className={`game-cell ${position===lane?'active':''} ${stack.includes(lane)?'found':''}`} key={lane}>{stack.includes(lane)?'■':position===lane?'●':''}</div>)}</div><div className="game-action-row"><button className="game-action" onClick={()=>{const next=[...stack,position];setStack(next);if(next.length>=5)setDone(true);}}>Drop block</button></div><p className="game-feedback">The marker moves automatically. Tap when it lines up.</p></>;
}

export function ScienceLab() {
  const [tools,setTools]=useState<string[]>([]),[message,setMessage]=useState('');
  const safe=['Safety glasses','Virtual magnifier','Observation notebook'];
  if(safe.every(item=>tools.includes(item))&&tools.length===3)return <Done score={3} total={3} replay={()=>setTools([])} />;
  return <><p className="game-prompt">Choose safe tools to observe a tiny virtual specimen.</p><p className="game-subprompt">Pick only viewing and note-taking tools. No real experiment is involved.</p><div className="game-options">{['Safety glasses','Virtual magnifier','Observation notebook','Open flame','Unknown liquid','Sharp tool'].map(item=><button key={item} className={`game-option ${tools.includes(item)?'selected':''}`} onClick={()=>setTools(current=>current.includes(item)?current.filter(value=>value!==item):[...current,item])}>{item}</button>)}</div><div className="game-action-row"><button className="game-action" onClick={()=>setMessage(tools.length===3&&tools.every(item=>safe.includes(item))?'Safe virtual toolkit selected.':`Select the three safe observation tools. ${tools.filter(item=>safe.includes(item)).length} correct so far.`)}>Check toolkit</button></div><p className="game-feedback">{message}</p></>;
}

export function StepPlan({ game }: { game: MiniGameDefinition }) {
  const steps=game.variant==='farm'?['Choose a sunny plot','Plant virtual seeds','Water the garden','Harvest the crops']:['Choose a plate','Add fruit pieces','Place crackers','Finish the arrangement'];
  const [progress,setProgress]=useState(0),[done,setDone]=useState(false),[message,setMessage]=useState('');
  if(done)return <Done score={4} total={4} replay={()=>{setProgress(0);setDone(false);setMessage('');}} />;
  return <><p className="game-prompt">{game.variant==='farm'?'Plan the garden in a useful order.':'Arrange a no-heat virtual snack.'}</p><p className="game-subprompt">Choose the next step in the plan, in order.</p><div className="game-options">{steps.map((step,index)=><button key={step} disabled={index<progress} className={`game-option ${index<progress?'correct':''}`} onClick={()=>{if(index===progress){const next=progress+1;setProgress(next);setMessage('Good order.');if(next===steps.length)setDone(true);}else setMessage('That step comes later. Try the next planned action.');}}>{index<progress?'✓ ':`${index+1}. `}{step}</button>)}</div><p className="game-feedback">{message||`${progress} of ${steps.length} steps done`}</p><p className="game-disclaimer">Fictional screen activity only. No heat, tools, or real ingredients.</p></>;
}

export function LaneChallenge({ game }: { game: MiniGameDefinition }) {
  const [step,setStep]=useState(0),[score,setScore]=useState(0),[done,setDone]=useState(false),[message,setMessage]=useState('');
  const target=[2,0,1,2,1,0];
  const isCatcher=game.variant==='catcher', isRace=game.variant==='racing';
  const options=isCatcher?['Lane 1','Lane 2','Lane 3']:isRace?['Left lane','Middle lane','Right lane']:game.variant==='jumper'?['Short jump','High jump','Wait']:['Dodge left','Jump','Dodge right'];
  const choose=(index:number)=>{if(done)return;const good=index===target[step];const nextScore=score+(good?1:0),nextStep=step+1;setScore(nextScore);setStep(nextStep);setMessage(good?'Clear! Keep going.':'A soft bump. Choose a safer move next time.');if(nextStep>=target.length)setDone(true);};
  if(done)return <Done score={score} total={6} replay={()=>{setStep(0);setScore(0);setDone(false);setMessage('');}} />;
  return <><p className="game-prompt">{isCatcher?'Catch the falling object in the correct lane.':isRace?'Switch lanes around the cones to reach the finish.':game.variant==='jumper'?'Time each jump to land on the safe platform.':'Choose a safe lane or jump to pass the next obstacle.'}</p><p className="game-subprompt">Step {step+1} of 6 · {score} clean moves</p><div className="lane-track">{[0,1,2].map(lane=><div className="lane-column" key={lane}><span className={`lane-obstacle ${target[step]===lane?'':'hidden'}`}>{isCatcher?'●':'◆'}</span><span className="lane-player">●</span></div>)}</div><div className="game-action-row">{options.map((option,index)=><button className="game-action secondary" key={option} onClick={()=>choose(index)}>{option}</button>)}</div><p className="game-feedback">{message}</p></>;
}

export function SpaceShooter() {
  const [ship,setShip]=useState(1),[targets,setTargets]=useState([0,1,2,3]),[hits,setHits]=useState(0);
  if(hits>=4)return <Done score={hits} total={4} replay={()=>{setShip(1);setTargets([0,1,2,3]);setHits(0);}} />;
  return <><p className="game-prompt">Move your ship, then tag every harmless target.</p><p className="game-subprompt">Use lane controls and shoot when a target is in your column.</p><div className="game-board" style={{gridTemplateColumns:'repeat(4,54px)',width:'fit-content'}}>{[0,1,2,3].map(lane=><div className={`game-cell ${ship===lane?'active':''}`} key={lane} onClick={()=>setShip(lane)}>{targets.includes(lane)?'◆':''}{ship===lane?'▲':''}</div>)}</div><div className="game-action-row">{[0,1,2,3].map(lane=><button key={lane} className="game-action secondary" onClick={()=>setShip(lane)}>Move {lane+1}</button>)}<button className="game-action" onClick={()=>{if(targets.includes(ship)){setTargets(targets.filter(t=>t!==ship));setHits(hits+1);}}}>Tag target</button></div><p className="game-feedback">{hits} of 4 targets tagged</p></>;
}
