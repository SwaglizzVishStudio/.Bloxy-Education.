import { strict as assert } from 'node:assert';
import { getRenewalPrice, RENEWAL_EVENTS } from './renewal-pricing.ts';

for (const { date } of RENEWAL_EVENTS) {
  assert.equal(getRenewalPrice(date, false), 500);
  assert.equal(getRenewalPrice(date, true), 500);
}
assert.equal(getRenewalPrice('2027-11-02', false), 1000);
assert.equal(getRenewalPrice('2027-11-02', true), 800);
assert.equal(getRenewalPrice('2027-11-06', false), 800);
assert.equal(getRenewalPrice('2027-11-07', false), 800);
assert.equal(getRenewalPrice('2028-11-19', false), 800); // Not the October promotion.
assert.equal(getRenewalPrice('2029-11-01', false), 1000); // No automatic recurrence.
assert.equal(getRenewalPrice('2027-10-31T18:30:00Z', false), 500); // Midnight IST.
assert.equal(getRenewalPrice(new Date('2027-11-01T18:30:00Z'), false), 1000);
for (const value of ['2027-02-29', '2028-02-30', 'bad', '2027-11-01T00:00:00']) {
  assert.throws(() => getRenewalPrice(value, false), RangeError);
}
assert.throws(() => getRenewalPrice(new Date(NaN), false), RangeError);
console.log('PASS: all six events, precedence, weekends, maze, IST boundaries, invalid dates, no recurrence.');