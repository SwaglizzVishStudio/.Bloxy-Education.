export interface ChatSafetyUser {
  name: string;
  strikes?: number;
  mutedUntil?: number;
}

export const MUTE_DURATION_MS = 24 * 60 * 60 * 1000;
// Word boundaries prevent matches inside words such as "Essex".
const banned = /\b(?:fuck|shit|sex|porn|boobs|dick|xxx|nsfw|nude)\b/iu;

function moderate(user: ChatSafetyUser, msg: string, voice: boolean, now: number): string {
  if (user.mutedUntil && now < user.mutedUntil) {
    return `Muted until ${new Date(user.mutedUntil).toLocaleString()}.`;
  }
  if (user.mutedUntil && now >= user.mutedUntil) {
    user.mutedUntil = undefined;
    user.strikes = 0;
  }
  const text = msg.trim();
  if (!text) return 'Enter a message to check.';
  if (banned.test(text.normalize('NFKC'))) {
    user.strikes = (user.strikes || 0) + 1;
    if (user.strikes === 1) return 'Warning: Keep chat safe.';
    if (user.strikes === 2) return 'Second warning. Next violation = 24-hour mute.';
    user.mutedUntil = now + MUTE_DURATION_MS;
    return `Muted for 24 hours until ${new Date(user.mutedUntil).toLocaleString()}.`;
  }
  return `${user.name}${voice ? ' (voice)' : ''}: ${text}`;
}

/** Local simulation only. Shared chat would need authoritative server enforcement. */
export function safeChat(user: ChatSafetyUser, msg: string, now = Date.now()): string {
  return moderate(user, msg, false, now);
}

/** Checks an already-transcribed string; does not capture or moderate live audio. */
export function safeVoice(user: ChatSafetyUser, msg: string, now = Date.now()): string {
  return moderate(user, msg, true, now);
}