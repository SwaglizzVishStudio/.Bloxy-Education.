/** User-specified promotional dates, not a verified religious-holiday calendar. */
export const RENEWAL_EVENTS = [
  { date: '2027-11-01', name: 'Diwali promotion' },
  { date: '2027-11-26', name: 'Black Friday' },
  { date: '2027-12-25', name: 'Christmas' },
  { date: '2028-10-19', name: 'Diwali promotion' },
  { date: '2028-11-24', name: 'Black Friday' },
  { date: '2028-12-25', name: 'Christmas' },
] as const;

export const RENEWAL_TIME_ZONE = 'Asia/Kolkata';
const festivalDates = new Set<string>(RENEWAL_EVENTS.map(event => event.date));

function calendarDate(value: Date | string): string {
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const parsed = new Date(`${value}T00:00:00Z`);
    if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) {
      throw new RangeError('Invalid renewal date.');
    }
    return value;
  }
  // Require an explicit timezone for timestamps; never use the device timezone.
  if (typeof value === 'string' && !/T.*(?:Z|[+-]\d{2}:\d{2})$/i.test(value)) {
    throw new RangeError('Use YYYY-MM-DD or an ISO timestamp with a timezone.');
  }
  const instant = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(instant.getTime())) throw new RangeError('Invalid renewal date.');
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: RENEWAL_TIME_ZONE, year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(instant);
  const part = (type: string) => parts.find(item => item.type === type)!.value;
  return `${part('year')}-${part('month')}-${part('day')}`;
}

/** Returns whole Indian rupees. Preview only; checkout must verify maze eligibility server-side. */
export function getRenewalPrice(date: Date | string, didMaze: boolean): number {
  const key = calendarDate(date);
  if (festivalDates.has(key)) return 500;
  const weekday = new Date(`${key}T00:00:00Z`).getUTCDay();
  if (weekday === 0 || weekday === 6 || didMaze) return 800;
  return 1000;
}