type AudioContextRef = { current: AudioContext | null };

function scheduleTone(
  context: AudioContext,
  startAt: number,
  startFrequency: number,
  endFrequency: number,
  duration: number,
  type: OscillatorType,
  volume: number,
) {
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  const endAt = startAt + duration;

  oscillator.type = type;
  oscillator.frequency.setValueAtTime(startFrequency, startAt);
  oscillator.frequency.exponentialRampToValueAtTime(endFrequency, endAt);
  gain.gain.setValueAtTime(0.0001, startAt);
  gain.gain.linearRampToValueAtTime(volume, startAt + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, endAt);

  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.start(startAt);
  oscillator.stop(endAt + 0.02);
}

export function prepareQuizFeedbackAudio(contextRef: AudioContextRef) {
  if (typeof window === "undefined" || typeof window.AudioContext === "undefined") {
    return;
  }

  try {
    const context = contextRef.current ?? new window.AudioContext();
    contextRef.current = context;
    if (context.state === "suspended") {
      void context.resume().catch(() => undefined);
    }
  } catch {
    // Keep quiz answering available when browser audio is unavailable.
  }
}

export function playQuizFeedbackSound(
  contextRef: AudioContextRef,
  isCorrect: boolean,
) {
  const context = contextRef.current;
  if (!context || context.state === "closed") return;

  const play = () => {
    const now = context.currentTime + 0.015;
    if (isCorrect) {
      scheduleTone(context, now, 880, 1320, 0.34, "sine", 0.14);
      scheduleTone(context, now + 0.01, 1760, 2200, 0.2, "sine", 0.035);
      return;
    }

    scheduleTone(context, now, 150, 82, 0.17, "triangle", 0.15);
    scheduleTone(context, now + 0.25, 128, 68, 0.18, "triangle", 0.15);
  };

  if (context.state === "suspended") {
    void context.resume().then(play).catch(() => undefined);
    return;
  }
  play();
}