import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ClerkProvider, Show, SignIn, SignUp, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  ArrowDown, ArrowDownRight, ArrowLeft, ArrowRight, ArrowUp, Award, BookOpen, Check, ChevronRight, CircleHelp,
  Clock3, Code2, CookingPot, Flame, Gamepad2, GraduationCap, LockKeyhole, LogOut,
  Menu, Monitor, ShieldAlert, ShieldCheck, ShoppingBag, Smartphone, Sparkles, Star, Trophy, WifiOff, X,
} from 'lucide-react';
import {
  getGetDashboardQueryKey, getGetLeaderboardQueryKey, getHealthCheckQueryKey, getListLessonsQueryKey,
  useCheckLessonAnswer, useClaimDailyReward, useExtendPremium, useGetDashboard, useGetLeaderboard, useHealthCheck, useListLessons,
  useSubmitLessonAttempt, useUnlockChallenge, useUpdateProfile,
} from '@workspace/api-client-react';
import type { AgeGroup, LearningHub, Lesson } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { AccountIdCard } from '@/components/account-id-card';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { playQuizFeedbackSound, prepareQuizFeedbackAudio } from '@/lib/quiz-feedback-sounds';
import { safeChat, safeVoice, type ChatSafetyUser } from '@/lib/safe-chat';
import { RenewalPricing } from '@/components/renewal-pricing';
import { GamesPage, MiniGamePage } from '@/pages/GamesPage';
import { ShopPage } from '@/pages/ShopPage';
import { ModerationGate, OwnerPage, SafetyReportPage, SpookyPreference } from '@/pages/SafetyPages';
import { getGetModerationAccessQueryKey, useGetModerationAccess } from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import '@/index.css';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const appearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#245e52', colorForeground: '#24433d', colorMutedForeground: '#667c74',
    colorDanger: '#bd5149', colorBackground: '#fbfaf4', colorInput: '#fffef9',
    colorInputForeground: '#24433d', colorNeutral: '#d6e0d8', fontFamily: 'DM Sans',
    borderRadius: '16px',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fbfaf4] rounded-[24px] w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#24433d] font-bold',
    headerSubtitle: 'text-[#667c74]',
    socialButtonsBlockButtonText: 'text-[#24433d] font-semibold',
    formFieldLabel: 'text-[#24433d] font-semibold',
    footerActionLink: 'text-[#245e52] font-bold',
    footerActionText: 'text-[#667c74]',
    dividerText: 'text-[#667c74]',
    identityPreviewEditButton: 'text-[#245e52]',
    formFieldSuccessText: 'text-[#245e52]',
    alertText: 'text-[#8c3c36]',
    logoBox: 'rounded-xl',
    logoImage: 'h-10 w-auto',
    socialButtonsBlockButton: 'rounded-xl border-[#d6e0d8] hover:bg-[#f1f3e9]',
    formButtonPrimary: 'rounded-xl bg-[#245e52] text-[#fbfaf4] hover:bg-[#194b41]',
    formFieldInput: 'rounded-xl border-[#d6e0d8] bg-[#fffef9] text-[#24433d]',
    footerAction: 'border-t border-[#e4e9df]',
    dividerLine: 'bg-[#d6e0d8]',
    alert: 'rounded-xl',
    otpCodeFieldInput: 'rounded-lg border-[#d6e0d8]',
    formFieldRow: 'gap-2',
    main: 'gap-5',
  },
};

type Hub = LearningHub;
const hubInfo: Record<Hub, { title: string; short: string; description: string; className: string }> = {
  cooking: { title: 'Kitchen lab', short: 'Cooking', description: 'Build confidence with clever, safe kitchen skills.', className: 'hub-cooking' },
  coding: { title: 'Code studio', short: 'Coding', description: 'Turn small ideas into working bits of logic.', className: 'hub-coding' },
  studies: { title: 'Study nook', short: 'Studies', description: 'Make tricky ideas click, one short session at a time.', className: 'hub-studies' },
};
const ageGroups: { id: AgeGroup; title: string; detail: string }[] = [
  { id: 'kids', title: 'Kids', detail: 'A bright place to begin' },
  { id: 'teens', title: 'Teens', detail: 'Make room to go deeper' },
  { id: 'adults', title: 'Adults', detail: 'Learn something useful today' },
];
const learnerProfileSchema = z.object({
  displayName: z.string().trim().min(2, 'Choose a nickname with at least 2 characters.').max(24, 'Nicknames can be up to 24 characters.').regex(/^[\p{L}\p{N}][\p{L}\p{N} ._-]*$/u, 'Use letters, numbers, spaces, dots, dashes, or underscores.'),
  age: z.string().min(1, 'Choose your age.').regex(/^(?:[1-9]|[1-5]\d|60)$/, 'Choose an age from 1 to 60.'),
});
type LearnerProfileFormValues = z.infer<typeof learnerProfileSchema>;

function ageGroupForAge(age: number): AgeGroup {
  if (age <= 12) return 'kids';
  if (age <= 19) return 'teens';
  return 'adults';
}

function Brand({ light = false }: { light?: boolean }) {
  return <span className={`brand-mark ${light ? 'brand-light' : ''}`} aria-label="Bloxy Education Pro"><span className="brand-glyph">b</span><span>bloxy<span className="brand-education"> education pro</span></span></span>;
}

function Home() {
  return (
    <main className="landing">
      <header className="landing-nav page-wrap">
        <Link href="/" className="brand-link" data-testid="link-home"><Brand /></Link>
        <nav className="landing-links" aria-label="Main navigation">
          <a href="#hubs" data-testid="link-explore-hubs">Explore</a>
          <a href="#how-it-works" data-testid="link-how-it-works">How it works</a>
          <Link href="/offline" data-testid="link-offline-nav">Offline games</Link>
        </nav>
        <div className="landing-actions">
          <Link href="/sign-in" className="nav-signin" data-testid="link-sign-in">Sign in</Link>
          <Link href="/sign-up" className="button button-dark button-small" data-testid="link-get-started">Get started <ArrowRight size={16} /></Link>
        </div>
      </header>
      <section className="hero page-wrap">
        <div className="hero-copy reveal">
          <div className="eyebrow"><span className="eyebrow-dot" /> A little curiosity goes a long way</div>
          <h1>Small lessons.<br /><span>Big “I did it.”</span></h1>
          <p>Cooking, coding, and study sessions made for real life. Pick up a skill, collect your progress, and see what you can do next.</p>
          <div className="hero-actions">
            <Link href="/sign-up" className="button button-dark" data-testid="link-start-learning">Start learning <ArrowRight size={17} /></Link>
            <a href="#hubs" className="button button-quiet" data-testid="link-see-the-hubs">See the hubs <ArrowDownRight size={17} /></a>
          </div>
          <Link href="/offline" className="offline-home-link" data-testid="link-offline-home"><Gamepad2 size={15} /> Play offline games without signing in <ArrowRight size={14} /></Link>
          <div className="hero-footnote"><span className="avatar-stack"><i>B</i><i>+</i><i>!</i></span><span>For curious learners at every age</span></div>
        </div>
        <div className="hero-art reveal reveal-delay-2" aria-label="A playful learning map illustration">
          <div className="art-sun"></div><div className="art-orbit orbit-one"></div><div className="art-orbit orbit-two"></div>
          <div className="art-label label-top"><Sparkles size={15} /> made for momentum</div>
          <div className="art-book"><div className="book-spine"></div><div className="book-lines"><i></i><i></i><i></i></div><div className="book-star"><Star size={23} fill="currentColor" /></div></div>
          <div className="art-path"></div>
          <div className="art-tile art-tile-code"><Code2 size={24} /><span>TRY A TINY<br />CODE IDEA</span><b>01</b></div>
          <div className="art-tile art-tile-study"><BookOpen size={22} /><span>ONE NEW<br />THING LEARNED</span><b>02</b></div>
          <div className="art-tile art-tile-cook"><CookingPot size={23} /><span>MAKE IT<br />HAPPEN</span><b>03</b></div>
          <div className="art-sticker">progress<br />looks good<br />on you</div>
          <div className="art-bottom-note">YOUR NEXT LITTLE WIN <span>→</span></div>
        </div>
      </section>
      <div className="ticker" aria-label="Learn, practice, make progress">
        <div>LEARN A LITTLE <span>•</span> PRACTICE A LOT <span>•</span> MAKE YOURSELF PROUD <span>•</span> LEARN A LITTLE <span>•</span> PRACTICE A LOT <span>•</span></div>
      </div>
      <section className="hub-section page-wrap" id="hubs">
        <div className="section-heading reveal"><div><div className="eyebrow">Three ways in</div><h2>Follow your <em>what if.</em></h2></div><p>Choose a path. Every lesson is short, focused, and ends with a chance to show what stuck.</p></div>
        <div className="hub-grid">
          {(Object.keys(hubInfo) as Hub[]).map((hub, index) => {
            const info = hubInfo[hub];
            const Icon = hub === 'cooking' ? CookingPot : hub === 'coding' ? Code2 : GraduationCap;
            return <article className={`hub-card ${info.className} reveal reveal-delay-${index + 1}`} key={hub}>
              <div className="hub-card-top"><span className="hub-index">0{index + 1} / HUB</span><span className="hub-icon"><Icon size={22} /></span></div>
              <h3>{info.title}</h3><p>{info.description}</p>
              <Link href="/sign-up" className="hub-card-link" data-testid={`link-hub-${hub}`}>Find your first lesson <ChevronRight size={17} /></Link>
              <div className="hub-decoration">{hub === 'cooking' ? 'MIX' : hub === 'coding' ? '{ }' : 'A+'}</div>
            </article>;
          })}
        </div>
      </section>
      <section className="how-section" id="how-it-works">
        <div className="page-wrap how-layout">
          <div className="how-intro"><div className="eyebrow eyebrow-light">A good loop</div><h2>Curiosity in.<br /><span>Confidence out.</span></h2><p>No marathon sessions, no pressure to be perfect. Just one thoughtful step, then another.</p><Link href="/sign-up" className="button button-lime" data-testid="link-build-a-streak">Build your streak <ArrowRight size={17} /></Link></div>
          <div className="steps">
            <div className="step"><span>01</span><div><h3>Pick something that sparks</h3><p>Choose cooking, coding, or studies. Your next lesson is only a few minutes away.</p></div><BookOpen /></div>
            <div className="step"><span>02</span><div><h3>Try it for yourself</h3><p>Practice as you go, then answer a few quick questions to lock it in.</p></div><Check /></div>
            <div className="step"><span>03</span><div><h3>Watch progress add up</h3><p>Earn Bloxy Points and coins for completing lessons. Every small win counts.</p></div><Trophy /></div>
          </div>
        </div>
      </section>
      <section className="reward-section page-wrap">
        <div className="reward-art"><div className="reward-coin"><span>B</span></div><div className="reward-ring"></div><span className="reward-spark">+</span><span className="reward-spark two">+</span></div>
        <div className="reward-copy"><div className="eyebrow">A little something for showing up</div><h2>Every effort<br />has a <em>bright side.</em></h2><p>Earn coins and points as you learn. Claim a daily reward, take on age-group challenges, and see your name climb the leaderboard.</p><Link href="/sign-up" className="text-link" data-testid="link-earn-rewards">See what you can earn <ArrowRight size={17} /></Link></div>
      </section>
      <section className="safety-section">
        <div className="page-wrap safety-inner"><div className="safety-icon"><CircleHelp size={24} /></div><div><div className="eyebrow">A space that feels right</div><h2>Be known by your nickname.</h2><p>Bloxy is built for learners of all ages. Choose a nickname and an age group—no real names, birth dates, or phone numbers needed.</p></div><Link href="/sign-up" className="button button-outline" data-testid="link-create-nickname">Make your learning profile <ArrowRight size={17} /></Link></div>
      </section>
      <div className="page-wrap" id="renewal-pricing"><RenewalPricing /></div>
      <footer className="landing-footer page-wrap"><Link href="/" className="brand-link"><Brand /></Link><span>Keep learning at your own pace.</span><div className="device-support"><span><Monitor size={14} /> PC</span><span><Smartphone size={14} /> Android &amp; iOS</span><span className="vr-unsupported">VR unsupported</span></div><Link href="/sign-in" className="footer-signin" data-testid="link-footer-sign-in">Already have a profile? Sign in <ArrowRight size={15} /></Link></footer>
    </main>
  );
}

function HomeRedirect() {
  return <><Show when="signed-in"><Redirect to="/user-portal" /></Show><Show when="signed-out"><Home /></Show></>;
}

function ProfileCompletionGate({ children }: { children: ReactNode }) {
  const { data: dashboard, isLoading, isError, refetch } = useGetDashboard();
  if (isLoading) return <AppShell><LoadingPanel /></AppShell>;
  if (isError || !dashboard) return <AppShell><ErrorPanel retry={() => refetch()} /></AppShell>;
  if (!dashboard.profile.ageGroup) return <Redirect to="/user-portal" />;
  return children;
}

function Protected({ children, allowIncompleteProfile = false }: { children: ReactNode; allowIncompleteProfile?: boolean }) {
  return <><Show when="signed-in"><ModerationGate>{allowIncompleteProfile ? children : <ProfileCompletionGate>{children}</ProfileCompletionGate>}</ModerationGate></Show><Show when="signed-out"><Redirect to="/" /></Show></>;
}

function LogoutControl() {
  const { signOut } = useClerk();
  return <button className="logout-button" type="button" onClick={() => signOut({ redirectUrl: basePath || '/' })} data-testid="button-sign-out"><LogOut size={17} /><span>Sign out</span></button>;
}

function AppShell({ children }: { children: ReactNode }) {
  useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), staleTime: 60_000, retry: false } });
  const moderation = useGetModerationAccess({ query: { queryKey: getGetModerationAccessQueryKey() } });
  const [menuOpen, setMenuOpen] = useState(false);
  const [location] = useLocation();
  const links = [
    { href: '/user-portal', label: 'My learning', icon: BookOpen },
    { href: '/learn', label: 'Lesson library', icon: Sparkles },
    { href: '/games', label: 'Mini-games', icon: Gamepad2 },
    { href: '/shop', label: 'Coin shop', icon: ShoppingBag },
    { href: '/challenges', label: 'Challenges', icon: Award },
    { href: '/leaderboard', label: 'Leaderboard', icon: Trophy },
    { href: '/safety-report', label: 'Safety report', icon: ShieldCheck },
    ...(moderation.data?.isOwner ? [{ href: '/owner', label: 'Safety desk', icon: ShieldAlert }] : []),
  ];
  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}>
      <Link href="/user-portal" className="sidebar-brand" data-testid="link-portal-brand"><Brand light /></Link>
      <div className="sidebar-caption">YOUR SPACE</div>
      <nav className="side-nav" aria-label="Learner navigation">{links.map(({ href, label, icon: Icon }) => { const active = location === href || (href === '/games' && location.startsWith('/games/')); return <Link key={href} href={href} className={`side-link ${active ? 'side-link-active' : ''}`} onClick={() => setMenuOpen(false)} data-testid={`link-nav-${href.slice(1)}`}><Icon size={18} />{label}{active && <span className="nav-current" />}</Link>; })}</nav>
      <div className="sidebar-bottom"><div className="sidebar-note"><span className="note-mark"><Sparkles size={15} /></span><p>Small steps<br /><strong>count here.</strong></p></div><LogoutControl /></div>
    </aside>
    {menuOpen && <button className="menu-scrim" aria-label="Close navigation" onClick={() => setMenuOpen(false)} data-testid="button-close-menu" />}
    <div className="main-column">
      <header className="topbar"><button className="menu-toggle" aria-label="Open navigation" onClick={() => setMenuOpen(true)} data-testid="button-open-menu"><Menu size={21} /></button><span className="topbar-breadcrumb">YOUR LEARNING SPACE</span><div className="topbar-right"><span className="topbar-spark"><Sparkles size={15} /></span><span>Keep that curiosity going</span></div></header>
       <main className="portal-content">{location === '/user-portal' && <><AccountIdCard /><SpookyPreference /></>}{children}</main>
    </div>
  </div>;
}

function LoadingPanel({ label = 'Getting your learning space ready' }: { label?: string }) {
  return <div className="loading-panel" aria-label={label} data-testid="status-loading"><div className="skeleton skeleton-title" /><div className="skeleton skeleton-line" /><div className="skeleton-row"><div className="skeleton skeleton-card" /><div className="skeleton skeleton-card" /><div className="skeleton skeleton-card" /></div><span>{label}</span></div>;
}

function ErrorPanel({ retry, children = 'We couldn’t load this just now.' }: { retry: () => void; children?: ReactNode }) {
  return <div className="error-panel" role="alert" data-testid="status-error"><div className="error-symbol"><X size={19} /></div><div><strong>One tiny hiccup.</strong><p>{children}</p><button className="text-link" onClick={retry} data-testid="button-retry">Try again <ArrowRight size={15} /></button></div></div>;
}

function ProfileSetup() {
  const queryClient = useQueryClient();
  const mutation = useUpdateProfile();
  const [message, setMessage] = useState('');
  const form = useForm<LearnerProfileFormValues>({
    resolver: zodResolver(learnerProfileSchema),
    defaultValues: { displayName: '', age: '' },
  });
  const selectedAge = form.watch('age');
  const selectedAgeGroup = selectedAge ? ageGroupForAge(Number(selectedAge)) : null;
  const selectedGroupTitle = ageGroups.find(group => group.id === selectedAgeGroup)?.title;

  function submit(values: LearnerProfileFormValues) {
    const ageGroup = ageGroupForAge(Number(values.age));
    setMessage('');
    mutation.mutate({ data: { displayName: values.displayName, ageGroup } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
      },
      onError: () => setMessage('We couldn’t save that just now. Please try again.'),
    });
  }
  return <div className="setup-screen reveal">
    <div className="setup-aside"><div className="setup-mark"><Sparkles size={29} /></div><div className="eyebrow eyebrow-light">Before the first lesson</div><h1>Make this<br />space <em>yours.</em></h1><p>Just two things, then you’re ready to explore. Your nickname is how you’ll appear around Bloxy.</p><div className="setup-aside-stamp">YOU’RE IN<br />GOOD COMPANY <span>+</span></div></div>
    <Form {...form}>
    <form className="setup-form" onSubmit={form.handleSubmit(submit)} data-testid="form-profile-setup">
      <div className="eyebrow">A quick hello</div><h2>Set up your learner profile</h2><p className="form-intro">Please choose a nickname. Skip real names, birth dates, and phone numbers.</p>
      <FormField control={form.control} name="displayName" render={({ field }) => <FormItem>
        <FormLabel className="field-label" htmlFor="nickname">Your nickname</FormLabel>
        <FormControl><input id="nickname" className="text-input" placeholder="e.g. CuriousComet" maxLength={24} autoComplete="nickname" data-testid="input-nickname" {...field} /></FormControl>
        <span className="field-hint">2–24 characters. This is the name learners will see.</span>
        <FormMessage />
      </FormItem>} />
      <FormField control={form.control} name="age" render={({ field }) => <FormItem>
        <FormLabel className="field-label age-label" htmlFor="learner-age">Choose your age</FormLabel>
        <FormControl>
          <select id="learner-age" className="text-input" required data-testid="select-learner-age" {...field}>
            <option value="">Select an age from 1 to 60</option>
            {Array.from({ length: 60 }, (_, index) => index + 1).map(age => <option key={age} value={String(age)}>{age}</option>)}
          </select>
        </FormControl>
        <span className="field-hint">Your age selects a learning area. Bloxy saves only the age group.</span>
        {selectedGroupTitle && <span className="field-hint" role="status" data-testid="text-section-preview">You’ll join the {selectedGroupTitle} area.</span>}
        <FormMessage />
      </FormItem>} />
      {message && <p className="form-message" role="alert" data-testid="text-profile-error">{message}</p>}
      <button className="button button-dark setup-submit" type="submit" disabled={mutation.isPending} data-testid="button-save-profile">{mutation.isPending ? 'Saving your profile…' : 'Let’s get learning'} <ArrowRight size={17} /></button>
      <p className="privacy-note"><LockKeyhole size={14} /> Your profile saves a nickname and age group, not your exact age.</p>
    </form>
    </Form>
  </div>;
}

function HubPill({ hub }: { hub: Hub }) {
  return <span className={`hub-pill ${hubInfo[hub].className}`}>{hubInfo[hub].short}</span>;
}

const waterBearSuccessMessages = [
  '💧🐻 [Water Bear]: Woohoo! You’re climbing faster than bubbles rising in soda water! 🫧',
  '💧🐻 [Water Bear]: Keep streaking! If you reach Bedrock, I’ll cannonball into the pool 🏊‍♂️🐻',
  '💧🐻 [Water Bear]: Dirty Bronze is drowning in jealousy 😱💦',
  '💧🐻 [Water Bear]: Bro, you’re surfing grades like a pro wave rider 🌊',
];

function ActivityProgressCard({
  activityGrade,
  activityRank,
  streakDays,
}: {
  activityGrade: string;
  activityRank: number;
  streakDays: number;
}) {
  const daysTowardNextGrade =
    activityGrade === 'Bedrock' ? 5 : Math.max(0, streakDays % 5);
  const progressLabel =
    activityGrade === 'Bedrock'
      ? 'Top activity grade reached'
      : `${5 - daysTowardNextGrade} more active ${5 - daysTowardNextGrade === 1 ? 'day' : 'days'} to the next grade`;

  return <section className="activity-panel surface reveal" data-testid="panel-activity-rank">
    <div className="activity-panel-main">
      <span className="eyebrow">WATER BEAR ACTIVITY</span>
      <div className="activity-grade-row"><h2 data-testid="text-activity-grade">{activityGrade}</h2></div>
      <p>Activity grades advance every five streak days. They’re separate from Bloxy Points.</p>
      <div className="activity-progress-track" role="progressbar" aria-label="Progress to next activity grade" aria-valuemin={0} aria-valuemax={5} aria-valuenow={daysTowardNextGrade}><span style={{ width: `${daysTowardNextGrade * 20}%` }} /></div>
      <small>{progressLabel}</small>
    </div>
    <div className="activity-rank-box"><span>ACTIVITY RANK</span><strong data-testid="text-activity-rank">#{activityRank}</strong><small>Separate from points position</small></div>
  </section>;
}

function DashboardPage() {
  const queryClient = useQueryClient();
  const { data: dashboard, isLoading, isError, refetch } = useGetDashboard();
  const reward = useClaimDailyReward();
  const premiumExtend = useExtendPremium();
  const [rewardMessage, setRewardMessage] = useState('');
  const autoClaimStarted = useRef(false);
  const claim = () => reward.mutate(undefined, {
    onSuccess: result => {
      const rewardSummary = `+${result.coinsAwarded} coins and +${result.pointsAwarded} points added.`;
      if (result.alreadyClaimed) {
        setRewardMessage('Your daily reward has already been collected.');
      } else if (result.streakEvent === 'reset') {
        setRewardMessage([
          rewardSummary,
          `💧🐻 [Water Bear]: ${result.profile.displayName}, you vanished for 2 days!`,
          '💧🐻 [Water Bear]: Splash! You fell to Bronze #55... I spilled my water bucket 😢',
          '💧🐻 [Water Bear]: Please continue your streak or I’ll start crying like a fountain 🌊😭',
        ].join('\n'));
      } else if (result.streakEvent === 'continued') {
        const message = waterBearSuccessMessages[Math.floor(Math.random() * waterBearSuccessMessages.length)];
        setRewardMessage(`${rewardSummary}\n${message}`);
      } else {
        setRewardMessage(rewardSummary);
      }
      queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
    },
  });
  useEffect(() => {
    if (
      dashboard &&
      dashboard.profile.ageGroup &&
      !dashboard.claimedDailyReward &&
      !autoClaimStarted.current
    ) {
      autoClaimStarted.current = true;
      claim();
    }
  }, [dashboard?.claimedDailyReward, dashboard?.profile.ageGroup]);

  if (isLoading) return <AppShell><LoadingPanel /></AppShell>;
  if (isError || !dashboard) return <AppShell><ErrorPanel retry={() => refetch()} /></AppShell>;
  if (!dashboard.profile.ageGroup) return <AppShell><ProfileSetup /></AppShell>;
  return <AppShell>
    <div className="welcome-row reveal"><div><div className="eyebrow">Your learner space</div><h1>Good to see you, <em>{dashboard.profile.displayName}</em></h1><p>Ready for one small win today?</p></div><div className="welcome-stamp"><span>YOUR PACE</span><b>YOUR<br />PROGRESS</b><Sparkles size={17} /></div></div>
    <div className="stats-strip reveal reveal-delay-1">
      <div className="stat-block"><span className="stat-icon stat-coins"><span>B</span></span><div><small>COINS</small><strong data-testid="text-coins">{dashboard.profile.coins}</strong></div></div>
      <div className="stat-block"><span className="stat-icon stat-points"><Star size={18} /></span><div><small>BLOXY POINTS</small><strong data-testid="text-points">{dashboard.profile.points}</strong></div></div>
      <div className="stat-block"><span className="stat-icon stat-lessons"><BookOpen size={18} /></span><div><small>LESSONS DONE</small><strong data-testid="text-completed-lessons">{dashboard.profile.completedLessons}</strong></div></div>
      <div className="stat-block"><span className="stat-icon stat-streak"><Flame size={18} /></span><div><small>DAY STREAK</small><strong data-testid="text-streak-days">{dashboard.profile.streakDays ?? 0}<small> days</small></strong></div></div>
      <div className="stat-age"><span>LEARNING AS</span><strong>{dashboard.profile.ageGroup}</strong></div>
    </div>
    <p className="streak-caption" data-testid="text-streak-reset">A break of two days resets your streak and activity rank; grades rise every five active streak days.</p>
    <ActivityProgressCard activityGrade={dashboard.profile.activityGrade} activityRank={dashboard.profile.activityRank} streakDays={dashboard.profile.streakDays} />
    <div className="dashboard-grid">
      <section className="daily-card reveal reveal-delay-2"><div className="daily-orbit"><div className="daily-coin">B</div><Sparkles className="daily-spark" size={19} /></div><div className="daily-content"><div className="eyebrow eyebrow-light">The daily little lift</div><h2>Show up.<br />Get a little extra.</h2><p>Base reward: 5 coins + 2 points. {Number(dashboard.profile.premiumDays ?? 0) > 0 ? 'Active Premium adds 2 coins + 2 points.' : 'Keep climbing to find your next boost.'}</p>{rewardMessage && <span className="reward-feedback" role="status" data-testid="text-reward-result">{rewardMessage}</span>}<button className="button button-lime" onClick={claim} disabled={dashboard.claimedDailyReward || reward.isPending} data-testid="button-claim-reward">{reward.isPending ? 'Adding reward…' : dashboard.claimedDailyReward ? 'Collected for today' : 'Collect daily reward'} <ArrowRight size={16} /></button>{reward.isError && <p className="inline-error" role="alert">Couldn’t collect your reward. Try again.</p>}</div></section>
      <section className="quickstart-card surface reveal reveal-delay-3"><div className="quickstart-top"><div><div className="eyebrow">Keep your rhythm</div><h2>What sounds good?</h2></div><Flame size={21} /></div><p>Pick a hub and find a lesson that fits your day.</p><div className="quickstart-options">{(Object.keys(hubInfo) as Hub[]).map(hub => { const Icon = hub === 'cooking' ? CookingPot : hub === 'coding' ? Code2 : GraduationCap; return <Link key={hub} href={`/learn?hub=${hub}`} className={`quick-hub ${hubInfo[hub].className}`} data-testid={`link-quick-${hub}`}><Icon size={18} /><span>{hubInfo[hub].short}</span><ChevronRight size={15} /></Link>; })}</div><Link href="/learn" className="text-link" data-testid="link-all-lessons">Browse all lessons <ArrowRight size={15} /></Link></section>
    </div>
    <section className="premium-strip surface reveal reveal-delay-2" data-testid="panel-premium-days"><div className="premium-symbol"><Star size={20} /></div><div className="premium-copy"><span className="eyebrow">BLOXY PREMIUM</span><strong>{dashboard.profile.premiumDays ?? 0} days active</strong><p>First place can unlock a four-day Premium Boost after a lesson win.</p></div>{(dashboard.profile.premiumDays ?? 0) > 0 && (dashboard.profile.premiumDays ?? 0) < 6 ? <button className="button button-dark" disabled={premiumExtend.isPending} onClick={() => premiumExtend.mutate(undefined, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() }); } })} data-testid="button-extend-premium">{premiumExtend.isPending ? 'Extending…' : 'Extend to 6 days'} <ArrowRight size={16} /></button> : (dashboard.profile.premiumDays ?? 0) >= 6 ? <span className="premium-maxed">6 days reached</span> : <span className="premium-earn">Earn your first-place boost</span>}{premiumExtend.isError && <span className="inline-error" role="alert">Couldn’t extend Premium.</span>}</section>
     <RenewalPricing mazeEligible={dashboard.profile.mazeDiscountEligible} />
    <LocalSafetyChecker />
    <OfflineGamesMenu />
    <section className="recent-section reveal reveal-delay-3"><div className="section-title-row"><div><div className="eyebrow">Your trail so far</div><h2>Recent lessons</h2></div><Link href="/learn" className="text-link" data-testid="link-discover-more">Discover more <ArrowRight size={15} /></Link></div>
      {dashboard.recentCompletions.length ? <div className="recent-list">{dashboard.recentCompletions.map(item => <div className="recent-row" key={`${item.lessonId}-${item.completedAt}`} data-testid={`row-recent-${item.lessonId}`}><span className={`recent-icon ${hubInfo[item.hub].className}`}>{item.hub === 'cooking' ? <CookingPot size={18} /> : item.hub === 'coding' ? <Code2 size={18} /> : <GraduationCap size={18} />}</span><div className="recent-name"><strong>{item.title}</strong><small>{item.correctCount} of {item.totalQuestions} correct</small></div><HubPill hub={item.hub} /><span className="recent-points">+{item.pointsEarned} pts</span></div>)}</div> : <div className="empty-state"><span className="empty-icon"><BookOpen size={23} /></span><div><strong>Your learning trail starts here.</strong><p>Finish a lesson and your progress will show up here.</p></div><Link href="/learn" className="text-link" data-testid="link-start-first-lesson">Find a first lesson <ArrowRight size={15} /></Link></div>}
    </section>
  </AppShell>;
}

function LessonCard({ lesson }: { lesson: Lesson }) {
  const Icon = lesson.hub === 'cooking' ? CookingPot : lesson.hub === 'coding' ? Code2 : GraduationCap;
  return <Link href={`/learn/${encodeURIComponent(lesson.id)}`} className={`lesson-card surface lift ${hubInfo[lesson.hub].className}`} data-testid={`card-lesson-${lesson.id}`}>
    <div className="lesson-card-head"><span className="lesson-icon"><Icon size={22} /></span><HubPill hub={lesson.hub} /></div>
    <h3>{lesson.title}</h3><p>{lesson.description}</p><div className="lesson-tags">{lesson.ageGroup && <span>{lesson.ageGroup}</span>}{lesson.skillLevel && <span>{lesson.skillLevel}</span>}{lesson.subject && <span>{lesson.subject}</span>}</div><div className="lesson-card-foot"><span><Clock3 size={14} /> {lesson.durationMinutes} min</span><span>{lesson.questions.length} questions</span><span className="lesson-open"><ArrowRight size={17} /></span></div>
  </Link>;
}

function LessonsPage() {
  const params = new URLSearchParams(window.location.search);
  const initialHub = params.get('hub');
  const [hub, setHub] = useState<Hub | 'all'>(initialHub === 'cooking' || initialHub === 'coding' || initialHub === 'studies' ? initialHub : 'all');
  const queryParams = hub === 'all' ? undefined : { hub };
  const { data: lessons, isLoading, isError, refetch } = useListLessons(queryParams);
  const filters: { id: Hub | 'all'; label: string }[] = [{ id: 'all', label: 'Everything' }, { id: 'cooking', label: 'Cooking' }, { id: 'coding', label: 'Coding' }, { id: 'studies', label: 'Studies' }];
  return <AppShell><div className="page-heading reveal"><div><div className="eyebrow">Pick a path, any path</div><h1>Lesson <em>library</em></h1><p>Quick sessions, real skills, and a chance to put what you learned to the test.</p></div><div className="heading-scribble">A LITTLE<br />GOES FAR <ArrowDownRight size={17} /></div></div>
    <div className="filter-row" role="group" aria-label="Filter lessons by hub">{filters.map(item => <button key={item.id} onClick={() => setHub(item.id)} className={`filter-chip ${hub === item.id ? 'filter-active' : ''}`} aria-pressed={hub === item.id} data-testid={`button-filter-${item.id}`}>{item.label}</button>)}</div>
    {isLoading ? <LoadingPanel label="Finding the right lessons" /> : isError ? <ErrorPanel retry={() => refetch()}>The lesson library took a little pause.</ErrorPanel> : lessons?.length ? <div className="lesson-grid">{lessons.map((lesson, i) => <div className={`reveal reveal-delay-${(i % 3) + 1}`} key={lesson.id}><LessonCard lesson={lesson} /></div>)}</div> : <div className="empty-state lessons-empty"><span className="empty-icon"><Sparkles size={23} /></span><div><strong>No lessons in this hub just yet.</strong><p>Try another hub to find something to explore.</p></div>{hub !== 'all' && <button className="text-link" onClick={() => setHub('all')} data-testid="button-show-all-lessons">Show all lessons <ArrowRight size={15} /></button>}</div>}
  </AppShell>;
}

function LessonPage({ params }: { params: { lessonId?: string } }) {
  const id = params.lessonId ?? '';
  const queryClient = useQueryClient();
  const { data: lessons, isLoading, isError, refetch } = useListLessons(undefined, { query: { queryKey: getListLessonsQueryKey(), enabled: !!id } });
  const submitAttempt = useSubmitLessonAttempt();
  const checkAnswer = useCheckLessonAnswer();
  const audioContextRef = useRef<AudioContext | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [answerFeedback, setAnswerFeedback] = useState<Record<number, 'checking' | 'correct' | 'incorrect' | 'error'>>({});
  const [result, setResult] = useState<Awaited<ReturnType<typeof submitAttempt.mutateAsync>> | null>(null);
  useEffect(() => () => {
    const context = audioContextRef.current;
    audioContextRef.current = null;
    if (context && context.state !== 'closed') void context.close().catch(() => undefined);
  }, []);
  const lesson = lessons?.find(item => item.id === id);
  const allAnswersSelected = lesson?.questions.every((question, index) => {
    const answer = answers[index];
    return Number.isInteger(answer) && answer >= 0 && answer < question.options.length;
  }) ?? false;
  const chooseAnswer = (questionIndex: number, questionId: string, answerIndex: number) => {
    prepareQuizFeedbackAudio(audioContextRef);
    setAnswers(current => {
      const questionCount = lesson?.questions.length ?? questionIndex + 1;
      const next = Array.from({ length: questionCount }, (_, index) => current[index] ?? -1);
      next[questionIndex] = answerIndex;
      return next;
    });
    submitAttempt.reset();
    setAnswerFeedback(current => ({ ...current, [questionIndex]: 'checking' }));
    checkAnswer.mutate({ lessonId: id, data: { questionId, answerIndex } }, {
      onSuccess: outcome => {
        setAnswerFeedback(current => ({
          ...current,
          [questionIndex]: outcome.isCorrect ? 'correct' : 'incorrect',
        }));
        playQuizFeedbackSound(audioContextRef, outcome.isCorrect);
      },
      onError: () => {
        setAnswerFeedback(current => ({ ...current, [questionIndex]: 'error' }));
      },
    });
  };
  const submit = () => {
    if (!lesson || !allAnswersSelected) return;
    const completedAnswers = lesson.questions.map((_question, index) => answers[index]);
    submitAttempt.mutate({ lessonId: lesson.id, data: { answers: completedAnswers } }, {
      onSuccess: outcome => {
        setResult(outcome);
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
      },
    });
  };
  if (isLoading) return <AppShell><LoadingPanel label="Opening your lesson" /></AppShell>;
  if (isError) return <AppShell><ErrorPanel retry={() => refetch()}>We couldn’t open this lesson right now.</ErrorPanel></AppShell>;
  if (!lesson) return <AppShell><div className="empty-state"><div><strong>We couldn’t find that lesson.</strong><p>Head back to the lesson library to choose another.</p></div><Link href="/learn" className="text-link" data-testid="link-back-to-lessons">Back to lessons <ArrowRight size={15} /></Link></div></AppShell>;
  if (result) return <AppShell><section className={`result-card ${result.passed ? 'result-pass' : 'result-keep-going'} reveal`} data-testid="section-lesson-result"><div className="result-symbol">{result.passed ? <Trophy size={30} /> : <Sparkles size={29} />}</div><div className="eyebrow">{result.passed ? 'Lesson complete' : 'Good practice'}</div><h1>{result.passed ? 'You did it.' : 'You’re getting there.'}</h1><p className="result-subtitle">{result.correctCount} of {result.totalQuestions} answers correct on <strong>{lesson.title}</strong>.</p><div className="result-rewards"><div><span>COINS EARNED</span><strong>+{result.coinsEarned}</strong></div><div><span>BLOXY POINTS</span><strong>+{result.pointsEarned}</strong></div></div>{result.premiumDaysAwarded > 0 && <div className="premium-award" role="status" data-testid="text-premium-award"><Star size={17} /> First place! You earned a {result.premiumDaysAwarded}-day Premium Boost.</div>}<p className="result-encouragement">{result.passed ? 'That’s a win worth keeping. What will you try next?' : 'Every try makes the next one easier. You can revisit this lesson any time.'}</p><div className="result-actions"><Link href="/learn" className="button button-dark" data-testid="link-continue-learning">Choose another lesson <ArrowRight size={17} /></Link><Link href="/user-portal" className="button button-quiet" data-testid="link-return-dashboard">My learning</Link></div></section></AppShell>;
  return <AppShell><div className="quiz-wrap reveal"><Link href="/learn" className="back-link" data-testid="link-lesson-library"><ArrowRight size={15} /> Lesson library</Link><div className={`quiz-hero ${hubInfo[lesson.hub].className}`}><div className="quiz-meta"><HubPill hub={lesson.hub} /><span><Clock3 size={14} /> {lesson.durationMinutes} min</span>{lesson.skillLevel && <span>{lesson.skillLevel}</span>}{lesson.subject && <span>{lesson.subject}</span>}</div><h1>{lesson.title}</h1><p>{lesson.description}</p><div className="quiz-progress-label"><span>YOUR QUIZ</span><span>{answers.filter(v => v >= 0).length} / {lesson.questions.length} answered</span></div><div className="quiz-progress"><i style={{ width: `${lesson.questions.length ? (answers.filter(v => v >= 0).length / lesson.questions.length) * 100 : 0}%` }} /></div></div>
      <section className="lesson-content-card surface"><div className="lesson-content-heading"><div><div className="eyebrow">Learn by doing</div><h2>Take a look, then give it a go.</h2></div>{lesson.ageGroup && <span className="lesson-audience">For {lesson.ageGroup}</span>}</div>{lesson.hub === 'cooking' && <p className="cooking-safety-note"><ShieldCheck size={16} /> Ask a trusted adult to supervise cooking, especially around heat and sharp tools.</p>}<div className="lesson-materials"><h3>{lesson.hub === 'cooking' ? 'Ingredients & materials' : 'What you’ll need'}</h3>{lesson.materials.length ? <ul>{lesson.materials.map((item, i) => <li key={`${i}-${item}`}>{item}</li>)}</ul> : <p>No materials needed—just bring your curiosity.</p>}</div><div className="lesson-steps"><h3>Steps</h3>{lesson.steps.length ? <ol>{lesson.steps.map((step, i) => <li key={`${i}-${step}`}><span>{String(i + 1).padStart(2, '0')}</span><p>{step}</p></li>)}</ol> : <p>Follow the quiz prompts to explore this lesson.</p>}</div></section>
      {lesson.questions.length ? <div className="question-list">{lesson.questions.map((question, qi) => {
        const feedback = answerFeedback[qi];
        return <section className="question-card surface" key={question.id}>
          <div className="question-number">QUESTION {String(qi + 1).padStart(2, '0')}</div>
          <h2>{question.prompt}</h2>
          <div className="answer-options">{question.options.map((option, oi) => <button type="button" key={`${question.id}-${oi}`} className={`answer-option ${answers[qi] === oi ? 'answer-selected' : ''}`} onClick={() => chooseAnswer(qi, question.id, oi)} disabled={checkAnswer.isPending || submitAttempt.isPending} aria-pressed={answers[qi] === oi} data-testid={`button-answer-${qi}-${oi}`}><span>{String.fromCharCode(65 + oi)}</span>{option}{answers[qi] === oi && <Check size={17} />}</button>)}</div>
          {feedback && <p className={`answer-feedback answer-feedback-${feedback}`} role="status" data-testid={`text-answer-feedback-${qi}`}>{feedback === 'checking' ? 'Checking your answer…' : feedback === 'correct' ? 'That’s right!' : feedback === 'incorrect' ? 'Not quite—try another answer.' : 'Couldn’t check that answer. Please try again.'}</p>}
        </section>;
      })}
      <div className="quiz-submit-row">{submitAttempt.isError && <span className="inline-error" role="alert">Your answers didn’t go through. Please try again.</span>}<button className="button button-dark" onClick={submit} disabled={answers.length !== lesson.questions.length || answers.some(answer => answer < 0) || checkAnswer.isPending || submitAttempt.isPending} data-testid="button-submit-quiz">{submitAttempt.isPending ? 'Checking your answers…' : 'Check my answers'} <ArrowRight size={17} /></button></div></div> : <div className="empty-state"><div><strong>This lesson is being prepared.</strong><p>There are no quiz questions available yet.</p></div><Link href="/learn" className="text-link">Back to the library <ArrowRight size={15} /></Link></div>}</div></AppShell>;
}

function ChallengesPage() {
  const queryClient = useQueryClient();
  const { data: dashboard, isLoading, isError, refetch } = useGetDashboard();
  const unlock = useUnlockChallenge();
  const [feedback, setFeedback] = useState('');
  if (isLoading) return <AppShell><LoadingPanel label="Checking your challenge access" /></AppShell>;
  if (isError || !dashboard) return <AppShell><ErrorPanel retry={() => refetch()} /></AppShell>;
  const unlocked = dashboard.unlockedChallenges;
  return <AppShell><div className="page-heading reveal"><div><div className="eyebrow">Ready when you are</div><h1>Challenge <em>board</em></h1><p>Choose the age-group challenge you’d like to open. Each has its own pace and level.</p></div><div className="heading-scribble">YOUR NEXT<br />LEVEL <Award size={18} /></div></div>
    <div className="challenge-intro surface"><div className="challenge-intro-icon"><Trophy size={24} /></div><div><strong>A little more stretch. A lot more progress.</strong><p>Unlock access with your learner profile. Challenge access is available by age group.</p></div><span className="challenge-balance"><b>{dashboard.profile.coins}</b><small>COINS</small></span></div>
    {feedback && <p className="challenge-feedback" role="status" data-testid="text-challenge-feedback">{feedback}</p>}
    {unlock.isError && <p className="inline-error challenge-error" role="alert">Couldn’t unlock this challenge. Check your balance and try again.</p>}
    <div className="challenge-grid">{ageGroups.map((group, i) => { const isUnlocked = unlocked.includes(group.id); const isCurrent = dashboard.profile.ageGroup === group.id; return <article className={`challenge-card surface challenge-${group.id} reveal reveal-delay-${i + 1}`} key={group.id} data-testid={`card-challenge-${group.id}`}><div className="challenge-card-top"><span className="challenge-level">CHALLENGE ACCESS</span>{isUnlocked ? <span className="unlocked-tag"><Check size={13} /> OPEN</span> : <span className="locked-tag"><LockKeyhole size={13} /> LOCKED</span>}</div><div className="challenge-illustration"><span>{group.id === 'kids' ? '01' : group.id === 'teens' ? '02' : '03'}</span><div className="challenge-orbit"><Sparkles size={25} /></div></div><h2>{group.title}</h2><p>{group.detail}. Open a challenge set designed for this learner group.</p>{isCurrent && <span className="current-group-note">YOUR AGE GROUP</span>}{isUnlocked ? <button className="button button-unlocked" disabled data-testid={`button-challenge-open-${group.id}`}><Check size={16} /> Access unlocked</button> : <button className="button button-dark challenge-unlock" disabled={unlock.isPending} onClick={() => { setFeedback(''); unlock.mutate({ data: { ageGroup: group.id } }, { onSuccess: response => { setFeedback(response.unlocked ? `${group.title} challenge access unlocked.` : `${group.title} challenge access is already open.`); queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() }); } }); }} data-testid={`button-unlock-${group.id}`}>{unlock.isPending ? 'Unlocking…' : 'Unlock access'} <ArrowRight size={16} /></button>}</article>; })}</div>
    <p className="challenge-footnote"><LockKeyhole size={14} /> You can unlock challenge access for a group at any time. A successful unlock updates your coin balance.</p>
  </AppShell>;
}

function LeaderboardPage() {
  const { data: rows, isLoading, isError, refetch } = useGetLeaderboard();
  return <AppShell><div className="page-heading reveal"><div><div className="eyebrow">A little friendly momentum</div><h1>Bloxy <em>leaderboard</em></h1><p>Celebrating the points learners have earned by showing up and finishing lessons.</p></div><div className="leaderboard-medal"><Trophy size={28} /><span>POINTS<br />TELL A STORY</span></div></div>
    <section className="leaderboard-panel surface reveal reveal-delay-1"><div className="leaderboard-panel-head"><div><span className="eyebrow">THE LEARNING LADDER</span><h2>Top learners</h2></div><span className="leaderboard-cycle"><span /> LIVE RANKINGS</span></div>
      {isLoading ? <LoadingPanel label="Loading learner rankings" /> : isError ? <ErrorPanel retry={() => refetch()}>The leaderboard couldn’t load right now.</ErrorPanel> : rows?.length ? <><div className="podium" data-testid="leaderboard-top-three">{rows.filter(row => row.rank <= 3).sort((a, b) => a.rank - b.rank).map(row => <div key={`podium-${row.rank}`} className={`podium-place podium-${row.rank}`} data-testid={`card-podium-${row.rank}`}><span className="podium-rank">{row.rank === 1 ? '01 / FIRST' : row.rank === 2 ? '02 / SECOND' : '03 / THIRD'}</span><span className="podium-avatar">{row.displayName.slice(0, 1).toUpperCase()}</span><strong>{row.displayName}</strong><span className="podium-score">{row.points.toLocaleString()} pts</span><small className="podium-activity">{row.activityGrade} · Activity #{row.activityRank}</small><small>{row.completedLessons} lessons</small></div>)}</div><div className="leaderboard-table"><div className="leaderboard-header"><span>RANK</span><span>LEARNER / ACTIVITY</span><span>LESSONS</span><span>BLOXY POINTS</span></div>{rows.map((row, i) => <div className={`leaderboard-row ${row.rank <= 3 ? `rank-top rank-${row.rank}` : ''}`} key={`${row.rank}-${row.displayName}`} data-testid={`row-leaderboard-${i}`}><span className="rank-number">{String(row.rank).padStart(2, '0')}</span><span className="learner-name"><span className="rank-avatar">{row.displayName.slice(0, 1).toUpperCase()}</span><span className="learner-name-copy"><strong>{row.displayName}</strong><small className="activity-leaderboard-meta">{row.activityGrade} · Activity rank #{row.activityRank}</small></span></span><span className="lesson-count">{row.completedLessons}</span><strong className="points-count">{row.points.toLocaleString()}</strong></div>)}</div></> : <div className="empty-state leaderboard-empty"><span className="empty-icon"><Trophy size={23} /></span><div><strong>The leaderboard is ready for its first learners.</strong><p>Complete lessons to earn points and join the rankings.</p></div><Link href="/learn" className="text-link" data-testid="link-leaderboard-learn">Browse lessons <ArrowRight size={15} /></Link></div>}
      <div className="leaderboard-foot"><span>Only your chosen learner nickname appears here.</span><Link href="/learn" className="text-link" data-testid="link-leaderboard-lessons">Earn more points <ArrowRight size={15} /></Link></div>
    </section>
  </AppShell>;
}

function LocalSafetyChecker() {
  const [draft, setDraft] = useState('');
  const [mode, setMode] = useState<'text' | 'voice'>('voice');
  const [user, setUser] = useState<ChatSafetyUser>({ name: 'Learner' });
  const [result, setResult] = useState('');
  function check(event: FormEvent) {
    event.preventDefault();
    const next = { ...user };
    setResult((mode === 'voice' ? safeVoice : safeChat)(next, draft));
    setUser(next);
  }
  return <section className="safety-checker surface" data-testid="panel-local-safety">
    <div className="safety-checker-heading"><span className="safety-checker-icon"><ShieldCheck size={20} /></span><div><span className="eyebrow">LOCAL-ONLY SIMULATION</span><h2>Check chat or a voice transcript</h2></div></div>
    <p>Two warnings, then a 24-hour simulated mute. Text and voice transcripts share strikes. Nothing is sent or saved; leaving this page resets the simulation. This basic word filter can miss unsafe context. Live chat and microphone recording are not enabled.</p>
    <label htmlFor="safety-mode">Check type </label>
    <select id="safety-mode" value={mode} onChange={event => { setMode(event.target.value as 'text' | 'voice'); setResult(''); }} data-testid="select-safety-mode">
      <option value="voice">Voice transcript (typed)</option><option value="text">Text chat</option>
    </select>
    <p data-testid="text-safety-strikes">Strikes: {user.strikes ?? 0}{user.mutedUntil ? ` · Simulated mute expires ${new Date(user.mutedUntil).toLocaleString()}` : ''}</p>
    <form className="safety-checker-form" onSubmit={check}>
      <label className="sr-only" htmlFor="safety-draft">{mode === 'voice' ? 'Voice transcript to check locally' : 'Text to check locally'}</label>
      <input id="safety-draft" value={draft} maxLength={240} onChange={event => { setDraft(event.target.value); setResult(''); }} placeholder={mode === 'voice' ? 'Type or paste a voice transcript…' : 'Type a short phrase to check…'} data-testid="input-safety-draft" />
      <button className="button button-dark" type="submit" disabled={!draft.trim()} data-testid="button-check-safety">Check locally <ArrowRight size={15} /></button>
    </form>
    {result && <div className="safety-check-result" role="status" data-testid="text-safety-result"><strong>{result}</strong></div>}
  </section>;
}

const offlineGames = [
  { name: 'Target Practice', kind: 'target' as const },
  { name: 'Puzzle Game', kind: 'puzzle' as const },
  { name: 'Racing Game' },
  { name: 'Platformer' },
  { name: 'Memory Quiz' },
  { name: 'Adventure Run' },
  { name: 'Cooking Mini-Game' },
  { name: 'Coding Challenge' },
  { name: 'Math Quiz' },
  { name: 'Survival Game' },
];

function OfflineGamesMenu() {
  const [gameOpen, setGameOpen] = useState<'target' | 'puzzle' | null>(() => navigator.onLine ? null : 'target');
  return <section className="offline-games surface" data-testid="panel-offline-games">
    <div className="offline-games-head"><div><span className="eyebrow">TAKE A QUICK BREAK</span><h2>Offline games</h2><p>Two small games are ready. More are coming soon.</p></div><span className="offline-games-icon"><Gamepad2 size={22} /></span></div>
    <div className="offline-game-list">{offlineGames.map((game, index) => <div className={`offline-game-row ${game.kind ? 'game-available' : 'game-coming'}`} key={game.name} data-testid={`row-offline-game-${index}`}>
      <span className="offline-game-number">{String(index + 1).padStart(2, '0')}</span><strong>{game.name}</strong>
      {game.kind ? <button type="button" className="game-play-link" onClick={() => setGameOpen(game.kind ?? null)} data-testid={`button-play-offline-game-${index}`}>Play <ArrowRight size={14} /></button> : <span className="coming-tag">COMING SOON</span>}
    </div>)}</div>
    {gameOpen === 'target' && <TargetArcade onClose={() => setGameOpen(null)} />}
    {gameOpen === 'puzzle' && <PuzzleMiniGame onClose={() => setGameOpen(null)} />}
  </section>;
}

function TargetArcade({ onClose }: { onClose: () => void }) {
  const [cursor, setCursor] = useState(0);
  const [hits, setHits] = useState<Set<number>>(() => new Set());
  const won = hits.size >= 10;
  const hitTarget = (index: number) => setHits(current => {
    if (current.has(index)) return current;
    const next = new Set(current);
    next.add(index);
    return next;
  });
  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' ', 'Enter'].includes(event.key)) event.preventDefault();
      if (event.key === 'ArrowLeft') setCursor(i => i % 5 === 0 ? i + 4 : i - 1);
      if (event.key === 'ArrowRight') setCursor(i => i % 5 === 4 ? i - 4 : i + 1);
      if (event.key === 'ArrowUp') setCursor(i => Math.max(0, i - 5));
      if (event.key === 'ArrowDown') setCursor(i => Math.min(9, i + 5));
      if (event.key === ' ' || event.key === 'Enter') hitTarget(cursor);
      if (event.key === 'Escape') onClose();
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [cursor, onClose]);
  const reset = () => { setHits(new Set()); setCursor(0); };
  return <div className="arcade-overlay"><section className="arcade-dialog" role="dialog" aria-modal="true" aria-labelledby="arcade-title" data-testid="dialog-target-arcade"><div className="arcade-top"><div><span className="eyebrow">OFFLINE ARCADE</span><h2 id="arcade-title">Target practice</h2></div><button className="arcade-close" onClick={onClose} aria-label="Close target game" data-testid="button-close-arcade"><X size={20} /></button></div><p className="arcade-instructions">A calm, no-pressure game. Move the ring with arrow keys or the controls, then hit a target. Find all 10.</p><div className="arcade-score" data-testid="text-arcade-score"><strong>{hits.size}</strong><span> / 10 targets</span>{won && <b>All targets found. Nicely done.</b>}</div><div className={`target-field ${won ? 'target-field-won' : ''}`}>{Array.from({ length: 10 }, (_, i) => <button key={i} className={`arcade-target target-pos-${i} ${cursor === i ? 'target-selected' : ''} ${hits.has(i) ? 'target-hit' : ''}`} onClick={() => { setCursor(i); hitTarget(i); }} aria-label={`Target ${i + 1}${hits.has(i) ? ', found' : ''}`} disabled={hits.has(i)} data-testid={`button-target-${i}`}><span>{hits.has(i) ? <Check size={16} /> : i + 1}</span></button>)}</div><div className="arcade-controls"><div className="dpad" aria-label="Touch movement controls"><button onClick={() => setCursor(i => Math.max(0, i - 5))} aria-label="Move up" data-testid="button-game-up"><ArrowUp size={17} /></button><button onClick={() => setCursor(i => i % 5 === 0 ? i + 4 : i - 1)} aria-label="Move left" data-testid="button-game-left"><ArrowLeft size={17} /></button><button onClick={() => setCursor(i => i % 5 === 4 ? i - 4 : i + 1)} aria-label="Move right" data-testid="button-game-right"><ArrowRight size={17} /></button><button onClick={() => setCursor(i => Math.min(9, i + 5))} aria-label="Move down" data-testid="button-game-down"><ArrowDown size={17} /></button></div><button className="button button-dark arcade-hit" onClick={() => hitTarget(cursor)} disabled={won || hits.has(cursor)} data-testid="button-game-hit">{won ? 'All done' : 'Hit selected target'} <Check size={16} /></button></div>{won && <button className="text-link arcade-restart" onClick={reset} data-testid="button-game-restart">Play another round <ArrowRight size={15} /></button>}</section></div>;
}

function PuzzleMiniGame({ onClose }: { onClose: () => void }) {
  const [answer, setAnswer] = useState('');
  const [checked, setChecked] = useState(false);
  const correct = Number(answer) === 12;
  function checkAnswer(event: FormEvent) {
    event.preventDefault();
    if (answer.trim()) setChecked(true);
  }
  return <div className="arcade-overlay"><section className="arcade-dialog puzzle-dialog" role="dialog" aria-modal="true" aria-labelledby="puzzle-title" data-testid="dialog-puzzle-game">
    <div className="arcade-top"><div><span className="eyebrow">OFFLINE PUZZLE</span><h2 id="puzzle-title">A quick number puzzle</h2></div><button className="arcade-close" onClick={onClose} aria-label="Close puzzle" data-testid="button-close-puzzle"><X size={20} /></button></div>
    <p className="arcade-instructions">What is 5 + 7?</p>
    <form className="puzzle-form" onSubmit={checkAnswer}>
      <label htmlFor="puzzle-answer">Your answer</label>
      <input id="puzzle-answer" inputMode="numeric" type="number" value={answer} onChange={event => { setAnswer(event.target.value); setChecked(false); }} data-testid="input-puzzle-answer" />
      <button className="button button-dark" type="submit" disabled={!answer.trim()} data-testid="button-check-puzzle">Check answer</button>
    </form>
    {checked && <p className={`puzzle-result ${correct ? 'puzzle-correct' : 'puzzle-try-again'}`} role="status" data-testid="text-puzzle-result">{correct ? 'That’s right—nice work!' : 'Not quite. Try once more.'}</p>}
  </section></div>;
}

function OfflineGamesPage() {
  const [online, setOnline] = useState(() => typeof navigator === 'undefined' || navigator.onLine);
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, []);
  return <main className="offline-page">
    <header className="offline-page-header"><Link href="/" className="brand-link" data-testid="link-offline-brand"><Brand /></Link><Link href="/" className="offline-back-link" data-testid="link-offline-back">Back to Bloxy <ArrowRight size={15} /></Link></header>
    <div className="offline-page-content">
      <div className="eyebrow">{online ? 'READY FOR A QUICK BREAK' : 'NO CONNECTION NEEDED'}</div>
      <h1>Keep learning,<br /><em>even offline.</em></h1>
      <p className="offline-page-intro">These small activities run in your browser. No account is needed, and game scores stay on this device.</p>
      <p className="offline-page-intro">Load this page online first to save its resources. Offline access depends on your browser keeping that storage. Online lessons and account features need a connection.</p>
      <OfflineGamesMenu />
      <LocalSafetyChecker />
    </div>
  </main>;
}

function OfflineServiceWorker() {
  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    let registration: ServiceWorkerRegistration | undefined;
    const cacheLoadedResources = () => {
      const resources = performance.getEntriesByType('resource')
        .map(entry => entry.name)
        .filter(name => {
          try {
            const url = new URL(name);
            return url.origin === window.location.origin &&
              !url.pathname.startsWith('/api') &&
              !url.pathname.startsWith('/__clerk');
          } catch {
            return false;
          }
        });
      const worker = navigator.serviceWorker.controller ?? registration?.active;
      worker?.postMessage({
        type: 'CACHE_APP_RESOURCES',
        urls: [...new Set([`${window.location.origin}${basePath}/`, `${window.location.origin}${basePath}/index.html`, ...resources])],
      });
    };
    const onControllerChange = () => cacheLoadedResources();
    navigator.serviceWorker.addEventListener('controllerchange', onControllerChange);
    void navigator.serviceWorker.register(`${basePath}/service-worker.js`, { scope: `${basePath}/` })
      .then(value => {
        registration = value;
        return navigator.serviceWorker.ready;
      })
      .then(cacheLoadedResources)
      .catch(error => console.warn('Bloxy offline cache could not be prepared.', error));
    return () => navigator.serviceWorker.removeEventListener('controllerchange', onControllerChange);
  }, []);
  return null;
}

function OfflineRescue() {
  const [offline, setOffline] = useState(() => typeof navigator !== 'undefined' && !navigator.onLine);
  const [location, setLocation] = useLocation();
  useEffect(() => {
    const onOnline = () => setOffline(false);
    const onOffline = () => { setOffline(true); setLocation('/offline'); };
    if (!navigator.onLine) setLocation('/offline');
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, [setLocation]);
  return offline ? <div className="offline-rescue" role="status" data-testid="status-offline"><span><WifiOff size={15} /> You’re offline. Saved games are still available.</span>{location !== '/offline' && <Link href="/offline" data-testid="link-open-offline-games">Open offline games <ArrowRight size={14} /></Link>}</div> : null;
}

function AuthPage({ kind }: { kind: 'sign-in' | 'sign-up' }) {
  return <div className="auth-page"><div className="auth-backdrop"><span className="auth-orbit one" /><span className="auth-orbit two" /><div className="auth-message"><Link href="/" className="brand-link" data-testid="link-auth-brand"><Brand /></Link><span className="eyebrow">YOUR NEXT LITTLE WIN</span><h1>Curiosity<br />looks good<br /><em>on you.</em></h1><p>A bright little space for skills, progress, and trying again.</p></div><div className="auth-footer-note">LEARN AT YOUR OWN PACE <Sparkles size={16} /></div></div><div className="auth-form-side"><Link href="/" className="auth-back" data-testid="link-auth-back">← Back to Bloxy</Link><div className="auth-form-wrap">{kind === 'sign-in' ? <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /> : <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} forceRedirectUrl={`${basePath}/user-portal`} />}</div></div></div>;
}

function ClerkCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) client.clear();
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Routes() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={HomeRedirect} />
    <Route path="/sign-in/*?" component={() => <AuthPage kind="sign-in" />} />
    <Route path="/sign-up/*?" component={() => <AuthPage kind="sign-up" />} />
    <Route path="/user-portal" component={() => <Protected allowIncompleteProfile><DashboardPage /></Protected>} />
    <Route path="/safety-report" component={() => <Protected><AppShell><SafetyReportPage /></AppShell></Protected>} />
    <Route path="/owner" component={() => <OwnerPage />} />
    <Route path="/learn" component={() => <Protected><LessonsPage /></Protected>} />
    <Route path="/learn/:lessonId" component={({ params }) => <Protected><LessonPage params={params} /></Protected>} />
    <Route path="/games" component={() => <Protected><AppShell><GamesPage /></AppShell></Protected>} />
    <Route path="/games/:gameId" component={({ params }) => <Protected><AppShell><MiniGamePage params={params} /></AppShell></Protected>} />
    <Route path="/shop" component={() => <Protected><AppShell><ShopPage /></AppShell></Protected>} />
    <Route path="/challenges" component={() => <Protected><ChallengesPage /></Protected>} />
    <Route path="/leaderboard" component={() => <Protected><LeaderboardPage /></Protected>} />
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}

function ClerkApp() {
  const [location, setLocation] = useLocation();
  if (location === '/offline') return <OfflineGamesPage />;
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={appearance}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    localization={{
      signIn: { start: { title: 'Welcome back', subtitle: 'Your next little win is waiting.' } },
      signUp: { start: { title: 'Make a learner profile', subtitle: 'Choose how you’d like to show up in Bloxy.' } },
    }}
    routerPush={to => setLocation(stripBase(to))}
    routerReplace={to => setLocation(stripBase(to), { replace: true })}
  >
    <ClerkCacheInvalidator />
    <Routes />
  </ClerkProvider>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={basePath}><OfflineServiceWorker /><OfflineRescue /><ClerkApp /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;