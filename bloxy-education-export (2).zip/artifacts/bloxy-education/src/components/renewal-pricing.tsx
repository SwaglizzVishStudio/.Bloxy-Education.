import { getRenewalPrice, RENEWAL_EVENTS } from '@/lib/renewal-pricing';

export function RenewalPricing({ mazeEligible }: { mazeEligible?: boolean }) {
  const currentPrice = getRenewalPrice(new Date(), mazeEligible ?? false);
  return <section className="renewal-pricing surface" aria-labelledby="renewal-pricing-title" data-testid="panel-renewal-pricing">
    <div className="eyebrow">2027–2028 PROMOTIONS</div>
    <h2 id="renewal-pricing-title">Renewal pricing</h2>
    <p>Standard renewal: <strong>₹1,000</strong>. Saturdays, Sundays, or eligible maze players: <strong>₹800</strong>. Listed festival dates: <strong>₹500</strong>.</p>
    <p>Festival pricing takes priority. Discounts do not stack. Dates use India time (IST).</p>
    <p className="renewal-current-preview" data-testid="text-renewal-current-preview">Current price preview: <strong>₹{currentPrice}</strong>{mazeEligible !== undefined && <span> · {mazeEligible ? 'Maze Escape eligibility verified' : 'Complete Maze Escape to qualify for the maze discount'}</span>}</p>
    <div className="renewal-event-list">{RENEWAL_EVENTS.map(event => <div className="renewal-event" key={event.date} data-testid={`renewal-event-${event.date}`}>
      <span><strong>{event.name}</strong><time dateTime={event.date}>{new Intl.DateTimeFormat('en-IN', { dateStyle: 'long', timeZone: 'UTC' }).format(new Date(`${event.date}T00:00:00Z`))}</time></span>
      <strong>₹{getRenewalPrice(event.date, false)}</strong>
    </div>)}</div>
    <p className="renewal-preview-note">Pricing preview only—renewal payments are not active. Maze eligibility on learner pages is based on a server-verified Maze Escape completion. These are Bloxy’s selected promotional dates.</p>
  </section>;
}