import { useState } from 'react';
import { useClerk } from '@clerk/react';
import { Check, Copy } from 'lucide-react';

export function AccountIdCard() {
  const { user } = useClerk();
  const accountId = user?.id;
  const [copyMessage, setCopyMessage] = useState('');

  if (!accountId) return null;

  async function copyAccountId() {
    const currentAccountId = accountId;
    if (!currentAccountId) return;
    try {
      await navigator.clipboard.writeText(currentAccountId);
      setCopyMessage('Copied. Share this ID only to set up your owner access.');
    } catch {
      setCopyMessage('Copy was blocked. Select the ID above and copy it manually.');
    }
  }

  return (
    <section className="account-id-card" aria-label="Your private account ID">
      <div className="account-id-copy">
        <div className="account-id-heading">
          <span className="eyebrow">PRIVATE ACCOUNT ID</span>
          <p>Only your signed-in account can see this. Your email is not shown.</p>
        </div>
        <code data-testid="text-own-account-id">{accountId}</code>
      </div>
      <div className="account-id-action">
        <button type="button" className="button button-quiet account-id-button" onClick={copyAccountId} data-testid="button-copy-account-id">
          {copyMessage.startsWith('Copied') ? <Check size={15} /> : <Copy size={15} />}
          {copyMessage.startsWith('Copied') ? 'Copied' : 'Copy ID'}
        </button>
        {copyMessage && <span role="status" className="account-id-status">{copyMessage}</span>}
      </div>
    </section>
  );
}
