import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";

export const OWNER_ACTOR_ID = "owner-passphrase";

const COOKIE_NAME = "bloxy_owner_session";
const COOKIE_PATH = "/api/owner";
const SESSION_DURATION_MS = 60 * 60 * 1000;
const MIN_SECRET_BYTES = 32;

type OwnerSessionPayload = {
  scope: "bloxy-owner";
  issuedAt: number;
  expiresAt: number;
};

function sessionKey(): string | null {
  const passphrase = process.env.BLOXY_OWNER_ADMIN_PASSPHRASE;
  if (!passphrase || Buffer.byteLength(passphrase, "utf8") < MIN_SECRET_BYTES) {
    return null;
  }
  const configuredSigningSecret = process.env.SESSION_SECRET;
  const signingSecret =
    configuredSigningSecret &&
    Buffer.byteLength(configuredSigningSecret, "utf8") >= MIN_SECRET_BYTES
      ? configuredSigningSecret
      : passphrase;
  return createHmac("sha256", signingSecret)
    .update("bloxy-owner-session\0", "utf8")
    .update(passphrase, "utf8")
    .digest("hex");
}

export function isOwnerPassphraseConfigured(): boolean {
  const passphrase = process.env.BLOXY_OWNER_ADMIN_PASSPHRASE;
  return Boolean(
    passphrase &&
      Buffer.byteLength(passphrase, "utf8") >= MIN_SECRET_BYTES &&
      sessionKey(),
  );
}

export function matchesOwnerPassphrase(candidate: string): boolean {
  const configured = process.env.BLOXY_OWNER_ADMIN_PASSPHRASE;
  if (!configured || !isOwnerPassphraseConfigured()) return false;

  const candidateDigest = createHash("sha256").update(candidate, "utf8").digest();
  const configuredDigest = createHash("sha256")
    .update(configured, "utf8")
    .digest();
  return timingSafeEqual(candidateDigest, configuredDigest);
}

function sign(payload: string, key: string): string {
  return createHmac("sha256", key).update(payload).digest("base64url");
}

function cookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict" as const,
    path: COOKIE_PATH,
  };
}

export function setOwnerSessionCookie(res: Response): boolean {
  const key = sessionKey();
  if (!key) return false;

  const issuedAt = Date.now();
  const payload: OwnerSessionPayload = {
    scope: "bloxy-owner",
    issuedAt,
    expiresAt: issuedAt + SESSION_DURATION_MS,
  };
  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString(
    "base64url",
  );
  const token = `${encodedPayload}.${sign(encodedPayload, key)}`;
  res.cookie(COOKIE_NAME, token, {
    ...cookieOptions(),
    maxAge: SESSION_DURATION_MS,
  });
  return true;
}

export function clearOwnerSessionCookie(res: Response): void {
  res.clearCookie(COOKIE_NAME, cookieOptions());
}

function ownerSessionToken(req: Request): string | null {
  const header = req.headers.cookie;
  if (!header) return null;

  for (const part of header.split(";")) {
    const separator = part.indexOf("=");
    if (separator < 0) continue;
    if (part.slice(0, separator).trim() === COOKIE_NAME) {
      return part.slice(separator + 1).trim() || null;
    }
  }
  return null;
}

export function getOwnerSessionActor(
  req: Request,
  now = Date.now(),
): string | null {
  const key = sessionKey();
  const token = ownerSessionToken(req);
  if (!key || !token) return null;

  const [encodedPayload, suppliedSignature, extra] = token.split(".");
  if (!encodedPayload || !suppliedSignature || extra !== undefined) return null;

  const expectedSignature = sign(encodedPayload, key);
  const expectedBytes = Buffer.from(expectedSignature, "utf8");
  const suppliedBytes = Buffer.from(suppliedSignature, "utf8");
  if (
    expectedBytes.length !== suppliedBytes.length ||
    !timingSafeEqual(expectedBytes, suppliedBytes)
  ) {
    return null;
  }

  try {
    const payload = JSON.parse(
      Buffer.from(encodedPayload, "base64url").toString("utf8"),
    ) as Partial<OwnerSessionPayload>;
    if (
      payload.scope !== "bloxy-owner" ||
      !Number.isSafeInteger(payload.issuedAt) ||
      !Number.isSafeInteger(payload.expiresAt) ||
      payload.issuedAt! > now + 60_000 ||
      payload.expiresAt! <= now ||
      payload.expiresAt! - payload.issuedAt! > SESSION_DURATION_MS
    ) {
      return null;
    }
    return OWNER_ACTOR_ID;
  } catch {
    return null;
  }
}
