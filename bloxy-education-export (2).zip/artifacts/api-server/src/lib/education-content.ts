export type AgeGroup = "kids" | "teens" | "adults";
export type LearningHub = "cooking" | "coding" | "studies";

export type LessonQuestionContent = {
  id: string;
  prompt: string;
  options: string[];
};

export type LessonContent = {
  id: string;
  title: string;
  description: string;
  hub: LearningHub;
  ageGroup: AgeGroup | null;
  skillLevel: string | null;
  subject: string | null;
  durationMinutes: number;
  materials: string[];
  steps: string[];
  questions: LessonQuestionContent[];
  correctAnswers: number[];
};

export const lessons: LessonContent[] = [
  {
    id: "kids-chocolate-milkshake",
    title: "Chocolate Milkshake",
    description: "Make a cool, creamy snack with a grown-up helping nearby.",
    hub: "cooking",
    ageGroup: "kids",
    skillLevel: null,
    subject: null,
    durationMinutes: 10,
    materials: ["1 cup milk", "1 small banana", "1 teaspoon cocoa powder"],
    steps: [
      "Wash your hands and ask a grown-up to help.",
      "Ask the grown-up to peel and slice the banana.",
      "With grown-up help, blend the banana, milk, and cocoa until smooth.",
      "Ask the grown-up to pour the drink, then enjoy it together.",
    ],
    questions: [
      {
        id: "q1",
        prompt: "Who should operate the blender?",
        options: ["A pet", "A grown-up helping you", "Nobody"],
      },
      {
        id: "q2",
        prompt: "What should you do before preparing food?",
        options: ["Wash your hands", "Touch your shoes", "Skip cleaning"],
      },
      {
        id: "q3",
        prompt: "What makes this snack creamy?",
        options: ["Only ice", "Paper and water", "Milk and banana"],
      },
    ],
    correctAnswers: [1, 0, 2],
  },
  {
    id: "teens-pizza-wrap",
    title: "Easy Pizza Wrap",
    description: "Build a no-cook pizza wrap with a few simple ingredients.",
    hub: "cooking",
    ageGroup: "teens",
    skillLevel: null,
    subject: null,
    durationMinutes: 10,
    materials: [
      "1 tortilla",
      "2 tablespoons tomato sauce",
      "A small handful of grated cheese",
      "Chopped vegetables of your choice",
    ],
    steps: [
      "Wash your hands and set out clean utensils.",
      "Spread tomato sauce on the tortilla with the back of a spoon.",
      "Add grated cheese and chopped vegetables.",
      "Fold the wrap and enjoy it cold, or ask an adult before using a hot appliance.",
    ],
    questions: [
      {
        id: "q1",
        prompt: "What is a safe way to spread the sauce?",
        options: ["Use a clean spoon", "Use your hands after gardening", "Use a sharp knife"],
      },
      {
        id: "q2",
        prompt: "What should you do before using a hot appliance?",
        options: ["Leave it unattended", "Ask an adult if you need help", "Touch the hot surface"],
      },
      {
        id: "q3",
        prompt: "Which ingredient gives the wrap its pizza flavor?",
        options: ["Paper", "Dish soap", "Tomato sauce"],
      },
    ],
    correctAnswers: [0, 1, 2],
  },
  {
    id: "adults-healthy-salad",
    title: "Healthy Salad Bowl",
    description: "Put together a colorful salad with greens, vegetables, and chickpeas.",
    hub: "cooking",
    ageGroup: "adults",
    skillLevel: null,
    subject: null,
    durationMinutes: 12,
    materials: [
      "2 cups mixed greens",
      "1 cup cooked chickpeas",
      "1 cucumber",
      "A handful of cherry tomatoes",
      "Your favorite dressing",
    ],
    steps: [
      "Rinse the greens and vegetables under clean running water.",
      "Add greens and rinsed chickpeas to a clean bowl.",
      "Add the chopped cucumber and tomatoes.",
      "Top with dressing and check labels for allergens that affect you.",
    ],
    questions: [
      {
        id: "q1",
        prompt: "Why rinse fresh produce before eating it?",
        options: ["To make it grow", "To change its color", "To remove dirt and debris"],
      },
      {
        id: "q2",
        prompt: "What should you check if you have a food allergy?",
        options: ["Ingredient labels", "The bowl color", "The day of the week"],
      },
      {
        id: "q3",
        prompt: "What do chickpeas add to the bowl?",
        options: ["Plant-based protein", "A cooking tool", "A paper wrapper"],
      },
    ],
    correctAnswers: [2, 1, 0],
  },
  {
    id: "coding-hello-world",
    title: "Print Hello World",
    description: "Take a first step into coding by giving a computer a clear instruction.",
    hub: "coding",
    ageGroup: null,
    skillLevel: "Beginner",
    subject: null,
    durationMinutes: 8,
    materials: ["A text editor or a sheet of paper"],
    steps: [
      "Write the instruction print(\"Hello, world!\").",
      "Read it from left to right and check the quotation marks.",
      "Run it in a beginner coding editor, or explain what it should display.",
    ],
    questions: [
      {
        id: "q1",
        prompt: "What does a print instruction usually do?",
        options: ["Deletes the keyboard", "Shows text as output", "Makes a computer sleep"],
      },
      {
        id: "q2",
        prompt: "What belongs around the words Hello, world! in this example?",
        options: ["A pair of shoes", "A food label", "Quotation marks"],
      },
      {
        id: "q3",
        prompt: "What is a good first output to try?",
        options: ["Hello, world!", "A blank page forever", "A broken screen"],
      },
    ],
    correctAnswers: [1, 2, 0],
  },
  {
    id: "coding-calculator",
    title: "Build a Calculator",
    description: "Plan a small calculator that adds two numbers and handles division safely.",
    hub: "coding",
    ageGroup: null,
    skillLevel: "Intermediate",
    subject: null,
    durationMinutes: 15,
    materials: ["A text editor or a sheet of paper"],
    steps: [
      "Create two number inputs named first and second.",
      "Add their values and display the result.",
      "Add a division option and check that the second number is not zero first.",
    ],
    questions: [
      {
        id: "q1",
        prompt: "What is 8 + 5?",
        options: ["85", "3", "13"],
      },
      {
        id: "q2",
        prompt: "What should a calculator check before dividing by a number?",
        options: ["That the divisor is not zero", "That the screen is blue", "That both numbers are words"],
      },
      {
        id: "q3",
        prompt: "What should a calculator show after adding two inputs?",
        options: ["A random color", "The sum", "The keyboard layout"],
      },
    ],
    correctAnswers: [2, 0, 1],
  },
  {
    id: "coding-mini-game",
    title: "Create a Mini Game",
    description: "Sketch a small game loop with a player, a target, and a score.",
    hub: "coding",
    ageGroup: null,
    skillLevel: "Advanced",
    subject: null,
    durationMinutes: 20,
    materials: ["A text editor or a sheet of paper"],
    steps: [
      "Choose a player action and one friendly target.",
      "Repeat the game update while the player is still playing.",
      "Add one point when the player reaches the target and show the score.",
    ],
    questions: [
      {
        id: "q1",
        prompt:
          "A player moves from x = 0 to x = 12 in one update while a thin target is at x = 5–6. What prevents the collision from being missed?",
        options: [
          "Check the path between the old and new positions",
          "Check only when the player stops moving",
          "Increase the target's animation speed",
        ],
      },
      {
        id: "q2",
        prompt:
          "At 60 frames per second, a player overlapping a target for one second earns 60 points. What is the best fix?",
        options: [
          "Register one hit, then allow another only after the player separates",
          "Clamp the score back to one every render",
          "Slow the whole game while the player overlaps",
        ],
      },
      {
        id: "q3",
        prompt:
          "Which update strategy keeps game physics consistent when rendering speed changes?",
        options: [
          "Add movement once per rendered frame",
          "Skip updates whenever a frame takes longer",
          "Use a fixed update step with an elapsed-time accumulator",
        ],
      },
    ],
    correctAnswers: [0, 0, 2],
  },
  {
    id: "studies-math",
    title: "Solve 2x + 5 = 15",
    description: "Practice undoing operations to find the value of x.",
    hub: "studies",
    ageGroup: null,
    skillLevel: null,
    subject: "Math",
    durationMinutes: 8,
    materials: ["Paper and pencil"],
    steps: [
      "Subtract 5 from both sides: 2x = 10.",
      "Divide both sides by 2.",
      "Check the answer by substituting it into the original equation.",
    ],
    questions: [
      {
        id: "q1",
        prompt: "After subtracting 5 from both sides, what remains?",
        options: ["2x = 20", "2x = 10", "x = 15"],
      },
      {
        id: "q2",
        prompt: "What is x?",
        options: ["5", "10", "20"],
      },
      {
        id: "q3",
        prompt: "Which check is correct?",
        options: ["2 × 10 + 5 = 15", "5 + 15 = 2", "2 × 5 + 5 = 15"],
      },
    ],
    correctAnswers: [1, 0, 2],
  },
  {
    id: "studies-english",
    title: "Find a Synonym for Happy",
    description: "Build vocabulary by finding words with a similar meaning.",
    hub: "studies",
    ageGroup: null,
    skillLevel: null,
    subject: "English",
    durationMinutes: 7,
    materials: ["A notebook or a sheet of paper"],
    steps: [
      "Read the word happy and think about its meaning.",
      "Choose a word that means something similar.",
      "Write a sentence with your chosen synonym.",
    ],
    questions: [
      {
        id: "q1",
        prompt: "Which word is a synonym for happy?",
        options: ["Joyful", "Tired", "Tiny"],
      },
      {
        id: "q2",
        prompt: "What does a synonym have?",
        options: ["A completely opposite meaning", "No meaning", "A similar meaning"],
      },
      {
        id: "q3",
        prompt: "Which word is closest to cheerful?",
        options: ["Glad", "Angry", "Sleepy"],
      },
    ],
    correctAnswers: [0, 2, 0],
  },
  {
    id: "studies-science",
    title: "Meet the Red Planet",
    description: "Explore a few facts about Mars and our solar system.",
    hub: "studies",
    ageGroup: null,
    skillLevel: null,
    subject: "Science",
    durationMinutes: 7,
    materials: ["A notebook or a sheet of paper"],
    steps: [
      "Find Mars on a simple diagram of the solar system.",
      "Notice its reddish appearance and rocky surface.",
      "Share one fact you learned with a study partner.",
    ],
    questions: [
      {
        id: "q1",
        prompt: "Which planet is known as the Red Planet?",
        options: ["Neptune", "Earth", "Mars"],
      },
      {
        id: "q2",
        prompt: "Where is Mars?",
        options: ["In our solar system", "Inside the Moon", "Under the ocean"],
      },
      {
        id: "q3",
        prompt: "What kind of planet is Mars?",
        options: ["A rocky planet", "A star", "A type of cloud"],
      },
    ],
    correctAnswers: [2, 1, 0],
  },
];

export function getLesson(lessonId: string): LessonContent | undefined {
  return lessons.find((lesson) => lesson.id === lessonId);
}

export function toPublicLesson(lesson: LessonContent) {
  const {
    correctAnswers: _correctAnswers,
    ...publicLesson
  } = lesson;
  return publicLesson;
}