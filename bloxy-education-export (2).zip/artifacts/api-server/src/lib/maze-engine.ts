export type MazeMove = "up" | "down" | "left" | "right";

export const MAZE_WIDTH = 15;
export const MAZE_HEIGHT = 15;
export const MAZE_START = { x: 1, y: 1 };
export const MAZE_EXIT = {
  x: MAZE_WIDTH - 2,
  y: MAZE_HEIGHT - 2,
};

const moveOffsets: Record<MazeMove, { x: number; y: number }> = {
  up: { x: 0, y: -1 },
  down: { x: 0, y: 1 },
  left: { x: -1, y: 0 },
  right: { x: 1, y: 0 },
};

function createRandom(seed: number) {
  let state = seed >>> 0;
  return () => {
    state += 0x6d2b79f5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4_294_967_296;
  };
}

export function generateMaze(seed: number) {
  const cells = Array.from({ length: MAZE_HEIGHT }, () =>
    Array.from({ length: MAZE_WIDTH }, () => "#"),
  );
  const random = createRandom(seed);
  const stack = [MAZE_START];
  cells[MAZE_START.y][MAZE_START.x] = ".";

  while (stack.length > 0) {
    const current = stack[stack.length - 1];
    const directions = [
      { x: 0, y: -2 },
      { x: 2, y: 0 },
      { x: 0, y: 2 },
      { x: -2, y: 0 },
    ];
    for (let index = directions.length - 1; index > 0; index -= 1) {
      const swapIndex = Math.floor(random() * (index + 1));
      [directions[index], directions[swapIndex]] = [
        directions[swapIndex],
        directions[index],
      ];
    }

    const next = directions.find(({ x, y }) => {
      const nextX = current.x + x;
      const nextY = current.y + y;
      return (
        nextX > 0 &&
        nextX < MAZE_WIDTH - 1 &&
        nextY > 0 &&
        nextY < MAZE_HEIGHT - 1 &&
        cells[nextY][nextX] === "#"
      );
    });

    if (!next) {
      stack.pop();
      continue;
    }

    cells[current.y + next.y / 2][current.x + next.x / 2] = ".";
    const destination = { x: current.x + next.x, y: current.y + next.y };
    cells[destination.y][destination.x] = ".";
    stack.push(destination);
  }

  return cells.map((row) => row.join(""));
}

export function validateMazeRoute(seed: number, moves: MazeMove[]) {
  if (moves.length === 0 || moves.length > 512) return false;
  const grid = generateMaze(seed);
  let x = MAZE_START.x;
  let y = MAZE_START.y;

  for (let index = 0; index < moves.length; index += 1) {
    const offset = moveOffsets[moves[index]];
    if (!offset) return false;
    x += offset.x;
    y += offset.y;

    if (
      y < 0 ||
      y >= MAZE_HEIGHT ||
      x < 0 ||
      x >= MAZE_WIDTH ||
      grid[y][x] !== "."
    ) {
      return false;
    }
    if (x === MAZE_EXIT.x && y === MAZE_EXIT.y) {
      return index === moves.length - 1;
    }
  }

  return false;
}
