export const activityGrades = [
  "Dirty Bronze",
  "Steel",
  "Silver",
  "Gold",
  "Emerald",
  "Red Gold",
  "Diamond",
  "Bedrock",
] as const;

export type ActivityGrade = (typeof activityGrades)[number];
export type ActivityProgressionEvent = "started" | "continued" | "reset";

const resetAfterMs = 2 * 24 * 60 * 60 * 1000;

type ActivityProgressionState = {
  streakDays: number;
  activityRank: number;
  activityLastPlayedAt: Date | null;
  lastRewardDate: string | null;
};

type ActivityProgressionResult = {
  streakDays: number;
  activityRank: number;
  event: ActivityProgressionEvent;
};

export function activityGradeForStreak(streakDays: number): ActivityGrade {
  const gradeIndex = Math.min(
    Math.floor(Math.max(0, streakDays) / 5),
    activityGrades.length - 1,
  );
  return activityGrades[gradeIndex]!;
}

export function applyDailyActivityProgression(
  state: ActivityProgressionState,
  now = new Date(),
): ActivityProgressionResult {
  const lastPlayedAt =
    state.activityLastPlayedAt ??
    (state.lastRewardDate
      ? new Date(`${state.lastRewardDate}T12:00:00.000Z`)
      : null);

  if (!lastPlayedAt || !Number.isFinite(lastPlayedAt.getTime())) {
    return {
      streakDays: 0,
      activityRank: state.activityRank,
      event: "started",
    };
  }

  if (now.getTime() - lastPlayedAt.getTime() >= resetAfterMs) {
    return {
      streakDays: 0,
      activityRank: 55,
      event: "reset",
    };
  }

  return {
    streakDays: state.streakDays + 1,
    activityRank: Math.max(1, state.activityRank - 10),
    event: "continued",
  };
}
