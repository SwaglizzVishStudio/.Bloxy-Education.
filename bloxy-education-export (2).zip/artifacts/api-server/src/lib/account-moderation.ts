import { clerkClient } from "@clerk/express";
import { and, desc, eq, isNull } from "drizzle-orm";
import {
  db,
  moderationBansTable,
  moderationEventsTable,
} from "@workspace/db";

export async function isAccountRestricted(userId: string): Promise<boolean> {
  const [ban] = await db
    .select({ userId: moderationBansTable.userId })
    .from(moderationBansTable)
    .where(eq(moderationBansTable.userId, userId))
    .limit(1);
  if (ban) return true;

  const [pendingEvent] = await db
    .select({ id: moderationEventsTable.id })
    .from(moderationEventsTable)
    .where(
      and(
        eq(moderationEventsTable.userId, userId),
        isNull(moderationEventsTable.completedAt),
      ),
    )
    .limit(1);
  return Boolean(pendingEvent);
}

export async function getPendingModerationEvent(
  userId: string,
): Promise<typeof moderationEventsTable.$inferSelect | null> {
  const [event] = await db
    .select()
    .from(moderationEventsTable)
    .where(
      and(
        eq(moderationEventsTable.userId, userId),
        isNull(moderationEventsTable.completedAt),
      ),
    )
    .orderBy(desc(moderationEventsTable.createdAt))
    .limit(1);
  return event ?? null;
}

async function revokeAllActiveSessions(userId: string): Promise<void> {
  if (!process.env.CLERK_SECRET_KEY) {
    throw new Error("Clerk server credentials are not configured");
  }
  const sessions = await clerkClient.sessions.getSessionList({
    userId,
    status: "active",
    limit: 100,
  });
  await Promise.all(
    sessions.data.map((session) =>
      clerkClient.sessions.revokeSession(session.id),
    ),
  );
}

export async function revokeLearnerSessions(userId: string): Promise<void> {
  await revokeAllActiveSessions(userId);
}

export async function finishModerationEvent(
  eventId: string,
  userId: string,
) {
  const [event] = await db
    .select()
    .from(moderationEventsTable)
    .where(
      and(
        eq(moderationEventsTable.id, eventId),
        eq(moderationEventsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!event) return null;
  if (event.completedAt) return event;

  if (!process.env.CLERK_SECRET_KEY) {
    throw new Error("Clerk server credentials are not configured");
  }
  if (event.action === "ban") {
    await clerkClient.users.banUser(userId);
  }
  await revokeAllActiveSessions(userId);

  const [completedEvent] = await db
    .update(moderationEventsTable)
    .set({ completedAt: new Date() })
    .where(
      and(
        eq(moderationEventsTable.id, eventId),
        isNull(moderationEventsTable.completedAt),
      ),
    )
    .returning();
  return completedEvent ?? event;
}
