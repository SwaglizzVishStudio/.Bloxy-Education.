import { randomInt } from "node:crypto";
import { eq } from "drizzle-orm";
import { db, learnersTable } from "@workspace/db";

export async function ensureLearner(userId: string) {
  const [existing] = await db
    .select()
    .from(learnersTable)
    .where(eq(learnersTable.id, userId))
    .limit(1);
  if (existing) return existing;

  await db
    .insert(learnersTable)
    .values({
      id: userId,
      displayName: `Learner ${randomInt(1000, 10_000)}`,
    })
    .onConflictDoNothing();

  const [learner] = await db
    .select()
    .from(learnersTable)
    .where(eq(learnersTable.id, userId))
    .limit(1);
  if (!learner) throw new Error("Could not initialize learner profile");
  return learner;
}
