import { getAuth } from "@clerk/express";
import { and, asc, count, eq, gt, ne } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  CompleteModerationEventParams,
  CompleteModerationEventResponse,
  CreateSafetyReportBody,
  CreateSafetyReportResponse,
  GetModerationAccessResponse,
  ListReportTargetsResponse,
  UpdateModerationPreferencesBody,
  UpdateModerationPreferencesResponse,
} from "@workspace/api-zod";
import {
  db,
  learnersTable,
  moderationBansTable,
  moderationEventsTable,
  safetyPreferencesTable,
  safetyReportsTable,
} from "@workspace/db";
import {
  finishModerationEvent,
  getPendingModerationEvent,
  isAccountRestricted,
} from "../lib/account-moderation";
import { ensureLearner } from "../lib/learner";

const router: IRouter = Router();
const reportsPerHourLimit = 5;
const moderationEventLifetimeMs = 15_000;

function requireAuth(req: Request, res: Response): string | null {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return userId;
}

async function requireAvailableAccount(
  req: Request,
  res: Response,
): Promise<string | null> {
  const userId = requireAuth(req, res);
  if (!userId) return null;
  if (await isAccountRestricted(userId)) {
    res.status(403).json({
      error: "This Bloxy account is currently restricted.",
      code: "ACCOUNT_RESTRICTED",
    });
    return null;
  }
  return userId;
}

router.get("/moderation/access", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  await ensureLearner(userId);

  let event = await getPendingModerationEvent(userId);
  if (event && event.expiresAt.getTime() <= Date.now()) {
    await finishModerationEvent(event.id, userId);
    event = null;
  }

  const [ban] = await db
    .select({ userId: moderationBansTable.userId })
    .from(moderationBansTable)
    .where(eq(moderationBansTable.userId, userId))
    .limit(1);
  const [preference] = await db
    .select({ allowSpookyEffects: safetyPreferencesTable.allowSpookyEffects })
    .from(safetyPreferencesTable)
    .where(eq(safetyPreferencesTable.userId, userId))
    .limit(1);

  res.json(
    GetModerationAccessResponse.parse({
      isOwner: false,
      banned: Boolean(ban),
      allowSpookyEffects: preference?.allowSpookyEffects ?? false,
      pendingEvent: event
        ? {
            id: event.id,
            action: event.action,
            showSpookyEffect:
              event.showSpookyEffect &&
              preference?.allowSpookyEffects === true,
            createdAt: event.createdAt,
          }
        : null,
    }),
  );
});

router.patch("/moderation/preferences", async (req, res): Promise<void> => {
  const userId = await requireAvailableAccount(req, res);
  if (!userId) return;

  const parsed = UpdateModerationPreferencesBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await ensureLearner(userId);
  await db
    .insert(safetyPreferencesTable)
    .values({ userId, allowSpookyEffects: parsed.data.allowSpookyEffects })
    .onConflictDoUpdate({
      target: safetyPreferencesTable.userId,
      set: {
        allowSpookyEffects: parsed.data.allowSpookyEffects,
        updatedAt: new Date(),
      },
    });
  res.json(
    UpdateModerationPreferencesResponse.parse({
      allowSpookyEffects: parsed.data.allowSpookyEffects,
    }),
  );
});

router.get("/moderation/targets", async (req, res): Promise<void> => {
  const userId = await requireAvailableAccount(req, res);
  if (!userId) return;
  await ensureLearner(userId);

  const targets = await db
    .select({ id: learnersTable.id, displayName: learnersTable.displayName })
    .from(learnersTable)
    .where(ne(learnersTable.id, userId))
    .orderBy(asc(learnersTable.displayName));
  res.json(ListReportTargetsResponse.parse(targets));
});

router.post("/moderation/reports", async (req, res): Promise<void> => {
  const userId = await requireAvailableAccount(req, res);
  if (!userId) return;

  const parsed = CreateSafetyReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const details = parsed.data.details.trim();
  if (details.length < 10) {
    res.status(400).json({ error: "Please describe the concern in at least 10 characters." });
    return;
  }
  if (parsed.data.targetUserId === userId) {
    res.status(400).json({ error: "You cannot report your own account." });
    return;
  }

  const [target] = await db
    .select({ id: learnersTable.id })
    .from(learnersTable)
    .where(eq(learnersTable.id, parsed.data.targetUserId))
    .limit(1);
  if (!target) {
    res.status(404).json({ error: "Registered learner was not found." });
    return;
  }

  const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const [recentReports] = await db
    .select({ value: count() })
    .from(safetyReportsTable)
    .where(
      and(
        eq(safetyReportsTable.reporterUserId, userId),
        gt(safetyReportsTable.createdAt, hourAgo),
      ),
    );
  if (Number(recentReports?.value ?? 0) >= reportsPerHourLimit) {
    res.status(429).json({ error: "You have reached the report limit for this hour." });
    return;
  }

  const id = randomUUID();
  const [report] = await db
    .insert(safetyReportsTable)
    .values({
      id,
      reporterUserId: userId,
      targetUserId: target.id,
      reason: parsed.data.reason,
      details,
      evidence: parsed.data.evidence?.trim() || null,
    })
    .returning();

  res.status(201).json(
    CreateSafetyReportResponse.parse({
      id: report.id,
      status: report.status,
      createdAt: report.createdAt,
    }),
  );
});

router.post(
  "/moderation/events/:eventId/complete",
  async (req, res): Promise<void> => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const params = CompleteModerationEventParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }

    const event = await getPendingModerationEvent(userId);
    if (!event || event.id !== params.data.eventId) {
      res.status(404).json({ error: "Pending moderation event was not found." });
      return;
    }
    await finishModerationEvent(event.id, userId);

    const [ban] = await db
      .select({ userId: moderationBansTable.userId })
      .from(moderationBansTable)
      .where(eq(moderationBansTable.userId, userId))
      .limit(1);
    res.json(
      CompleteModerationEventResponse.parse({
        completed: true,
        banned: Boolean(ban),
      }),
    );
  },
);

export default router;
