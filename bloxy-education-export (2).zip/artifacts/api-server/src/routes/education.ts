import { getAuth } from "@clerk/express";
import { and, asc, count, desc, eq, gt, sql } from "drizzle-orm";
import { randomInt, randomUUID } from "node:crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  ClaimDailyRewardResponse,
  CheckLessonAnswerBody,
  CheckLessonAnswerParams,
  CheckLessonAnswerResponse,
  CompleteMazeBody,
  CompleteMazeResponse,
  ExtendPremiumResponse,
  GetDashboardResponse,
  GetLeaderboardResponse,
  GetShopResponse,
  ListLessonsQueryParams,
  ListLessonsResponse,
  SubmitLessonAttemptBody,
  SubmitLessonAttemptParams,
  SubmitLessonAttemptResponse,
  StartMazeResponse,
  PurchaseShopItemBody,
  PurchaseShopItemResponse,
  UnlockChallengeBody,
  UnlockChallengeResponse,
  UpdateProfileBody,
  UpdateProfileResponse,
} from "@workspace/api-zod";
import {
  challengeUnlocksTable,
  dailyRewardsTable,
  db,
  learnersTable,
  lessonCompletionsTable,
  mazeRunsTable,
  shopInventoryTable,
  shopPurchasesTable,
} from "@workspace/db";
import {
  getLesson,
  lessons,
  toPublicLesson,
  type AgeGroup,
} from "../lib/education-content";
import {
  activityGradeForStreak,
  applyDailyActivityProgression,
} from "../lib/activity-progression";
import {
  generateMaze,
  MAZE_EXIT,
  MAZE_HEIGHT,
  MAZE_START,
  MAZE_WIDTH,
  validateMazeRoute,
} from "../lib/maze-engine";
import { isAccountRestricted } from "../lib/account-moderation";
import { ensureLearner } from "../lib/learner";

const router: IRouter = Router();
const dayInMs = 24 * 60 * 60 * 1000;
const mazeRewardCoins = 50;
const shopCatalog = [
  {
    id: "sword",
    name: "Adventure Sword",
    description: "A collectible for your adventure shelf.",
    price: 30,
  },
  {
    id: "shield",
    name: "Trail Shield",
    description: "A sturdy collectible for your growing collection.",
    price: 25,
  },
  {
    id: "potion",
    name: "Spark Potion",
    description: "A bright little collectible for your shelf.",
    price: 10,
  },
] as const;

function requireAuth(req: Request, res: Response): string | null {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return userId;
}

function remainingPremiumDays(expiresAt: Date | null, now = new Date()) {
  if (!expiresAt || expiresAt.getTime() <= now.getTime()) return 0;
  return Math.ceil((expiresAt.getTime() - now.getTime()) / dayInMs);
}

async function getProfile(userId: string) {
  const [learner] = await db
    .select()
    .from(learnersTable)
    .where(eq(learnersTable.id, userId))
    .limit(1);
  if (!learner) throw new Error("Learner profile was not found");

  const [completionCount] = await db
    .select({ value: count() })
    .from(lessonCompletionsTable)
    .where(eq(lessonCompletionsTable.userId, userId));

  return {
    displayName: learner.displayName,
    ageGroup: learner.ageGroup as AgeGroup | null,
    coins: learner.coins,
    points: learner.points,
    completedLessons: Number(completionCount?.value ?? 0),
    streakDays: learner.streakDays,
    activityRank: learner.activityRank,
    activityGrade: activityGradeForStreak(learner.streakDays),
    premiumDays: remainingPremiumDays(learner.premiumExpiresAt),
    mazeDiscountEligible: learner.mazeDiscountEligible,
  };
}

function utcDate(now = new Date()) {
  return now.toISOString().slice(0, 10);
}

router.use(async (req, res, next): Promise<void> => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (await isAccountRestricted(userId)) {
    res.status(403).json({
      error: "This Bloxy account is currently restricted.",
      code: "ACCOUNT_RESTRICTED",
    });
    return;
  }
  next();
});

router.get("/dashboard", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  await ensureLearner(userId);
  const today = utcDate();
  const [dailyReward] = await db
    .select()
    .from(dailyRewardsTable)
    .where(
      and(
        eq(dailyRewardsTable.userId, userId),
        eq(dailyRewardsTable.rewardDate, today),
      ),
    )
    .limit(1);

  const completions = await db
    .select()
    .from(lessonCompletionsTable)
    .where(eq(lessonCompletionsTable.userId, userId))
    .orderBy(desc(lessonCompletionsTable.completedAt))
    .limit(5);

  const recentCompletions = completions.flatMap((completion) => {
    const lesson = getLesson(completion.lessonId);
    if (!lesson) return [];
    return [
      {
        lessonId: lesson.id,
        title: lesson.title,
        hub: lesson.hub,
        correctCount: completion.correctCount,
        totalQuestions: completion.totalQuestions,
        pointsEarned: completion.pointsEarned,
        completedAt: completion.completedAt,
      },
    ];
  });

  const unlocked = await db
    .select({ ageGroup: challengeUnlocksTable.ageGroup })
    .from(challengeUnlocksTable)
    .where(eq(challengeUnlocksTable.userId, userId));

  res.json(
    GetDashboardResponse.parse({
      profile: await getProfile(userId),
      claimedDailyReward: Boolean(dailyReward),
      recentCompletions,
      unlockedChallenges: unlocked.map((entry) => entry.ageGroup),
    }),
  );
});

router.patch("/profile", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const displayName = parsed.data.displayName.trim();
  if (
    displayName.length < 2 ||
    displayName.length > 24 ||
    !/^[\p{L}\p{N}][\p{L}\p{N} ._-]*$/u.test(displayName)
  ) {
    res.status(400).json({
      error: "Choose a nickname with 2–24 letters, numbers, spaces, dots, dashes, or underscores.",
    });
    return;
  }

  await ensureLearner(userId);
  await db
    .update(learnersTable)
    .set({
      displayName,
      ageGroup: parsed.data.ageGroup,
      updatedAt: new Date(),
    })
    .where(eq(learnersTable.id, userId));

  res.json(UpdateProfileResponse.parse(await getProfile(userId)));
});

router.get("/lessons", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const query = ListLessonsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const learner = await ensureLearner(userId);
  const visibleLessons = lessons.filter((lesson) => {
    if (query.data.hub && lesson.hub !== query.data.hub) return false;
    if (lesson.ageGroup && learner.ageGroup !== lesson.ageGroup) return false;
    return true;
  });

  res.json(ListLessonsResponse.parse(visibleLessons.map(toPublicLesson)));
});

router.post(
  "/lessons/:lessonId/check-answer",
  async (req, res): Promise<void> => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    const params = CheckLessonAnswerParams.safeParse(req.params);
    const input = CheckLessonAnswerBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!input.success) {
      res.status(400).json({ error: input.error.message });
      return;
    }

    const lesson = getLesson(params.data.lessonId);
    if (!lesson) {
      res.status(404).json({ error: "Lesson not found" });
      return;
    }

    const questionIndex = lesson.questions.findIndex(
      (question) => question.id === input.data.questionId,
    );
    if (questionIndex < 0) {
      res.status(404).json({ error: "Question not found" });
      return;
    }
    if (input.data.answerIndex >= lesson.questions[questionIndex].options.length) {
      res.status(400).json({ error: "Answer option not found" });
      return;
    }

    await ensureLearner(userId);
    res.json(
      CheckLessonAnswerResponse.parse({
        isCorrect:
          lesson.correctAnswers[questionIndex] === input.data.answerIndex,
      }),
    );
  },
);

router.post("/lessons/:lessonId/attempt", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = SubmitLessonAttemptParams.safeParse(req.params);
  const input = SubmitLessonAttemptBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!input.success) {
    res.status(400).json({ error: input.error.message });
    return;
  }

  const lesson = getLesson(params.data.lessonId);
  if (!lesson) {
    res.status(404).json({ error: "Lesson not found" });
    return;
  }
  if (
    input.data.answers.length !== lesson.questions.length ||
    input.data.answers.some(
      (answer, index) =>
        answer < 0 || answer >= lesson.questions[index].options.length,
    )
  ) {
    res.status(400).json({ error: "Please answer every question." });
    return;
  }

  await ensureLearner(userId);
  const correctCount = input.data.answers.reduce(
    (total, answer, index) =>
      total + (answer === lesson.correctAnswers[index] ? 1 : 0),
    0,
  );
  const passed = correctCount >= 2;
  let coinsEarned = 0;
  let pointsEarned = 0;
  let premiumDaysAwarded = 0;

  await db.transaction(async (tx) => {
    const [learner] = await tx
      .select()
      .from(learnersTable)
      .where(eq(learnersTable.id, userId))
      .for("update");
    if (!learner) throw new Error("Learner profile was not found");

    const [priorCompletion] = await tx
      .select()
      .from(lessonCompletionsTable)
      .where(
        and(
          eq(lessonCompletionsTable.userId, userId),
          eq(lessonCompletionsTable.lessonId, lesson.id),
        ),
      )
      .limit(1);

    if (passed && !priorCompletion) {
      const now = new Date();
      coinsEarned = 10;
      pointsEarned = 10;
      await tx.insert(lessonCompletionsTable).values({
        userId,
        lessonId: lesson.id,
        correctCount,
        totalQuestions: lesson.questions.length,
        pointsEarned,
      });
      const [updatedLearner] = await tx
        .update(learnersTable)
        .set({
          coins: learner.coins + coinsEarned,
          points: learner.points + pointsEarned,
          updatedAt: now,
        })
        .where(eq(learnersTable.id, userId))
        .returning();

      const [leader] = await tx
        .select({ id: learnersTable.id })
        .from(learnersTable)
        .where(gt(learnersTable.points, 0))
        .orderBy(desc(learnersTable.points), asc(learnersTable.createdAt))
        .limit(1);
      const wasPremiumActive =
        updatedLearner.premiumExpiresAt !== null &&
        updatedLearner.premiumExpiresAt.getTime() > now.getTime();
      if (leader?.id === userId && !wasPremiumActive) {
        premiumDaysAwarded = 4;
        const expiresAt = new Date(now.getTime() + 4 * dayInMs);
        await tx
          .update(learnersTable)
          .set({ premiumExpiresAt: expiresAt, updatedAt: now })
          .where(eq(learnersTable.id, userId));
      }
      return;
    }

    if (passed && priorCompletion && correctCount > priorCompletion.correctCount) {
      await tx
        .update(lessonCompletionsTable)
        .set({ correctCount })
        .where(
          and(
            eq(lessonCompletionsTable.userId, userId),
            eq(lessonCompletionsTable.lessonId, lesson.id),
          ),
        );
    }
  });

  res.json(
    SubmitLessonAttemptResponse.parse({
      lessonId: lesson.id,
      passed,
      correctCount,
      totalQuestions: lesson.questions.length,
      coinsEarned,
      pointsEarned,
      premiumDaysAwarded,
      profile: await getProfile(userId),
    }),
  );
});

router.post("/daily-reward", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  await ensureLearner(userId);

  const now = new Date();
  const today = utcDate(now);
  let alreadyClaimed = false;
  let coinsAwarded = 0;
  let pointsAwarded = 0;
  let streakEvent: "none" | "started" | "continued" | "reset" = "none";

  await db.transaction(async (tx) => {
    const [learner] = await tx
      .select()
      .from(learnersTable)
      .where(eq(learnersTable.id, userId))
      .for("update");
    if (!learner) throw new Error("Learner profile was not found");

    const [existingReward] = await tx
      .select()
      .from(dailyRewardsTable)
      .where(
        and(
          eq(dailyRewardsTable.userId, userId),
          eq(dailyRewardsTable.rewardDate, today),
        ),
      )
      .limit(1);
    if (existingReward || learner.lastRewardDate === today) {
      alreadyClaimed = true;
      return;
    }

    const premiumActive =
      learner.premiumExpiresAt !== null &&
      learner.premiumExpiresAt.getTime() > now.getTime();
    coinsAwarded = 5 + (premiumActive ? 2 : 0);
    pointsAwarded = 2 + (premiumActive ? 2 : 0);
    const progression = applyDailyActivityProgression(
      {
        streakDays: learner.streakDays,
        activityRank: learner.activityRank,
        activityLastPlayedAt: learner.activityLastPlayedAt,
        lastRewardDate: learner.lastRewardDate,
      },
      now,
    );
    streakEvent = progression.event;

    await tx.insert(dailyRewardsTable).values({
      userId,
      rewardDate: today,
      coinsAwarded,
      pointsAwarded,
    });
    await tx
      .update(learnersTable)
      .set({
        coins: learner.coins + coinsAwarded,
        points: learner.points + pointsAwarded,
        streakDays: progression.streakDays,
        activityRank: progression.activityRank,
        activityLastPlayedAt: now,
        lastRewardDate: today,
        updatedAt: now,
      })
      .where(eq(learnersTable.id, userId));
  });

  res.json(
    ClaimDailyRewardResponse.parse({
      alreadyClaimed,
      coinsAwarded,
      pointsAwarded,
      streakEvent,
      profile: await getProfile(userId),
    }),
  );
});

router.post("/challenge-unlocks", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  const input = UnlockChallengeBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: input.error.message });
    return;
  }
  await ensureLearner(userId);

  let unlocked = false;
  let coinsSpent = 0;
  const ageGroup = input.data.ageGroup;
  await db.transaction(async (tx) => {
    const [learner] = await tx
      .select()
      .from(learnersTable)
      .where(eq(learnersTable.id, userId))
      .for("update");
    if (!learner) throw new Error("Learner profile was not found");

    const [existingUnlock] = await tx
      .select()
      .from(challengeUnlocksTable)
      .where(
        and(
          eq(challengeUnlocksTable.userId, userId),
          eq(challengeUnlocksTable.ageGroup, ageGroup),
        ),
      )
      .limit(1);
    if (existingUnlock) {
      unlocked = true;
      return;
    }
    if (learner.coins < 10) return;

    coinsSpent = 10;
    unlocked = true;
    await tx.insert(challengeUnlocksTable).values({ userId, ageGroup });
    await tx
      .update(learnersTable)
      .set({ coins: learner.coins - coinsSpent, updatedAt: new Date() })
      .where(eq(learnersTable.id, userId));
  });

  if (!unlocked) {
    res.status(400).json({ error: "You need 10 coins to unlock this challenge." });
    return;
  }

  res.json(
    UnlockChallengeResponse.parse({
      ageGroup,
      unlocked,
      coinsSpent,
      profile: await getProfile(userId),
    }),
  );
});

router.post("/premium/extend", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  await ensureLearner(userId);

  const now = new Date();
  let premiumDays = 0;
  await db.transaction(async (tx) => {
    const [learner] = await tx
      .select()
      .from(learnersTable)
      .where(eq(learnersTable.id, userId))
      .for("update");
    if (
      !learner?.premiumExpiresAt ||
      learner.premiumExpiresAt.getTime() <= now.getTime()
    ) {
      return;
    }

    premiumDays = 6;
    await tx
      .update(learnersTable)
      .set({
        premiumExpiresAt: new Date(now.getTime() + premiumDays * dayInMs),
        updatedAt: now,
      })
      .where(eq(learnersTable.id, userId));
  });

  if (premiumDays === 0) {
    res.status(400).json({ error: "You need an active Premium Boost to extend it." });
    return;
  }
  res.json(
    ExtendPremiumResponse.parse({
      premiumDays,
      profile: await getProfile(userId),
    }),
  );
});

router.get("/shop", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  const learner = await ensureLearner(userId);
  const inventory = await db
    .select({
      itemId: shopInventoryTable.itemId,
      quantity: shopInventoryTable.quantity,
    })
    .from(shopInventoryTable)
    .where(eq(shopInventoryTable.userId, userId));
  const quantities = new Map(
    inventory.map((item) => [item.itemId, item.quantity]),
  );

  res.json(
    GetShopResponse.parse({
      coins: learner.coins,
      items: shopCatalog.map((item) => ({
        ...item,
        ownedCount: quantities.get(item.id) ?? 0,
      })),
    }),
  );
});

router.post("/shop/purchase", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  const input = PurchaseShopItemBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: input.error.message });
    return;
  }
  const item = shopCatalog.find((entry) => entry.id === input.data.itemId);
  if (!item) {
    res.status(400).json({ error: "That shop item is not available." });
    return;
  }

  await ensureLearner(userId);
  let insufficientCoins = false;
  let requestIdConflict = false;
  let coinsRemaining = 0;
  let ownedCount = 0;
  let coinsSpent: number = item.price;
  let alreadyProcessed = false;

  await db.transaction(async (tx) => {
    const [learner] = await tx
      .select()
      .from(learnersTable)
      .where(eq(learnersTable.id, userId))
      .for("update");
    if (!learner) throw new Error("Learner profile was not found");

    const [priorPurchase] = await tx
      .select()
      .from(shopPurchasesTable)
      .where(
        and(
          eq(shopPurchasesTable.userId, userId),
          eq(shopPurchasesTable.requestId, input.data.requestId),
        ),
      )
      .limit(1);

    if (priorPurchase) {
      if (priorPurchase.itemId !== item.id) {
        requestIdConflict = true;
        return;
      }
      const [existingInventory] = await tx
        .select({ quantity: shopInventoryTable.quantity })
        .from(shopInventoryTable)
        .where(
          and(
            eq(shopInventoryTable.userId, userId),
            eq(shopInventoryTable.itemId, item.id),
          ),
        )
        .limit(1);
      coinsRemaining = learner.coins;
      ownedCount = existingInventory?.quantity ?? 0;
      coinsSpent = priorPurchase.coinsSpent;
      alreadyProcessed = true;
      return;
    }

    if (learner.coins < item.price) {
      insufficientCoins = true;
      return;
    }

    const now = new Date();
    const [updatedInventory] = await tx
      .insert(shopInventoryTable)
      .values({ userId, itemId: item.id, quantity: 1, updatedAt: now })
      .onConflictDoUpdate({
        target: [shopInventoryTable.userId, shopInventoryTable.itemId],
        set: {
          quantity: sql`${shopInventoryTable.quantity} + 1`,
          updatedAt: now,
        },
      })
      .returning({ quantity: shopInventoryTable.quantity });

    await tx.insert(shopPurchasesTable).values({
      userId,
      requestId: input.data.requestId,
      itemId: item.id,
      coinsSpent: item.price,
    });
    const [updatedLearner] = await tx
      .update(learnersTable)
      .set({ coins: learner.coins - item.price, updatedAt: now })
      .where(eq(learnersTable.id, userId))
      .returning({ coins: learnersTable.coins });

    coinsRemaining = updatedLearner.coins;
    ownedCount = updatedInventory.quantity;
  });

  if (requestIdConflict) {
    res.status(409).json({ error: "This purchase request ID was already used." });
    return;
  }
  if (insufficientCoins) {
    res.status(400).json({ error: `You need ${item.price} coins to buy this item.` });
    return;
  }

  res.json(
    PurchaseShopItemResponse.parse({
      itemId: item.id,
      coinsSpent,
      coinsRemaining,
      ownedCount,
      alreadyProcessed,
    }),
  );
});

function indiaDate(now: Date) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const values = Object.fromEntries(
    parts.map((part) => [part.type, part.value]),
  );
  return `${values.year}-${values.month}-${values.day}`;
}

router.post("/games/maze/start", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  await ensureLearner(userId);

  const runId = randomUUID();
  const seed = randomInt(0, 2_147_483_647);
  await db.transaction(async (tx) => {
    const [learner] = await tx
      .select({ id: learnersTable.id })
      .from(learnersTable)
      .where(eq(learnersTable.id, userId))
      .for("update");
    if (!learner) throw new Error("Learner profile was not found");
    await tx.insert(mazeRunsTable).values({ id: runId, userId, seed });
  });

  res.json(
    StartMazeResponse.parse({
      runId,
      width: MAZE_WIDTH,
      height: MAZE_HEIGHT,
      grid: generateMaze(seed),
      start: MAZE_START,
      exit: MAZE_EXIT,
    }),
  );
});

router.post("/games/maze/complete", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  const input = CompleteMazeBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: input.error.message });
    return;
  }
  await ensureLearner(userId);

  let runNotFound = false;
  let invalidRoute = false;
  let coinsAwarded = 0;
  let alreadyCompleted = false;
  let discountEligible = false;

  await db.transaction(async (tx) => {
    const [learner] = await tx
      .select()
      .from(learnersTable)
      .where(eq(learnersTable.id, userId))
      .for("update");
    if (!learner) throw new Error("Learner profile was not found");

    const [run] = await tx
      .select()
      .from(mazeRunsTable)
      .where(
        and(
          eq(mazeRunsTable.id, input.data.runId),
          eq(mazeRunsTable.userId, userId),
        ),
      )
      .for("update")
      .limit(1);
    if (!run) {
      runNotFound = true;
      return;
    }

    if (run.completedAt) {
      coinsAwarded = run.coinsAwarded;
      alreadyCompleted = true;
      discountEligible = learner.mazeDiscountEligible;
      return;
    }

    if (!validateMazeRoute(run.seed, input.data.moves)) {
      invalidRoute = true;
      return;
    }

    const today = indiaDate(new Date());
    const [priorDailyReward] = await tx
      .select({ id: mazeRunsTable.id })
      .from(mazeRunsTable)
      .where(
        and(
          eq(mazeRunsTable.userId, userId),
          eq(mazeRunsTable.rewardDate, today),
        ),
      )
      .limit(1);
    coinsAwarded = priorDailyReward ? 0 : mazeRewardCoins;
    const now = new Date();

    await tx
      .update(mazeRunsTable)
      .set({
        completedAt: now,
        rewardDate: coinsAwarded > 0 ? today : null,
        coinsAwarded,
      })
      .where(eq(mazeRunsTable.id, run.id));
    await tx
      .update(learnersTable)
      .set({
        coins: learner.coins + coinsAwarded,
        mazeDiscountEligible: true,
        updatedAt: now,
      })
      .where(eq(learnersTable.id, userId));
    discountEligible = true;
  });

  if (runNotFound) {
    res.status(404).json({ error: "Maze run was not found. Start a new maze." });
    return;
  }
  if (invalidRoute) {
    res.status(400).json({ error: "That route does not reach the maze exit." });
    return;
  }

  res.json(
    CompleteMazeResponse.parse({
      coinsAwarded,
      alreadyCompleted,
      discountEligible,
      profile: await getProfile(userId),
    }),
  );
});

router.get("/leaderboard", async (req, res): Promise<void> => {
  if (!requireAuth(req, res)) return;

  const leaders = await db
    .select({
      displayName: learnersTable.displayName,
      points: learnersTable.points,
      activityRank: learnersTable.activityRank,
      streakDays: learnersTable.streakDays,
      completedLessons: count(lessonCompletionsTable.lessonId),
    })
    .from(learnersTable)
    .leftJoin(
      lessonCompletionsTable,
      eq(learnersTable.id, lessonCompletionsTable.userId),
    )
    .where(gt(learnersTable.points, 0))
    .groupBy(
      learnersTable.id,
      learnersTable.displayName,
      learnersTable.points,
      learnersTable.activityRank,
      learnersTable.streakDays,
      learnersTable.createdAt,
    )
    .orderBy(desc(learnersTable.points), asc(learnersTable.createdAt))
    .limit(3);

  res.json(
    GetLeaderboardResponse.parse(
      leaders.map((entry, index) => ({
        rank: index + 1,
        displayName: entry.displayName,
        points: entry.points,
        activityRank: entry.activityRank,
        activityGrade: activityGradeForStreak(entry.streakDays),
        completedLessons: Number(entry.completedLessons),
      })),
    ),
  );
});

export default router;