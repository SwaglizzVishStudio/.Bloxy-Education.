import { Router, type IRouter } from "express";
import healthRouter from "./health";
import educationRouter from "./education";
import moderationRouter from "./moderation";
import ownerRouter from "./owner";

const router: IRouter = Router();

router.use(healthRouter);
router.use(moderationRouter);
router.use(ownerRouter);
router.use(educationRouter);

export default router;
