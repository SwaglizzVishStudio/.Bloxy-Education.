import { clerkClient } from "@clerk/express";
import { and, asc, desc, eq, ilike, isNull } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  BanOwnerUserBody,
  BanOwnerUserParams,
  BanOwnerUserResponse,
  CreateOwnerSessionBody,
  CreateOwnerSessionResponse,
  DeleteOwnerSessionResponse,
  GetOwnerSessionResponse,
  KickOwnerUserBody,
  KickOwnerUserParams,
  KickOwnerUserResponse,
  ListOwnerSafetyReportsQueryParams,
  ListOwnerSafetyReportsResponse,
  ListOwnerUsersQueryParams,
  ListOwnerUsersResponse,
  ReviewOwnerSafetyReportBody,
  ReviewOwnerSafetyReportParams,
  ReviewOwnerSafetyReportResponse,
  UnbanOwnerUserParams,
  UnbanOwnerUserResponse,
} from "@workspace/api-zod";
import {
  db,
  learnersTable,
  moderationBansTable,
  moderationEventsTable,
  safetyPreferencesTable,
  safetyReportsTable,
} from "@workspace/db";
import { alias } from "drizzle-orm/pg-core";
import {
  revokeLearnerSessions,
} from "../lib/account-moderation";
import {
  clearOwnerSessionCookie,
  getOwnerSessionActor,
  isOwnerPassphraseConfigured,
  matchesOwnerPassphrase,
  OWNER_ACTOR_ID,
  setOwnerSessionCookie,
} from "../lib/owner-session";

const router: IRouter = Router();
const eventLifetimeMs = 15_000;

function requireOwner(req: Request, res: Response): string | null {
  const actorId = getOwnerSessionActor(req);
  if (!actorId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return actorId;
}

async function getTargetUserId(
  rawParams: Request["params"],
  paramSchema:
    | typeof KickOwnerUserParams
    | typeof BanOwnerUserParams
    | typeof UnbanOwnerUserParams,
  res: Response,
  ownerId: string,
): Promise<string | null> {
  const parsed = paramSchema.safeParse(rawParams);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return null;
  }
  const targetId = parsed.data.userId;
  if (targetId === ownerId) {
    res
      .status(400)
      .json({ error: "Owner actions cannot target the owner account." });
    return null;
  }
  const [target] = await db
    .select({ id: learnersTable.id })
    .from(learnersTable)
    .where(eq(learnersTable.id, targetId))
    .limit(1);
  if (!target) {
    res.status(404).json({ error: "Registered learner was not found." });
    return null;
  }
  return target.id;
}

async function queueOrRunAction(
  ownerId: string,
  targetId: string,
  action: "kick" | "ban",
  withScareRequested: boolean,
  banReason?: string,
): Promise<"completed" | "warning_sent"> {
  const [pending] = await db
    .select({ id: moderationEventsTable.id })
    .from(moderationEventsTable)
    .where(
      and(
        eq(moderationEventsTable.userId, targetId),
        isNull(moderationEventsTable.completedAt),
      ),
    )
    .limit(1);
  if (pending)
    throw new Error("A moderation action is already pending for this account.");

  const [preference] = await db
    .select({ allowSpookyEffects: safetyPreferencesTable.allowSpookyEffects })
    .from(safetyPreferencesTable)
    .where(eq(safetyPreferencesTable.userId, targetId))
    .limit(1);
  const showSpookyEffect =
    withScareRequested && preference?.allowSpookyEffects === true;

  if (showSpookyEffect) {
    const now = new Date();
    await db.transaction(async (tx) => {
      if (action === "ban") {
        await tx
          .insert(moderationBansTable)
          .values({
            userId: targetId,
            bannedBy: ownerId,
            reason: banReason?.trim() || "Blocked by the Bloxy owner.",
          })
          .onConflictDoUpdate({
            target: moderationBansTable.userId,
            set: {
              bannedBy: ownerId,
              reason: banReason?.trim() || "Blocked by the Bloxy owner.",
              bannedAt: now,
            },
          });
      }
      await tx.insert(moderationEventsTable).values({
        id: randomUUID(),
        userId: targetId,
        action,
        showSpookyEffect: true,
        createdAt: now,
        expiresAt: new Date(now.getTime() + eventLifetimeMs),
      });
    });
    return "warning_sent";
  }

  if (action === "ban") {
    await db
      .insert(moderationBansTable)
      .values({
        userId: targetId,
        bannedBy: ownerId,
        reason: banReason?.trim() || "Blocked by the Bloxy owner.",
      })
      .onConflictDoUpdate({
        target: moderationBansTable.userId,
        set: {
          bannedBy: ownerId,
          reason: banReason?.trim() || "Blocked by the Bloxy owner.",
          bannedAt: new Date(),
        },
      });
    if (!process.env.CLERK_SECRET_KEY) {
      throw new Error("Clerk server credentials are not configured");
    }
    await clerkClient.users.banUser(targetId);
  }
  await revokeLearnerSessions(targetId);
  return "completed";
}

const reporterLearners = alias(learnersTable, "safety_reporter");
const targetLearners = alias(learnersTable, "safety_target");

async function findOwnerReport(reportId: string) {
  const [report] = await db
    .select({
      id: safetyReportsTable.id,
      reporterName: reporterLearners.displayName,
      targetName: targetLearners.displayName,
      targetUserId: safetyReportsTable.targetUserId,
      reason: safetyReportsTable.reason,
      details: safetyReportsTable.details,
      evidence: safetyReportsTable.evidence,
      status: safetyReportsTable.status,
      createdAt: safetyReportsTable.createdAt,
      reviewedAt: safetyReportsTable.reviewedAt,
      reviewNote: safetyReportsTable.reviewNote,
    })
    .from(safetyReportsTable)
    .innerJoin(
      reporterLearners,
      eq(safetyReportsTable.reporterUserId, reporterLearners.id),
    )
    .innerJoin(
      targetLearners,
      eq(safetyReportsTable.targetUserId, targetLearners.id),
    )
    .where(eq(safetyReportsTable.id, reportId))
    .limit(1);
  return report ?? null;
}

router.get("/owner/session", (req, res): void => {
  res.json(
    GetOwnerSessionResponse.parse({
      authenticated: Boolean(getOwnerSessionActor(req)),
    }),
  );
});

router.post("/owner/session", async (req, res): Promise<void> => {
  const parsed = CreateOwnerSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a valid owner passphrase." });
    return;
  }
  if (!isOwnerPassphraseConfigured()) {
    res.status(503).json({
      error: "Owner sign-in has not been configured securely.",
    });
    return;
  }
  if (!matchesOwnerPassphrase(parsed.data.passphrase)) {
    await new Promise((resolve) => setTimeout(resolve, 250));
    res.status(401).json({ error: "The passphrase was not accepted." });
    return;
  }
  if (!setOwnerSessionCookie(res)) {
    res.status(503).json({
      error: "Owner sign-in has not been configured securely.",
    });
    return;
  }
  res.json(CreateOwnerSessionResponse.parse({ authenticated: true }));
});

router.delete("/owner/session", (_req, res): void => {
  clearOwnerSessionCookie(res);
  res.json(DeleteOwnerSessionResponse.parse({ authenticated: false }));
});

router.use("/owner", (req, res, next) => {
  if (!requireOwner(req, res)) return;
  next();
});

router.get("/owner/users", async (req, res): Promise<void> => {
  const ownerId = requireOwner(req, res);
  if (!ownerId) return;
  const parsed = ListOwnerUsersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const search = parsed.data.search?.trim();
  const rows = await db
    .select({
      id: learnersTable.id,
      displayName: learnersTable.displayName,
      ageGroup: learnersTable.ageGroup,
      bannedUserId: moderationBansTable.userId,
      createdAt: learnersTable.createdAt,
    })
    .from(learnersTable)
    .leftJoin(
      moderationBansTable,
      eq(learnersTable.id, moderationBansTable.userId),
    )
    .where(
      search ? ilike(learnersTable.displayName, `%${search}%`) : undefined,
    )
    .orderBy(asc(learnersTable.displayName))
    .limit(250);

  res.json(
    ListOwnerUsersResponse.parse(
      rows.map((row) => ({
        id: row.id,
        displayName: row.displayName,
        ageGroup:
          row.ageGroup === "kids" ||
          row.ageGroup === "teens" ||
          row.ageGroup === "adults"
            ? row.ageGroup
            : null,
        banned: Boolean(row.bannedUserId),
        createdAt: row.createdAt,
      })),
    ),
  );
});

router.post("/owner/users/:userId/kick", async (req, res): Promise<void> => {
  const ownerId = requireOwner(req, res);
  if (!ownerId) return;
  const targetId = await getTargetUserId(
    req.params,
    KickOwnerUserParams,
    res,
    ownerId,
  );
  if (!targetId) return;
  const parsed = KickOwnerUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const status = await queueOrRunAction(
      ownerId,
      targetId,
      "kick",
      parsed.data.withScare,
    );
    res.json(KickOwnerUserResponse.parse({ status, banned: false }));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message ===
        "A moderation action is already pending for this account."
    ) {
      res.status(409).json({ error: error.message });
      return;
    }
    req.log.error({ err: error, targetId }, "Failed to kick learner");
    res.status(502).json({ error: "Could not complete the session action." });
  }
});

router.post("/owner/users/:userId/ban", async (req, res): Promise<void> => {
  const ownerId = requireOwner(req, res);
  if (!ownerId) return;
  const targetId = await getTargetUserId(
    req.params,
    BanOwnerUserParams,
    res,
    ownerId,
  );
  if (!targetId) return;
  const parsed = BanOwnerUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const status = await queueOrRunAction(
      ownerId,
      targetId,
      "ban",
      parsed.data.withScare,
      parsed.data.reason,
    );
    res.json(BanOwnerUserResponse.parse({ status, banned: true }));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message ===
        "A moderation action is already pending for this account."
    ) {
      res.status(409).json({ error: error.message });
      return;
    }
    req.log.error({ err: error, targetId }, "Failed to ban learner");
    res.status(502).json({ error: "Could not complete the account action." });
  }
});

router.post("/owner/users/:userId/unban", async (req, res): Promise<void> => {
  const ownerId = requireOwner(req, res);
  if (!ownerId) return;
  const targetId = await getTargetUserId(
    req.params,
    UnbanOwnerUserParams,
    res,
    ownerId,
  );
  if (!targetId) return;

  try {
    if (!process.env.CLERK_SECRET_KEY) {
      throw new Error("Clerk server credentials are not configured");
    }
    await clerkClient.users.unbanUser(targetId);
    await db.transaction(async (tx) => {
      await tx
        .delete(moderationBansTable)
        .where(eq(moderationBansTable.userId, targetId));
      await tx
        .update(moderationEventsTable)
        .set({ completedAt: new Date() })
        .where(
          and(
            eq(moderationEventsTable.userId, targetId),
            eq(moderationEventsTable.action, "ban"),
            isNull(moderationEventsTable.completedAt),
          ),
        );
    });
    res.json(
      UnbanOwnerUserResponse.parse({ status: "completed", banned: false }),
    );
  } catch (error) {
    req.log.error({ err: error, targetId }, "Failed to unban learner");
    res.status(502).json({ error: "Could not restore the account." });
  }
});

router.get("/owner/reports", async (req, res): Promise<void> => {
  const parsed = ListOwnerSafetyReportsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const rows = await db
    .select({
      id: safetyReportsTable.id,
      reporterName: reporterLearners.displayName,
      targetName: targetLearners.displayName,
      targetUserId: safetyReportsTable.targetUserId,
      reason: safetyReportsTable.reason,
      details: safetyReportsTable.details,
      evidence: safetyReportsTable.evidence,
      status: safetyReportsTable.status,
      createdAt: safetyReportsTable.createdAt,
      reviewedAt: safetyReportsTable.reviewedAt,
      reviewNote: safetyReportsTable.reviewNote,
    })
    .from(safetyReportsTable)
    .innerJoin(
      reporterLearners,
      eq(safetyReportsTable.reporterUserId, reporterLearners.id),
    )
    .innerJoin(
      targetLearners,
      eq(safetyReportsTable.targetUserId, targetLearners.id),
    )
    .where(
      parsed.data.status
        ? eq(safetyReportsTable.status, parsed.data.status)
        : undefined,
    )
    .orderBy(desc(safetyReportsTable.createdAt))
    .limit(250);
  res.json(ListOwnerSafetyReportsResponse.parse(rows));
});

router.patch(
  "/owner/reports/:reportId/review",
  async (req, res): Promise<void> => {
    const ownerId = requireOwner(req, res);
    if (!ownerId) return;
    const params = ReviewOwnerSafetyReportParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = ReviewOwnerSafetyReportBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const [updated] = await db
      .update(safetyReportsTable)
      .set({
        status: parsed.data.status,
        reviewedAt: new Date(),
        reviewedBy: ownerId,
        reviewNote: parsed.data.reviewNote?.trim() || null,
      })
      .where(eq(safetyReportsTable.id, params.data.reportId))
      .returning({ id: safetyReportsTable.id });
    if (!updated) {
      res.status(404).json({ error: "Safety report was not found." });
      return;
    }

    const report = await findOwnerReport(updated.id);
    if (!report) {
      res.status(404).json({ error: "Safety report was not found." });
      return;
    }
    res.json(ReviewOwnerSafetyReportResponse.parse(report));
  },
);

export default router;
