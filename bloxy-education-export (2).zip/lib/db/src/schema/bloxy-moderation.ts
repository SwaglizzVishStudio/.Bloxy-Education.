import { createInsertSchema } from "drizzle-zod";
import { boolean, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { learnersTable } from "./bloxy-education";

export const moderationBansTable = pgTable("bloxy_moderation_bans", {
  userId: text("user_id")
    .primaryKey()
    .references(() => learnersTable.id, { onDelete: "cascade" }),
  reason: text("reason").notNull(),
  bannedBy: text("banned_by").notNull(),
  bannedAt: timestamp("banned_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const moderationEventsTable = pgTable("bloxy_moderation_events", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => learnersTable.id, { onDelete: "cascade" }),
  action: text("action").$type<"kick" | "ban">().notNull(),
  showSpookyEffect: boolean("show_spooky_effect").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const safetyReportsTable = pgTable("bloxy_safety_reports", {
  id: text("id").primaryKey(),
  reporterUserId: text("reporter_user_id")
    .notNull()
    .references(() => learnersTable.id, { onDelete: "cascade" }),
  targetUserId: text("target_user_id")
    .notNull()
    .references(() => learnersTable.id, { onDelete: "cascade" }),
  reason: text("reason")
    .$type<"unsafe_contact" | "personal_information" | "harassment" | "other">()
    .notNull(),
  details: text("details").notNull(),
  evidence: text("evidence"),
  status: text("status")
    .$type<"pending" | "action_taken" | "reviewed" | "dismissed">()
    .notNull()
    .default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  reviewedBy: text("reviewed_by"),
  reviewNote: text("review_note"),
});

export const safetyPreferencesTable = pgTable("bloxy_safety_preferences", {
  userId: text("user_id")
    .primaryKey()
    .references(() => learnersTable.id, { onDelete: "cascade" }),
  allowSpookyEffects: boolean("allow_spooky_effects")
    .notNull()
    .default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertModerationBanSchema = createInsertSchema(
  moderationBansTable,
).omit({ bannedAt: true });
export const insertModerationEventSchema = createInsertSchema(
  moderationEventsTable,
).omit({ createdAt: true, completedAt: true });
export const insertSafetyReportSchema = createInsertSchema(
  safetyReportsTable,
).omit({ createdAt: true, reviewedAt: true, reviewedBy: true });
export const insertSafetyPreferenceSchema = createInsertSchema(
  safetyPreferencesTable,
).omit({ updatedAt: true });

export type ModerationBan = typeof moderationBansTable.$inferSelect;
export type InsertModerationBan = z.infer<typeof insertModerationBanSchema>;
export type ModerationEvent = typeof moderationEventsTable.$inferSelect;
export type InsertModerationEvent = z.infer<typeof insertModerationEventSchema>;
export type SafetyReport = typeof safetyReportsTable.$inferSelect;
export type InsertSafetyReport = z.infer<typeof insertSafetyReportSchema>;
export type SafetyPreference = typeof safetyPreferencesTable.$inferSelect;
export type InsertSafetyPreference = z.infer<
  typeof insertSafetyPreferenceSchema
>;
