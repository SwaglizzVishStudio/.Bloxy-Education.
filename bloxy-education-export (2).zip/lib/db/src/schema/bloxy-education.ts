import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  date,
  integer,
  pgTable,
  primaryKey,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const learnersTable = pgTable("bloxy_learners", {
  id: text("id").primaryKey(),
  displayName: text("display_name").notNull(),
  ageGroup: text("age_group"),
  coins: integer("coins").notNull().default(0),
  points: integer("points").notNull().default(0),
  streakDays: integer("streak_days").notNull().default(0),
  activityRank: integer("activity_rank").notNull().default(1000),
  activityLastPlayedAt: timestamp("activity_last_played_at", {
    withTimezone: true,
  }),
  lastRewardDate: date("last_reward_date", { mode: "string" }),
  premiumExpiresAt: timestamp("premium_expires_at", { withTimezone: true }),
  mazeDiscountEligible: boolean("maze_discount_eligible")
    .notNull()
    .default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const dailyRewardsTable = pgTable(
  "bloxy_daily_rewards",
  {
    userId: text("user_id")
      .notNull()
      .references(() => learnersTable.id, { onDelete: "cascade" }),
    rewardDate: date("reward_date", { mode: "string" }).notNull(),
    coinsAwarded: integer("coins_awarded").notNull(),
    pointsAwarded: integer("points_awarded").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.rewardDate] })],
);

export const lessonCompletionsTable = pgTable(
  "bloxy_lesson_completions",
  {
    userId: text("user_id")
      .notNull()
      .references(() => learnersTable.id, { onDelete: "cascade" }),
    lessonId: text("lesson_id").notNull(),
    correctCount: integer("correct_count").notNull(),
    totalQuestions: integer("total_questions").notNull(),
    pointsEarned: integer("points_earned").notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.lessonId] })],
);

export const challengeUnlocksTable = pgTable(
  "bloxy_challenge_unlocks",
  {
    userId: text("user_id")
      .notNull()
      .references(() => learnersTable.id, { onDelete: "cascade" }),
    ageGroup: text("age_group").notNull(),
    unlockedAt: timestamp("unlocked_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.ageGroup] })],
);

export const shopInventoryTable = pgTable(
  "bloxy_shop_inventory",
  {
    userId: text("user_id")
      .notNull()
      .references(() => learnersTable.id, { onDelete: "cascade" }),
    itemId: text("item_id").notNull(),
    quantity: integer("quantity").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [primaryKey({ columns: [table.userId, table.itemId] })],
);

export const shopPurchasesTable = pgTable(
  "bloxy_shop_purchases",
  {
    userId: text("user_id")
      .notNull()
      .references(() => learnersTable.id, { onDelete: "cascade" }),
    requestId: text("request_id").notNull(),
    itemId: text("item_id").notNull(),
    coinsSpent: integer("coins_spent").notNull(),
    purchasedAt: timestamp("purchased_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.requestId] })],
);

export const mazeRunsTable = pgTable(
  "bloxy_maze_runs",
  {
    id: text("id").primaryKey(),
    userId: text("user_id")
      .notNull()
      .references(() => learnersTable.id, { onDelete: "cascade" }),
    seed: integer("seed").notNull(),
    startedAt: timestamp("started_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    rewardDate: date("reward_date", { mode: "string" }),
    coinsAwarded: integer("coins_awarded").notNull().default(0),
  },
  (table) => [
    uniqueIndex("bloxy_maze_runs_user_reward_date_unique").on(
      table.userId,
      table.rewardDate,
    ),
  ],
);

export const insertLearnerSchema = createInsertSchema(learnersTable).omit({
  createdAt: true,
  updatedAt: true,
});
export const insertDailyRewardSchema = createInsertSchema(dailyRewardsTable).omit({
  createdAt: true,
});
export const insertLessonCompletionSchema = createInsertSchema(
  lessonCompletionsTable,
).omit({ completedAt: true });
export const insertChallengeUnlockSchema = createInsertSchema(
  challengeUnlocksTable,
).omit({ unlockedAt: true });
export const insertShopInventorySchema = createInsertSchema(shopInventoryTable).omit({
  updatedAt: true,
});
export const insertShopPurchaseSchema = createInsertSchema(shopPurchasesTable).omit({
  purchasedAt: true,
});
export const insertMazeRunSchema = createInsertSchema(mazeRunsTable).omit({
  startedAt: true,
});

export type Learner = typeof learnersTable.$inferSelect;
export type InsertLearner = z.infer<typeof insertLearnerSchema>;
export type DailyReward = typeof dailyRewardsTable.$inferSelect;
export type InsertDailyReward = z.infer<typeof insertDailyRewardSchema>;
export type LessonCompletion = typeof lessonCompletionsTable.$inferSelect;
export type InsertLessonCompletion = z.infer<typeof insertLessonCompletionSchema>;
export type ChallengeUnlock = typeof challengeUnlocksTable.$inferSelect;
export type InsertChallengeUnlock = z.infer<typeof insertChallengeUnlockSchema>;
export type ShopInventory = typeof shopInventoryTable.$inferSelect;
export type InsertShopInventory = z.infer<typeof insertShopInventorySchema>;
export type ShopPurchase = typeof shopPurchasesTable.$inferSelect;
export type InsertShopPurchase = z.infer<typeof insertShopPurchaseSchema>;
export type MazeRun = typeof mazeRunsTable.$inferSelect;
export type InsertMazeRun = z.infer<typeof insertMazeRunSchema>;